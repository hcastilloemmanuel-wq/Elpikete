import react from '@vitejs/plugin-react'
import { defineConfig } from 'vitest/config'
import { VitePWA } from 'vite-plugin-pwa'

// VITE_BASE: '/elpikete/' en GitHub Pages; '/' con dominio propio.
// VITE_SINGLE=1: versión de prueba en un solo archivo .html (sin service worker, todo incluido).
const single = process.env.VITE_SINGLE === '1'
const base = single ? './' : (process.env.VITE_BASE ?? '/elpikete/')

export default defineConfig({
  base,
  ...(single ? {
    resolve: { alias: { 'virtual:pwa-register/react': new URL('./src/lib/pwa-stub.ts', import.meta.url).pathname } },
    build: { outDir: 'dist-single', assetsInlineLimit: 100_000_000, cssCodeSplit: false, rollupOptions: { output: { inlineDynamicImports: true } } },
  } : {}),
  plugins: [
    react(),
    ...(single ? [] : [VitePWA({
      registerType: 'prompt',
      includeAssets: ['favicon.svg', 'apple-touch-icon.png'],
      manifest: {
        name: 'El Pikete', short_name: 'El Pikete', lang: 'es',
        description: 'La red social de los cubanos en Brasil',
        theme_color: '#2B3FD4', background_color: '#F6F5F0', display: 'standalone',
        start_url: base, scope: base,
        icons: [
          { src: 'icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,svg,png,woff2}'],
        // Las listas de ciudades por estado no se descargan todas al instalar: se guardan al usarlas.
        globIgnores: ['**/assets/[A-Z][A-Z]-*.js'],
        navigateFallback: `${base}index.html`,
        runtimeCaching: [{ urlPattern: /\/assets\/[A-Z]{2}-[^/]+\.js$/, handler: 'CacheFirst', options: { cacheName: 'ciudades', expiration: { maxEntries: 30 } } }],
      },
    })]),
  ],
  test: { environment: 'jsdom', globals: true, setupFiles: ['./tests/setup.ts'], include: ['tests/**/*.test.{ts,tsx}'] },
})
