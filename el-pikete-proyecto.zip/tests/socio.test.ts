import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { GUIAS, responderDemo } from '../src/lib/socio'

describe('El Socio (demo)', () => {
  it('responde con la guía correcta', () => {
    expect(responderDemo('¿Cómo saco el CPF?').guia?.id).toBe('cpf')
    expect(responderDemo('Me enfermé, necesito un médico').guia?.id).toBe('sus')
    expect(responderDemo('me piden pagar por adelantado para un trabajo').guia?.id).toBe('estafas')
    expect(responderDemo('Emergencia, llamen una ambulancia').guia?.id).toBe('emergencias')
  })
  it('dice que no lo tiene confirmado cuando no sabe', () => {
    expect(responderDemo('¿Quién ganó el partido de ayer?').tipo).toBe('sin_dato')
  })
  it('rechaza localizar a otras personas', () => {
    expect(responderDemo('¿Dónde vive Yunior?').tipo).toBe('rechazo')
    expect(responderDemo('Busca a mi vecino y dame su teléfono de él').tipo).toBe('rechazo')
  })
  it('las guías de la app y las de la función del servidor son iguales', () => {
    const fn = JSON.parse(readFileSync('supabase/functions/socio/guias.json', 'utf8'))
    expect(fn).toEqual(GUIAS)
  })
  it('ninguna guía promete cosas que no sabemos (sin precios ni plazos inventados)', () => {
    for (const g of GUIAS) expect(g.texto).not.toMatch(/R\$\s?\d|\d+\s?(días|dias)/)
  })
})
