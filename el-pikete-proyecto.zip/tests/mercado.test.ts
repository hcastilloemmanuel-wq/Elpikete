import { describe, expect, it } from 'vitest'
import { detectarRiesgo, diasRestantes, filtrarAnuncios, validarAnuncio, venceEn, vencido, seccionDe } from '../src/lib/mercado'
import type { Anuncio } from '../src/lib/mercado'

const base: Anuncio = { id: '1', user_id: 'u', apodo: 'A', avatar_color: '#2B3FD4', ciudad_ibge: 1400100, ciudad_nombre: 'Boa Vista', tipo: 'vendo', titulo: 'Bicicleta', descripcion: 'Aro 26 en buen estado.', precio: 400, barrio: null, jornada: null, idioma: null, mostrar_whatsapp: false, creado_en: '2026-11-01T00:00:00Z', vence_en: '2026-12-01T00:00:00Z', estado: 'activo' }

describe('anti-estafa', () => {
  it('detecta pago por adelantado, terceros, ganancia fácil y documentos', () => {
    expect(detectarRiesgo('Empleo seguro, pago por adelantado de la taxa')).toContain('adelantado')
    expect(detectarRiesgo('Pague a taxa de inscrição antes')).toContain('adelantado')
    expect(detectarRiesgo('Manda el dinero por Western Union')).toContain('terceros')
    expect(detectarRiesgo('Gana dinero fácil desde casa')).toContain('facil')
    expect(detectarRiesgo('Envía tu pasaporte para empezar')).toContain('documentos')
  })
  it('no marca anuncios normales', () => {
    expect(detectarRiesgo('Bicicleta aro 26', 'Se paga al recoger, en efectivo.')).toEqual([])
    expect(detectarRiesgo('Ayudante de cocina', 'Turno de tarde. Pago semanal.')).toEqual([])
  })
})
describe('anuncios', () => {
  it('vencen a los 30 días', () => {
    const ahora = Date.parse('2026-11-03T00:00:00Z')
    expect(Math.round((Date.parse(venceEn(ahora)) - ahora) / 86400000)).toBe(30)
    expect(vencido({ vence_en: '2026-11-02T00:00:00Z' }, ahora)).toBe(true)
    expect(diasRestantes({ vence_en: '2026-11-13T00:00:00Z' }, ahora)).toBe(10)
  })
  it('separa Bolsa y Pincha y filtra', () => {
    const ahora = Date.parse('2026-11-03T00:00:00Z')
    const pincha = { ...base, id: '2', tipo: 'empleo' as const, titulo: 'Ayudante de cocina' }
    const venc = { ...base, id: '3', vence_en: '2026-11-01T00:00:00Z' }
    const rev = { ...base, id: '4', estado: 'revision' as const }
    const f = { texto: '', seccion: 'bolsa' as const, tipo: null, solo_mi_ciudad: true, ciudad: 1400100 }
    expect(seccionDe('busco_empleo')).toBe('pincha')
    expect(filtrarAnuncios([base, pincha, venc, rev], f, ahora).map((a) => a.id)).toEqual(['1'])
    expect(filtrarAnuncios([base, pincha], { ...f, seccion: 'pincha', texto: 'cocína' }, ahora).map((a) => a.id)).toEqual(['2'])
    expect(filtrarAnuncios([{ ...base, ciudad_ibge: 1302603 }], f, ahora)).toEqual([])
  })
  it('valida', () => {
    const b = { tipo: 'vendo' as const, titulo: 'Bici', descripcion: 'Buen estado, aro 26.', precio: 100, barrio: null, jornada: null, idioma: null, mostrar_whatsapp: false }
    expect(validarAnuncio(b)).toBeNull()
    expect(validarAnuncio({ ...b, titulo: 'ab' })).toBe('anuncio_titulo')
    expect(validarAnuncio({ ...b, precio: -1 })).toBe('anuncio_precio')
  })
})
