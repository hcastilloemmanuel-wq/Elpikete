import { cleanup, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import App from '../src/App'
import { setLang } from '../src/i18n'

beforeEach(() => { localStorage.clear(); sessionStorage.clear(); window.location.hash = '#/'; setLang('es') })
afterEach(cleanup)

describe('registro completo de punta a punta (modo demo)', () => {
  it('entra, completa las pantallas saltando lo opcional y llega a la cuadra', async () => {
    const u = userEvent.setup()
    render(<App />)
    await screen.findByText('Entra a tu cuadra')
    await u.click(screen.getByRole('button', { name: 'Enviarme el código' }))
    expect(await screen.findByText('Pon al menos 2 letras.')).toBeInTheDocument()
    await u.type(screen.getByLabelText('¿Cómo te llamamos?'), 'Yoel')
    await u.type(screen.getByLabelText('Correo'), 'yoel@correo.com')
    await u.click(screen.getByRole('button', { name: 'Enviarme el código' }))
    expect(await screen.findByText('Tienes que confirmar que tienes 18 años o más.')).toBeInTheDocument()
    await u.click(screen.getByLabelText('Tengo 18 años o más'))
    await u.click(screen.getByRole('button', { name: 'Enviarme el código' }))
    await u.type(await screen.findByLabelText('Código'), '123456')
    await u.click(screen.getByRole('button', { name: 'Entrar' }))

    await screen.findByText('¿De dónde eres?')
    await u.click(screen.getByRole('button', { name: 'Siguiente' }))
    expect(await screen.findByText('Elige tu provincia.')).toBeInTheDocument()
    await u.selectOptions(screen.getByLabelText('Provincia de Cuba'), 'Matanzas')
    await u.click(screen.getByRole('button', { name: 'Siguiente' }))

    await screen.findByText('¿Dónde vives ahora?')
    await u.selectOptions(screen.getByLabelText('Estado de Brasil'), 'RR')
    await u.type(await screen.findByPlaceholderText('Escribe para buscar tu ciudad'), 'boa vis')
    await u.click(await screen.findByRole('option', { name: 'Boa Vista' }))
    await u.click(screen.getByRole('button', { name: 'Siguiente' }))

    await screen.findByText(/¿A qué te dedicas\?/)
    await u.click(screen.getByRole('button', { name: 'Prefiero no decirlo por ahora' }))
    await screen.findByText(/Tu WhatsApp/)
    await u.type(screen.getByLabelText('Número con código de país'), 'hola')
    await u.click(screen.getByRole('button', { name: 'Siguiente' }))
    expect(await screen.findByText(/Revisa el número/)).toBeInTheDocument()
    await u.click(screen.getByRole('button', { name: 'Prefiero no decirlo por ahora' }))

    await screen.findByText('¿Para qué entras?')
    await u.click(screen.getByRole('button', { name: 'Acabo de llegar' }))
    await u.click(screen.getByRole('button', { name: 'Siguiente' }))
    await screen.findByText('Último toque')
    await u.click(screen.getByRole('button', { name: 'Entrar a mi cuadra' }))

    expect(await screen.findByRole('heading', { name: 'Cuadra de Boa Vista' })).toBeInTheDocument()
    await waitFor(() => expect(screen.queryByText('Último toque')).toBeNull())
  }, 30000)

  it('entra con teléfono, ve el aviso de demostración y usa el código de prueba', async () => {
    const u = userEvent.setup()
    render(<App />)
    await screen.findByText('Entra a tu cuadra')
    await u.type(screen.getByLabelText('¿Cómo te llamamos?'), 'Rosa')
    await u.click(screen.getByRole('button', { name: /Teléfono/ }))
    await u.click(screen.getByLabelText('Tengo 18 años o más'))
    await u.click(screen.getByRole('button', { name: 'Enviarme el código' }))
    expect(await screen.findByText('Escribe tu número.')).toBeInTheDocument()
    await u.type(screen.getByLabelText('Número con código de país'), '95 99999-9999')
    await u.click(screen.getByRole('button', { name: 'Enviarme el código' }))
    expect(await screen.findByText('Modo demostración: no se envía nada de verdad')).toBeInTheDocument()
    expect(screen.getByText(/\+5595999999999/)).toBeInTheDocument()
    await u.click(screen.getByRole('button', { name: 'Poner el código de prueba' }))
    await u.click(screen.getByRole('button', { name: 'Entrar' }))
    await screen.findByText('¿De dónde eres?')
  }, 30000)
})
