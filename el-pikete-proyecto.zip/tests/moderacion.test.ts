import { beforeEach, describe, expect, it } from 'vitest'
import { social } from '../src/lib/backend/demo-social'
import type { Perfil } from '../src/lib/backend/types'

const perfil = (id: string, apodo: string): Perfil => ({ id, apodo, provincia_cuba: 'Matanzas', estado_br: 'RR', ciudad_ibge: 1400100, ciudad_nombre: 'Boa Vista', barrio: null, oficios: [], oficio_visibilidad: 'todos', modo_discreto: false, recien_llegado: false, propositos: [], frase: null, avatar_color: '#2B3FD4', paso: 7, completado: true })
const A = perfil('a', 'Ana'), B = perfil('b', 'Beto'), C = perfil('c', 'Cuca'), D = perfil('d', 'Dani')
const ctx = (yo: Perfil) => ({ yo, otros: [A, B, C, D].filter((x) => x.id !== yo.id) })

describe('moderación (demo)', () => {
  beforeEach(() => localStorage.clear())
  it('bloquear oculta publicaciones, paisanos y corta la amistad', () => {
    social.createPost(ctx(B), 'aviso', 'Soy Beto')
    expect(social.listPosts(ctx(A)).some((p) => p.autor.id === 'b')).toBe(true)
    social.pedirAmistad(ctx(A), 'b')
    social.bloquear(ctx(A), 'b')
    expect(social.listPosts(ctx(A)).some((p) => p.autor.id === 'b')).toBe(false)
    expect(social.listPosts(ctx(B)).some((p) => p.autor.id === 'a')).toBe(false)
    expect(social.paisanos(ctx(A)).some((p) => p.id === 'b')).toBe(false)
    expect(social.amistades(ctx(A))).toHaveLength(0)
  })
  it('no se puede escribir a alguien que te bloqueó', () => {
    social.pedirAmistad(ctx(A), 'ej-p1')
    social.bloquear(ctx(A), 'ej-p1')
    expect(() => social.enviar(ctx(A), 'ej-p1', 'hola')).toThrow()
  })
  it('tres reportes de personas distintas ocultan la publicación', () => {
    social.createPost(ctx(D), 'aviso', 'Mándame dinero por adelantado')
    const id = social.listPosts(ctx(A)).find((p) => p.autor.id === 'd')!.id
    social.reportarPost(ctx(A), id); social.reportarPost(ctx(A), id)
    expect(social.listPosts(ctx(A)).some((p) => p.id === id)).toBe(true) // el mismo usuario dos veces cuenta una
    social.reportarPost(ctx(B), id); social.reportarPost(ctx(C), id)
    expect(social.listPosts(ctx(A)).some((p) => p.id === id)).toBe(false)
  })
})
