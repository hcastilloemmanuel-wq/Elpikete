import { vi, beforeEach, describe, expect, it } from 'vitest'
import { demoBackend } from '../src/lib/backend/demo'
import { guardarBorrador, leerBorrador, limpiarCachePrivada, setRemember } from '../src/lib/storage'

beforeEach(() => { localStorage.clear(); sessionStorage.clear() })

describe('sesión por dispositivo (modo demo)', () => {
  it('código incorrecto no entra', async () => {
    await demoBackend.requestCode('a@b.co', 'Ana')
    await expect(demoBackend.verifyCode('a@b.co', '000000')).rejects.toMatchObject({ code: 'codigo_incorrecto' })
    expect(await demoBackend.getSession()).toBeNull()
  })
  it('entra, guarda perfil y contacto, y cierra sesión', async () => {
    await demoBackend.requestCode('a@b.co', 'Ana'); await demoBackend.verifyCode('a@b.co', '123456')
    const p = await demoBackend.savePerfil({ provincia_cuba: 'Matanzas', paso: 3 })
    expect(p.apodo).toBe('Ana'); expect(p.provincia_cuba).toBe('Matanzas')
    await demoBackend.saveContacto({ whatsapp: '5595999999999', whatsapp_visibilidad: 'amigos' })
    expect((await demoBackend.getContacto()).whatsapp_visibilidad).toBe('amigos')
    await demoBackend.signOut('local'); expect(await demoBackend.getSession()).toBeNull()
  })
  it('en otro dispositivo (sin la sesión local) hay que volver a entrar', async () => {
    await demoBackend.requestCode('a@b.co', 'Ana'); await demoBackend.verifyCode('a@b.co', '123456')
    localStorage.removeItem('pk_demo_session'); sessionStorage.clear()
    expect(await demoBackend.getSession()).toBeNull()
  })
  it('dispositivo compartido: la sesión vive en sessionStorage y no en localStorage', async () => {
    setRemember(false)
    await demoBackend.requestCode('c@d.co', 'Carlos'); await demoBackend.verifyCode('c@d.co', '123456')
    expect(sessionStorage.getItem('pk_demo_session')).not.toBeNull(); expect(localStorage.getItem('pk_demo_session')).toBeNull()
  })
  it('mi teléfono: la sesión vive en localStorage', async () => {
    setRemember(true)
    await demoBackend.requestCode('c@d.co', 'Carlos'); await demoBackend.verifyCode('c@d.co', '123456')
    expect(localStorage.getItem('pk_demo_session')).not.toBeNull()
  })
  it('borrar la cuenta elimina datos y sesión', async () => {
    await demoBackend.requestCode('a@b.co', 'Ana'); await demoBackend.verifyCode('a@b.co', '123456')
    await demoBackend.deleteAccount()
    expect(await demoBackend.getSession()).toBeNull(); expect(JSON.parse(localStorage.getItem('pk_demo_db') ?? '{}')).toEqual({})
  })
  it('limpiar caché privada borra borradores', () => {
    guardarBorrador('chat', { x: 1 }); expect(leerBorrador('chat')).toEqual({ x: 1 })
    limpiarCachePrivada(); expect(leerBorrador('chat')).toBeNull()
  })
  it('si el teléfono bloquea el almacenamiento, la demo sigue funcionando en memoria', async () => {
    const boom = () => { throw new DOMException('insecure', 'SecurityError') }
    const espias = [
      vi.spyOn(Storage.prototype, 'getItem').mockImplementation(boom),
      vi.spyOn(Storage.prototype, 'setItem').mockImplementation(boom),
      vi.spyOn(Storage.prototype, 'removeItem').mockImplementation(boom),
    ]
    try {
      await demoBackend.requestCode('z@z.co', 'Zeta'); await demoBackend.verifyCode('z@z.co', '123456')
      expect((await demoBackend.getSession())?.userId).toBeTruthy()
      await demoBackend.signOut('local'); expect(await demoBackend.getSession()).toBeNull()
    } finally { espias.forEach((e) => e.mockRestore()) }
  })
})
