import { describe, expect, it } from 'vitest'
import { normalizarWhatsapp, validarApodo, validarCodigo, validarCorreo, validarWhatsapp } from '../src/lib/validate'

describe('apodo', () => {
  it('acepta apodos normales con tildes y eñes', () => { expect(validarApodo('Yoandry ñ')).toBeNull() })
  it('rechaza cortos, largos y con enlaces', () => {
    expect(validarApodo('a')).toBe('apodo_corto'); expect(validarApodo('x'.repeat(31))).toBe('apodo_largo')
    expect(validarApodo('mira www.x.com')).toBe('apodo_enlace'); expect(validarApodo('yo@mail')).toBe('apodo_enlace')
  })
})
describe('correo y código', () => {
  it('correo', () => { expect(validarCorreo('a@b.co')).toBeNull(); expect(validarCorreo('a@b')).toBe('correo_invalido'); expect(validarCorreo(' ')).toBe('correo_vacio') })
  it('código de 6 dígitos', () => { expect(validarCodigo('123456')).toBeNull(); expect(validarCodigo('12345')).toBe('codigo_invalido'); expect(validarCodigo('12a456')).toBe('codigo_invalido') })
})
describe('whatsapp', () => {
  it('vacío es válido (opcional)', () => { expect(validarWhatsapp('')).toBeNull() })
  it('normaliza números brasileños sin código de país', () => { expect(normalizarWhatsapp('(95) 99999-9999')).toBe('5595999999999') })
  it('acepta formato internacional con + y espacios', () => { expect(validarWhatsapp('+55 95 99999-9999')).toBeNull(); expect(normalizarWhatsapp('+53 5 123 4567')).toBe('5351234567') })
  it('rechaza letras y números imposibles', () => { expect(validarWhatsapp('hola')).toBe('whatsapp_invalido'); expect(validarWhatsapp('123')).toBe('whatsapp_invalido'); expect(validarWhatsapp('+55 95 9999')).toBe('whatsapp_invalido') })
})
