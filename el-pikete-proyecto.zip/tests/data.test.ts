import { describe, expect, it } from 'vitest'
import { ciudadesDe, ESTADOS_BR, OFICIOS_PLANOS, PROVINCIAS_CUBA } from '../src/lib/data'

describe('listas de referencia', () => {
  it('Cuba: 15 provincias y el municipio especial', () => { expect(PROVINCIAS_CUBA).toHaveLength(16); expect(PROVINCIAS_CUBA).toContain('Matanzas') })
  it('Brasil: 27 unidades federativas', () => { expect(ESTADOS_BR).toHaveLength(27); expect(ESTADOS_BR.find((e) => e.uf === 'RR')?.nombre).toBe('Roraima') })
  it('Todas las ciudades tienen código IBGE único y suman al menos 5570', async () => {
    const todas = (await Promise.all(ESTADOS_BR.map((e) => ciudadesDe(e.uf)))).flat()
    expect(todas.length).toBeGreaterThanOrEqual(5570)
    expect(new Set(todas.map((c) => c.ibge)).size).toBe(todas.length)
  })
  it('Boa Vista (RR) existe con su código oficial', async () => {
    const rr = await ciudadesDe('RR'); expect(rr.find((c) => c.nombre === 'Boa Vista')?.ibge).toBe(1400100)
  })
  it('hay más de una Boa Vista en Brasil: por eso se guarda el código y no el nombre', async () => {
    const todas = (await Promise.all(ESTADOS_BR.map((e) => ciudadesDe(e.uf)))).flat()
    expect(todas.filter((c) => c.nombre === 'Boa Vista').length).toBeGreaterThan(1)
  })
  it('estado desconocido devuelve lista vacía', async () => { expect(await ciudadesDe('XX')).toEqual([]) })
  it('oficios sin repetidos', () => { expect(new Set(OFICIOS_PLANOS).size).toBe(OFICIOS_PLANOS.length) })
})
