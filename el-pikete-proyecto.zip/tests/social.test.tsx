import { beforeEach, describe, expect, it } from 'vitest'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import App from '../src/App'
import { validarTexto, tiempoRelativo } from '../src/lib/social'

describe('social: lógica', () => {
  it('valida el texto', () => {
    expect(validarTexto('   ', 500)).toBe('texto_vacio')
    expect(validarTexto('x'.repeat(501), 500)).toBe('texto_largo')
    expect(validarTexto('hola', 500)).toBeNull()
  })
  it('tiempo relativo', () => {
    const ahora = Date.parse('2026-11-03T12:00:00Z')
    expect(tiempoRelativo('2026-11-03T11:59:40Z', ahora).k).toBe('tiempo.ahora')
    expect(tiempoRelativo('2026-11-03T11:30:00Z', ahora)).toEqual({ k: 'tiempo.min', n: 30 })
    expect(tiempoRelativo('2026-11-03T09:00:00Z', ahora)).toEqual({ k: 'tiempo.h', n: 3 })
    expect(tiempoRelativo('2026-11-01T12:00:00Z', ahora)).toEqual({ k: 'tiempo.d', n: 2 })
  })
})

async function entrar(u: ReturnType<typeof userEvent.setup>) {
  render(<App />)
  await screen.findByText('Entra a tu cuadra')
  await u.type(screen.getByLabelText('¿Cómo te llamamos?'), 'Yoel')
  await u.type(screen.getByLabelText('Correo'), 'yoel@ejemplo.com')
  await u.click(screen.getByLabelText(/18 años/))
  await u.click(screen.getByRole('button', { name: 'Enviarme el código' }))
  await u.type(await screen.findByLabelText('Código'), '123456')
  await u.click(screen.getByRole('button', { name: 'Entrar' }))
  await u.selectOptions(await screen.findByLabelText('Provincia de Cuba'), 'Camagüey')
  await u.click(screen.getByRole('button', { name: 'Siguiente' }))
  await u.selectOptions(await screen.findByLabelText('Estado de Brasil'), 'RR')
  await u.type(screen.getByPlaceholderText('Escribe para buscar tu ciudad'), 'boa vis')
  await u.click(await screen.findByRole('option', { name: 'Boa Vista' }))
  await u.click(screen.getByRole('button', { name: 'Siguiente' }))
  await u.click(screen.getByRole('button', { name: 'Prefiero no decirlo por ahora' }))
  await u.click(screen.getByRole('button', { name: 'Prefiero no decirlo por ahora' }))
  await u.click(screen.getByRole('button', { name: 'Acabo de llegar' }))
  await u.click(screen.getByRole('button', { name: 'Siguiente' }))
  await u.click(screen.getByRole('button', { name: 'Entrar a mi cuadra' }))
  await screen.findByRole('heading', { name: 'Cuadra de Boa Vista' })
}

describe('social: cuadra, amigos y chat (demo)', () => {
  beforeEach(() => { localStorage.clear(); sessionStorage.clear(); window.location.hash = '' })

  it('publica (el HTML no se ejecuta), da me gusta y comenta', async () => {
    const u = userEvent.setup()
    await entrar(u)
    expect(await screen.findByText(/CPF sin turno/)).toBeInTheDocument() // ejemplo de la ciudad
    await u.type(screen.getByLabelText('Escribe en tu cuadra'), '<img src=x onerror=alert(1)> hola cuadra')
    await u.click(screen.getByRole('button', { name: 'Publicar' }))
    const texto = await screen.findByText(/hola cuadra/)
    expect(texto.textContent).toContain('<img src=x')
    expect(document.querySelector('.cuadra img')).toBeNull()
    const post = texto.closest('article') as HTMLElement
    await u.click(within(post).getByRole('button', { name: /me gusta/ }))
    await waitFor(() => expect(within(post).getByRole('button', { name: /me gusta/ })).toHaveAttribute('aria-pressed', 'true'))
    await u.click(within(post).getByRole('button', { name: /comentarios/ }))
    await u.type(within(post).getByLabelText('Escribe un comentario'), 'buena idea{enter}')
    expect(await within(post).findByText(/buena idea/)).toBeInTheDocument()
  }, 40000)

  it('agrega un paisano y chatea; sin ser amigos no se puede escribir', async () => {
    const u = userEvent.setup()
    await entrar(u)
    await u.click(screen.getAllByRole('link', { name: 'Chat' })[0])
    expect(await screen.findByText(/Aún no tienes amigos/)).toBeInTheDocument()
    const fila = (await screen.findByText('Dayami')).closest('li') as HTMLElement
    await u.click(within(fila).getByRole('button', { name: 'Agregar' }))
    const amigo = (await screen.findAllByText('Dayami'))[0].closest('button') as HTMLElement
    await u.click(amigo)
    await u.type(await screen.findByLabelText('Escribe un mensaje'), 'Hola Dayami{enter}')
    expect(await screen.findByText('Hola Dayami')).toBeInTheDocument()
    expect(await screen.findByText(/Dale, qué bolá|Claro asere|Perfecto|Gracias por escribir/, {}, { timeout: 4000 })).toBeInTheDocument()
  }, 40000)

  it('Mercado: un anuncio normal se publica y uno con señales de estafa queda en revisión', async () => {
    const u = userEvent.setup()
    await entrar(u)
    await u.click(screen.getAllByRole('link', { name: 'Mercado' })[0])
    expect(await screen.findByText(/Bicicleta aro 26/)).toBeInTheDocument()
    await u.click(screen.getByRole('tab', { name: 'Pincha' }))
    expect(screen.getByText(/Nunca pagues por adelantado un empleo/)).toBeInTheDocument()
    await u.click(screen.getByRole('button', { name: 'Publicar en Pincha' }))
    await u.type(screen.getByLabelText('Título'), 'Trabajo desde casa')
    await u.type(screen.getByLabelText('Detalles'), 'Gana dinero fácil, paga la tarifa por adelantado.')
    await u.click(screen.getByRole('button', { name: 'Publicar anuncio' }))
    expect(await screen.findByText(/quedó en revisión/)).toBeInTheDocument()
    expect(await screen.findByText(/En revisión: todavía no lo ve nadie/)).toBeInTheDocument()
  }, 40000)
})
