import { beforeEach, describe, expect, it, vi } from 'vitest'
import { identificador, validarTelefono } from '../src/lib/validate'

describe('entrar con teléfono o correo', () => {
  it('valida el teléfono con código de país', () => {
    expect(validarTelefono('')).toBe('telefono_vacio')
    expect(validarTelefono('hola')).toBe('telefono_invalido')
    expect(validarTelefono('+55 95 99999-9999')).toBeNull()
    expect(validarTelefono('95 99999-9999')).toBeNull() // sin país: se asume Brasil
    expect(validarTelefono('+53 5 123 4567')).toBeNull() // Cuba
    expect(validarTelefono('+55 95 999')).toBe('telefono_invalido')
  })
  it('arma el identificador que viaja al servidor', () => {
    expect(identificador('correo', ' Ana@Correo.COM ', '')).toBe('ana@correo.com')
    expect(identificador('telefono', '', '(95) 99999-9999')).toBe('+5595999999999')
    expect(identificador('telefono', '', '+53 5 123 4567')).toBe('+5351234567')
  })
})

// Servidor real: comprobamos con un cliente falso que se llama como Supabase lo espera.
const signInWithOtp = vi.fn(async () => ({ error: null }))
const verifyOtp = vi.fn(async () => ({ data: { user: { id: 'u1', email: null, phone: '5595999999999' } }, error: null }))
vi.mock('@supabase/supabase-js', () => ({ createClient: () => ({ auth: { signInWithOtp, verifyOtp, getSession: async () => ({ data: { session: null } }) } }) }))

describe('backend real: pide y verifica el código', () => {
  beforeEach(() => { signInWithOtp.mockClear(); verifyOtp.mockClear() })
  it('por correo', async () => {
    const { supabaseBackend } = await import('../src/lib/backend/supabase')
    await supabaseBackend.requestCode('ana@correo.com', 'Ana')
    expect(signInWithOtp).toHaveBeenCalledWith({ email: 'ana@correo.com', options: { shouldCreateUser: true, data: { apodo: 'Ana' }, emailRedirectTo: window.location.origin + import.meta.env.BASE_URL } })
  })
  it('por teléfono (SMS)', async () => {
    const { supabaseBackend } = await import('../src/lib/backend/supabase')
    await supabaseBackend.requestCode('+5595999999999', 'Ana')
    expect(signInWithOtp).toHaveBeenCalledWith({ phone: '+5595999999999', options: { shouldCreateUser: true, data: { apodo: 'Ana' } } })
    const ses = await supabaseBackend.verifyCode('+5595999999999', ' 123456 ')
    expect(verifyOtp).toHaveBeenCalledWith({ phone: '+5595999999999', token: '123456', type: 'sms' })
    expect(ses.userId).toBe('u1'); expect(ses.email).toBe('+5595999999999')
  })
  it('verifica por correo con type email', async () => {
    const { supabaseBackend } = await import('../src/lib/backend/supabase')
    await supabaseBackend.verifyCode('ana@correo.com', '123456')
    expect(verifyOtp).toHaveBeenCalledWith({ email: 'ana@correo.com', token: '123456', type: 'email' })
  })
})
