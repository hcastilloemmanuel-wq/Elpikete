import { describe, expect, it } from 'vitest'
import { FILTROS_VACIOS, SERVICIOS_EJEMPLO, etiquetaReputacion, filtrarServicios, ordenarServicios, sugerirOficios, validarServicio } from '../src/lib/servicios'
import { render, screen } from '@testing-library/react'
import { Tarjeta } from '../src/features/servicios/Tarjeta'

describe('servicios: lógica', () => {
  it('hay 12 ejemplos y todos marcados', () => {
    expect(SERVICIOS_EJEMPLO).toHaveLength(12)
    expect(SERVICIOS_EJEMPLO.every((s) => s.ejemplo)).toBe(true)
  })
  it('sugiere oficios sin importar tildes', () => {
    expect(sugerirOficios('electr')[0]).toBe('Electricista')
    expect(sugerirOficios('MECANI')).toContain('Mecánico')
    expect(sugerirOficios('')).toEqual([])
  })
  it('filtra por ciudad, texto y casillas', () => {
    const bv = filtrarServicios(SERVICIOS_EJEMPLO, { ...FILTROS_VACIOS, ciudad: 1400100 })
    expect(bv).toHaveLength(11)
    expect(filtrarServicios(SERVICIOS_EJEMPLO, { ...FILTROS_VACIOS, texto: 'electricista' })).toHaveLength(1)
    expect(filtrarServicios(SERVICIOS_EJEMPLO, { ...FILTROS_VACIOS, urgencias: true, habla_pt: true }).every((s) => s.urgencias && s.habla_pt)).toBe(true)
    expect(filtrarServicios(SERVICIOS_EJEMPLO, { ...FILTROS_VACIOS, barrio: 'centro' }).length).toBeGreaterThan(0)
  })
  it('un perfil con menos de 3 trabajos se muestra como nuevo y no gana por nota', () => {
    const nuevo = SERVICIOS_EJEMPLO.find((s) => s.apodo === 'Liudmila')!
    expect(etiquetaReputacion(nuevo)).toBe('nuevo')
    const ord = ordenarServicios(SERVICIOS_EJEMPLO, 'reputacion')
    expect(ord[0].promedio).toBe(5)
    expect(ord.indexOf(nuevo)).toBeGreaterThanOrEqual(10)
  })
  it('ordena por trabajos y por rapidez', () => {
    expect(ordenarServicios(SERVICIOS_EJEMPLO, 'trabajos')[0].apodo).toBe('Yosvany')
    expect(ordenarServicios(SERVICIOS_EJEMPLO, 'rapidez')[0].rapidez_min).toBe(5)
  })
  it('valida el formulario', () => {
    const base = { oficio: 'Plomero', descripcion: 'Arreglo salideros y tanques.', zonas: null, precio: null, horario: null, habla_pt: false, domicilio: false, urgencias: false, disponible_hoy: false, mostrar_whatsapp: false }
    expect(validarServicio(base)).toBeNull()
    expect(validarServicio({ ...base, oficio: ' ' })).toBe('servicio_oficio')
    expect(validarServicio({ ...base, descripcion: 'corto' })).toBe('servicio_descripcion')
    expect(validarServicio({ ...base, descripcion: 'x'.repeat(401) })).toBe('servicio_descripcion_larga')
  })
})

describe('servicios: el texto de otros nunca es HTML', () => {
  it('muestra etiquetas como texto, sin crear elementos', () => {
    const s = { ...SERVICIOS_EJEMPLO[0], descripcion: '<img src=x onerror=alert(1)> hola <script>1</script>', apodo: '<b>Hack</b>' }
    const { container } = render(<Tarjeta s={s} />)
    expect(container.querySelector('img')).toBeNull()
    expect(container.querySelector('script')).toBeNull()
    expect(container.querySelector('b')).toBeNull()
    expect(screen.getByText(/<img src=x/)).toBeTruthy()
  })
})
