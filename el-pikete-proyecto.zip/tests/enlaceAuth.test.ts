import { it, expect } from 'vitest'
import { capturarEnlaceAuth, tomarEnlacePendiente } from '../src/lib/enlaceAuth'
it('captura', () => {
  window.history.replaceState(null,'','/Elpikete/#access_token=AA&refresh_token=BB&type=magiclink')
  capturarEnlaceAuth()
  expect(window.location.hash).toBe('#/')
  expect(tomarEnlacePendiente()).toEqual({access_token:'AA',refresh_token:'BB'})
  expect(tomarEnlacePendiente()).toBeNull()
})
