import { describe, expect, it } from 'vitest'
import { aDolares, aReales, cargarTasas, leerTasas } from '../src/lib/cambio'

const ok = { result: 'success', rates: { BRL: 5.4, EUR: 0.9 }, time_last_update_utc: 'hoy' }
describe('cambio', () => {
  it('lee las tasas y rechaza datos raros', () => {
    expect(leerTasas(ok)).toEqual({ brl_por_usd: 5.4, brl_por_eur: 6, actualizado: 'hoy' })
    expect(leerTasas({ result: 'error' })).toBeNull()
    expect(leerTasas({ result: 'success', rates: { BRL: 0, EUR: 1 } })).toBeNull()
    expect(leerTasas(null)).toBeNull()
  })
  it('convierte', () => { expect(aReales(100, 5.4)).toBe(540); expect(aDolares(540, 5.4)).toBe(100) })
  it('si la red falla devuelve null (nunca inventa)', async () => {
    expect(await cargarTasas((async () => { throw new Error('x') }) as unknown as typeof fetch)).toBeNull()
    expect(await cargarTasas((async () => ({ ok: false })) as unknown as typeof fetch)).toBeNull()
    expect(await cargarTasas((async () => ({ ok: true, json: async () => ok })) as unknown as typeof fetch)).not.toBeNull()
  })
})
