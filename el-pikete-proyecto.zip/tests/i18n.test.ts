import { describe, expect, it } from 'vitest'
import { IDIOMAS } from '../src/i18n'

const vars = (s: string) => (s.match(/\{\w+\}/g) ?? []).sort().join(',')
describe('traducciones español / portugués', () => {
  it('portugués tiene exactamente las mismas claves que español', () => {
    expect(Object.keys(IDIOMAS.pt).sort()).toEqual(Object.keys(IDIOMAS.es).sort())
  })
  it('ninguna frase está vacía y las variables coinciden', () => {
    for (const k of Object.keys(IDIOMAS.es)) {
      expect(IDIOMAS.es[k as keyof typeof IDIOMAS.es].trim(), k).not.toBe('')
      expect(IDIOMAS.pt[k as keyof typeof IDIOMAS.pt].trim(), k).not.toBe('')
      expect(vars(IDIOMAS.pt[k as keyof typeof IDIOMAS.pt]), k).toBe(vars(IDIOMAS.es[k as keyof typeof IDIOMAS.es]))
    }
  })
})
