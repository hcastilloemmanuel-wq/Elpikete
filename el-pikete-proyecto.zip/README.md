# El Pikete

La red social de los cubanos en Brasil. Página web instalable (PWA), alojada en GitHub Pages, con Supabase como servidor de datos.

- Puesta en marcha paso a paso: [`docs/GUIA_PUESTA_EN_MARCHA.md`](docs/GUIA_PUESTA_EN_MARCHA.md)
- Plan de construcción por fases: [`docs/PLAN_DE_CONSTRUCCION.md`](docs/PLAN_DE_CONSTRUCCION.md)
- Estado actual: [`docs/PROGRESO.md`](docs/PROGRESO.md)

```
npm install
npm run dev        # servidor local
npm test           # pruebas
npm run build      # versión para publicar
```
Sin claves de Supabase la app corre en modo demostración (código de entrada 123456).
- Para probar sin subir nada: `npm run build:html` y abre `El-Pikete-Prueba.html`.
