// Junta todo (JS, CSS, letras, icono) en UN solo archivo: El-Pikete-Prueba.html
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

const dir = 'dist-single'
let html = readFileSync(join(dir, 'index.html'), 'utf8')
const b64 = (f, mime) => `data:${mime};base64,${readFileSync(f).toString('base64')}`

// CSS (con las letras dentro)
html = html.replace(/<link rel="stylesheet"[^>]*href="\.\/(assets\/[^"]+\.css)"[^>]*>/g, (_, f) => {
  let css = readFileSync(join(dir, f), 'utf8')
  css = css.replace(/url\(["']?(?:\.\.\/|\.\/|\/)?fonts\/([^"')]+)["']?\)/g, (_m, name) => `url(${b64(join(dir, 'fonts', name), 'font/woff')})`)
  return `<style>${css}</style>`
})
// JS (módulo en línea, al final del cuerpo)
let js = ''
html = html.replace(/<script type="module"[^>]*src="\.\/(assets\/[^"]+\.js)"[^>]*><\/script>/g, (_, f) => { js += readFileSync(join(dir, f), 'utf8'); return '' })
html = html.replace(/<link rel="modulepreload"[^>]*>/g, '')
// Icono
const icono = `<link rel="icon" type="image/svg+xml" href="${b64(join(dir, 'favicon.svg'), 'image/svg+xml')}" />`
const toque = `<link rel="apple-touch-icon" href="${b64(join(dir, 'apple-touch-icon.png'), 'image/png')}" />`
const modulo = `<script type="module">${js.replace(/<\/script/gi, '<\\/script')}</script></body>`
// Siempre con funciones: el código tiene "$&" y "$'" que un texto de reemplazo interpretaría mal.
html = html.replace(/<link rel="icon"[^>]*>/, () => icono)
html = html.replace(/<link rel="apple-touch-icon"[^>]*>/, () => toque)
html = html.replace('</body>', () => modulo)

const salida = process.argv[2] ?? 'El-Pikete-Prueba.html'
writeFileSync(salida, html)
console.log('listo:', salida, (html.length / 1024).toFixed(0) + ' KB')
