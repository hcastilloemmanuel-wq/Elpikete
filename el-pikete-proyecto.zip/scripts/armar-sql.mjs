// Junta todo en archivos para pegar de una vez en Supabase.
import { readdirSync, readFileSync, writeFileSync } from 'node:fs'
const migr = readdirSync('supabase/migrations').filter((f) => f.endsWith('.sql')).sort()
const cab = (t) => `-- ============================================================\n-- ${t}\n-- ============================================================\n`
writeFileSync('supabase/SETUP_COMPLETO.sql',
  '-- El Pikete · TODA la base de datos en un solo archivo. Pégalo completo en Supabase > SQL Editor > Run (una sola vez).\n\n' +
  migr.map((f) => cab(f) + readFileSync('supabase/migrations/' + f, 'utf8')).join('\n\n'))
const tests = readdirSync('supabase/tests').filter((f) => f.endsWith('.sql')).sort()
writeFileSync('supabase/SETUP_PRUEBAS.sql',
  '-- El Pikete · pruebas de seguridad. Pégalo DESPUÉS del setup. Cada bloque termina con un aviso "OK"; si algo dice FALLO, no abras la app a gente.\n\n' +
  tests.map((f) => cab(f) + readFileSync('supabase/tests/' + f, 'utf8')).join('\n\n'))
// La función del Socio con las guías ya metidas, para pegar en el panel sin subir archivos.
const guias = readFileSync('supabase/functions/socio/guias.json', 'utf8').trim()
const fn = readFileSync('supabase/functions/socio/index.ts', 'utf8').replace("import guias from './guias.json' with { type: 'json' }", `const guias = ${guias}`)
writeFileSync('supabase/functions/socio/PEGAR_EN_EL_PANEL.ts', fn)
console.log('listo:', migr.length, 'migraciones,', tests.length, 'pruebas')
