# Progreso

## 2026-11-02
- Fase 0 y Fase 1 construidas: proyecto base, PWA, registro de 7 pantallas, sesión por dispositivo, perfil, privacidad, ES/PT, migración SQL y prueba de reglas.
- Verificación: `npm run typecheck`, `npm test` (25 pruebas) y `npm run build` en verde. Primera carga: ~100 KB comprimidos.
- Modo demostración activo mientras no haya claves de Supabase (código 123456).
- Siguiente: Fase 2a (Recién Llegado de Boa Vista).

## Rediseño visual v2 (3 nov 2026)
- Sistema de diseño nuevo (docs/DISENO.md): paleta añil/sol/rojo/mar, Young Serif + Instrument Sans propias, iconografía propia (45 iconos), baldosa cubana como firma, avatares por provincia, tema automático.
- Pantallas rehechas: entrada, registro, inicio, vacíos, perfil. PWA: iconos y colores nuevos.
- Regla para fases siguientes: usar solo estas piezas.

## Versión de prueba en un solo archivo (3 nov 2026)
- `npm run build:html` genera `El-Pikete-Prueba.html` (≈590 KB): toda la app en modo demo en un archivo, sin internet ni servidor. Se abre en el teléfono o el computador. Código de entrada: 123456. Los datos quedan en ese navegador.
- Pulido premium: barra inferior flotante, botones con profundidad, entrada animada del mosaico, detalles del modo oscuro.
- Regla para tareas automáticas: al terminar cada fase, regenerar este archivo con `npm run build:html` y entregarlo junto al zip.

- Arreglo (3 nov): la versión de un solo archivo ya funciona aunque el teléfono bloquee el almacenamiento (Android abriendo desde Descargas). Prueba automática incluida.

- Arreglo (3 nov): dentro del visor de Claude (sin dirección web normal) el enrutador fallaba con "Invalid URL" y la pantalla quedaba en blanco; ahora usa un enrutador en memoria. Probado en iframe aislado.

- Entrada con correo o teléfono (3 nov): selector, validación, backend real con SMS (requiere proveedor), aviso claro de demostración y botón "Poner el código de prueba". 32 pruebas.

## 2026-11-03 · Fase 3a hecha en sesión directa: Servicios
- Pantalla Servicios (carga diferida): buscador con sugerencias de oficios, filtro por ciudad (por defecto la tuya) y barrio, casillas (disponible hoy, habla portugués, domicilio, urgencias), orden por reputación/trabajos/rapidez, tarjeta de servicio, crear/editar/quitar MI servicio, contacto por WhatsApp solo si el profesional lo muestra (función ver_whatsapp).
- Reputación: menos de 3 trabajos = "Nuevo", no compite por nota. Lógica en src/lib/servicios.ts con pruebas.
- Demo: 12 servicios de ejemplo marcados "Ejemplo"; el tuyo se guarda en el teléfono.
- Migración 0004_servicios.sql (RLS: la tabla solo la lee su dueño, los demás usan la vista servicios_publicos; el dueño no puede escribir la reputación) y supabase/tests/servicios_test.sql. NO ejecutados contra un Supabase real todavía.
- Falta de 3a: fotos (módulo src/lib/imagen.ts con WebP + quitar EXIF; el bucket 'servicios' ya está en la migración).
- Pendiente: 3b presupuestos y reseñas, 4 Cuadra/amigos/chat, 6 Bolsa/Pincha, noticias, El Socio.

## 2026-11-03 · Arreglo del login en visores + núcleo social
- Causa real de "Enviar código no hace nada": el visor (iframe sandbox sin allow-forms) bloquea el envío nativo de formularios. Los botones principales ya no dependen de él. Probado en Android/file://, con almacenamiento bloqueado y en iframe sandbox.
- Cuadra (muro por ciudad, orden cronológico): publicar por tipo, me gusta, comentarios, borrar lo mío. Texto siempre como texto (prueba incluida).
- Amigos y Chat: paisanos cerca (nunca modo discreto), solicitud/aceptación, mensajes solo entre amigos con sondeo cada 4 s. En demo, 5 perfiles de ejemplo aceptan y responden.
- Migración 0005_social.sql + supabase/tests/social_test.sql (no ejecutados contra un Supabase real).
- Falta: reportar/bloquear/moderación, reglas de la comunidad en el primer uso, fotos, notificaciones, Bolsa/Pincha, noticias, El Socio, presupuestos/reseñas.

## 2026-11-03 · La Bolsa y Pincha
- Pestaña Mercado: La Bolsa (vendo, compro, alquilo, servicio) y Pincha (ofrezco/busco empleo, jornada, idioma, pago en reales). Buscador, filtro por ciudad y tipo, mis anuncios (cerrar, renovar 30 días), reportar. Aviso fijo en Pincha contra pagos por adelantado.
- Anti-estafa: src/lib/mercado.ts detecta pago por adelantado, giros a terceros, ganancias fáciles y envío de documentos (es/pt). Esos anuncios quedan "en revisión". 3 reportes de personas distintas también lo sacan de circulación.
- Migración 0006_mercado.sql: el servidor aplica la misma revisión (no se puede saltar desde la app), solo se publica por función, 10 anuncios/día, RLS. Prueba supabase/tests/mercado_test.sql (no ejecutada contra Supabase real).
- Falta: fotos, favoritos, cola de moderación, bloquear usuarios, noticias, El Socio, presupuestos/reseñas.

## 2026-11-03 · Todo listo para publicar
- Añadido: reportar/bloquear, 10 reglas de la comunidad (primer uso), cola de moderación (rol moderador), Noticias (dólar del día + prensa independiente con aviso al salir), El Socio (modo básico con guías; con IA vía función de Supabase y límites diario/mensual).
- SQL probado en PostgreSQL 16 real con un simulador de Supabase (roles, auth.uid, RLS): 5 pruebas de seguridad en verde. Encontró y corrigió un fallo real (hay_bloqueo: parámetro con el mismo nombre que una columna).
- Entrega: supabase/SETUP_COMPLETO.sql y SETUP_PRUEBAS.sql (npm run armar:sql), publicar-desde-zip.yml (GitHub construye el zip), PDF con la guía paso a paso.
- Falta: presupuestos y reseñas, fotos (src/lib/imagen.ts), notificaciones, "Recién Llegado" como ruta guiada completa, panel visual de moderación (hoy es una consulta SQL), verificación real contra un Supabase y un GitHub de Emmanuel.
