# Cómo poner El Pikete en internet (paso a paso, desde el teléfono)

Todo es gratis. Tiempo: unos 40 minutos. Hacen falta dos cuentas: **Supabase** (la base de datos) y **GitHub** (la página web). Se hace desde el navegador del teléfono; si puedes, pon el navegador en "Sitio de escritorio".

Qué necesitas tener a mano (te los mandé como archivos):
1. `SETUP_COMPLETO.sql`  (toda la base de datos)
2. `SETUP_PRUEBAS.sql`  (comprueba la seguridad)
3. `el-pikete-proyecto.zip`  (la app)
4. `publicar-desde-zip.yml`  (la orden que publica la página)
5. `PEGAR_EN_EL_PANEL.ts`  (solo para activar la IA de El Socio, opcional)

---

## Parte 1. Supabase (la base de datos)

1. Entra a **supabase.com** y crea una cuenta (puedes usar tu cuenta de GitHub).
2. **New project**. Nombre: `elpikete`. Pon una contraseña de base de datos y guárdala. **Region: South America (São Paulo)**. Espera 1 o 2 minutos.
3. Menú izquierdo: **SQL Editor** → **New query**. Abre `SETUP_COMPLETO.sql`, copia **todo** el texto, pégalo y toca **Run**. Debe decir "Success".
4. Otra **New query**: pega `SETUP_PRUEBAS.sql` y **Run**. Debe mostrar cinco avisos que empiezan con `OK`. Si ves la palabra **FALLO**, no sigas y me escribes.
5. **Authentication → Sign In / Providers → Email**: activado. Si aparece **Confirm email**, desactívalo (usamos código, no enlace).
6. **Authentication → Emails (plantillas)**: en **Magic Link** y en **Confirm signup**, el texto debe llevar `{{ .Token }}`. Ejemplo: `Tu código para entrar a El Pikete es: {{ .Token }}`.
7. **Project Settings → API**: copia dos datos: **Project URL** y la clave **anon public**. (La clave `service_role` NUNCA se copia ni se comparte.)

## Parte 2. GitHub (la página)

1. Entra a **github.com** y crea una cuenta o inicia sesión.
2. **New repository**. Nombre: `elpikete`. **Public**. No marques "Add a README". **Create repository**.
3. En el repositorio nuevo toca **uploading an existing file**. Sube **un solo archivo**: `el-pikete-proyecto.zip` (no lo descomprimas). Abajo toca **Commit changes**.
4. Toca **Add file → Create new file**. En el nombre escribe exactamente: `.github/workflows/publicar.yml` (las barras crean las carpetas solas). Pega dentro todo el texto de `publicar-desde-zip.yml`. **Commit changes**.
5. **Settings → Secrets and variables → Actions → pestaña Variables → New repository variable**. Crea dos:
   - Nombre `VITE_SUPABASE_URL`, valor: el Project URL.
   - Nombre `VITE_SUPABASE_ANON_KEY`, valor: la clave anon public.
6. **Settings → Pages → Build and deployment → Source: GitHub Actions**.
7. Pestaña **Actions**: verás "Publicar El Pikete" corriendo. Si no arrancó, toca **Run workflow**. Cuando salga en verde, tu página queda en
   `https://TU-USUARIO.github.io/elpikete/`
8. Ábrela en el teléfono. Para instalarla como app: Chrome → menú de tres puntos → **Instalar aplicación** (iPhone: Safari → compartir → **Agregar a pantalla de inicio**).

## Parte 3. Unir las dos cosas

En Supabase: **Authentication → URL Configuration**: en **Site URL** pon la dirección de tu página (`https://TU-USUARIO.github.io/elpikete/`).

## Parte 4. Primera prueba (con tu correo)

- [ ] Te registras con tu correo y llega el código de 6 dígitos.
- [ ] Completas tu perfil y entras a la Cuadra. Publicas algo.
- [ ] Con un segundo correo (o el de tu hermana) te registras en la misma ciudad. Se ven las publicaciones y se pueden agregar como amigos y chatear.
- [ ] En Servicios publicas tu servicio; en Mercado publicas un anuncio; se ve desde la otra cuenta.

**Importante sobre los correos:** el servicio de correo gratis de Supabase manda muy pocos mensajes por hora (unos 2). Sirve para que pruebes tú. Para gente de verdad conecta un servicio de correo propio: crea cuenta gratis en **resend.com**, y en Supabase ve a **Project Settings → Authentication → SMTP Settings** y pon los datos de Resend. Entrar con teléfono (SMS) necesita un proveedor de pago (Twilio); mira la sección de abajo.

## Parte 5. Hacerte moderador

Después de registrarte tú, en Supabase → **SQL Editor** pega esto cambiando el apodo por el tuyo y toca Run:

```
insert into public.roles (user_id, rol)
select id, 'moderador' from public.perfiles where apodo = 'TuApodo';
```

Para ver la cola de reportes: SQL Editor → `select * from public.cola_moderacion();`

## Parte 6 (opcional). Activar la inteligencia artificial de El Socio

Sin esto, El Socio responde en "modo básico" con las guías de la app y funciona igual de seguro. Con la IA contesta con más soltura, pero **cuesta dinero por cada mensaje**.
1. Crea una clave en **console.anthropic.com** (necesita saldo prepago). Ponle un tope de gasto mensual allí mismo.
2. Supabase → **Edge Functions → Deploy a new function → Via Editor**. Nombre: `socio`. Pega todo `PEGAR_EN_EL_PANEL.ts`. **Deploy**.
3. Supabase → **Edge Functions → Secrets** → agrega `ANTHROPIC_API_KEY` con tu clave. (Opcional: `SOCIO_LIMITE_DIA` = 30 mensajes por persona al día, `SOCIO_TOPE_MES` = tope de mensajes de toda la app al mes.)
4. La clave nunca va en GitHub ni en la página.

## Cuando compres un dominio
1. Cómpralo (un .com es lo más simple).
2. GitHub → **Settings → Pages → Custom domain**, escribe el dominio y crea los registros DNS que indique GitHub.
3. En **Settings → Variables** crea `VITE_BASE` con valor `/`, y cambia en `publicar.yml` la línea de `VITE_BASE` por `VITE_BASE: /`.

## Cosas que tienes que saber
- **GitHub Pages** no está pensado para negocios: para la beta está bien. Si ganas dinero con la app, se pasa a Cloudflare Pages (mismo código).
- **Supabase gratis** pausa el proyecto si pasa una semana sin uso. Se reactiva con un toque.
- **Cuenta de Supabase y de GitHub son tuyas.** Yo no tengo acceso a ellas; por eso estos pasos los haces tú.
- Si algo falla, copia el mensaje exacto y me lo mandas.

---

## Entrar con correo o con teléfono: qué hay que activar (y qué cuesta)

La app ya permite elegir **correo** o **teléfono**. En la versión de prueba (modo demo) NO se envía nada: el código es siempre `123456`.

**Correo (recomendado para empezar, gratis o casi):**
1. En Supabase: Authentication → Providers → Email activado, "Confirm email" activado.
2. Plantilla del correo con el código: usa `{{ .Token }}` en el mensaje (así llega el código de 6 dígitos y no un enlace).
3. El correo que trae Supabase por defecto manda muy pocos mensajes por hora y es solo para probar. Para uso real conecta un servicio de correo (por ejemplo Resend, que tiene plan gratis): Project Settings → Authentication → SMTP Settings.

**Teléfono por SMS (tiene costo por mensaje):**
1. Supabase no envía SMS por sí solo: hay que conectar un proveedor (Twilio, MessageBird o Vonage) en Authentication → Providers → Phone.
2. Cada SMS se paga al proveedor. Antes de abrir la app al público conviene fijar un límite de gasto.
3. Mientras no esté conectado, elegir "Teléfono" en la versión real dará el error "No pudimos enviar el código". Recomendación: dejar solo correo al lanzar y activar el teléfono cuando haya ingresos.

**Importante:** el envío real de códigos aún NO se ha probado contra un Supabase de verdad (no hay proyecto creado). Está probado que la app hace la llamada correcta; falta comprobarlo en vivo cuando crees el proyecto. Hazlo en este orden: crear proyecto → correr la migración → probar entrar con tu correo.
