# Sistema de diseño de El Pikete (v2)

Regla de oro: **todo lo nuevo se construye con estas piezas. No se inventan colores, letras ni iconos sueltos.**

## Idea
La baldosa hidráulica cubana es la firma de la app: logo, entrada, avatares y pantallas vacías.
Se gasta toda la "valentía" visual en la baldosa; lo demás se mantiene tranquilo y ordenado.

## Colores (variables en `src/styles.css`)
- Añil `#2B3FD4` principal · Sol `#FFC93C` resaltado · Rojo `#E03A3E` alertas · Mar `#0E9F96` confirmaciones
- Cal `#F6F5F0` fondo claro · Noche `#0B0E2A` fondo oscuro · Rosa `#F6B7CB` apoyo
- Tema claro por defecto; oscuro si el teléfono lo pide o el usuario lo elige. Usar SIEMPRE las variables (`--bg`, `--sup`, `--txt`, `--mut`, `--pri`, `--line`), nunca hex sueltos en componentes.

## Letras (guardadas en `public/fonts`, con su licencia OFL)
- Títulos: Young Serif. Texto: Instrument Sans (400 y 700).
- Escala: h1 30 px, h2 20 px, texto 16 px, notas 13 px. Sin mayúsculas sostenidas, sin etiquetas pequeñas decorativas.

## Espacios y formas
- Escala de 4 px: `--s1` 4 · `--s2` 8 · `--s3` 12 · `--s4` 16 · `--s5` 24 · `--s6` 32 · `--s7` 48.
- Radios por jerarquía: `--r-s` 8 · `--r-m` 14 (botones, campos) · `--r-l` 24 (bloques grandes) · `--r-pill`.
- Sin sombras pesadas. No convertir todo en tarjetas iguales: usar filas con línea divisoria cuando alcance.
- Toques mínimos de 44 px; botón principal de 54 px.

## Iconos (`src/ui/Icon.tsx`)
- Familia propia de unos 45 iconos: cuadrícula 24, trazo 1.75, puntas redondas, detalle en color de acento.
- Uso: `<Icon name="servicios" size={24} relleno />`. Si falta uno, se dibuja en ese archivo con las mismas reglas. Prohibidos los emojis.

## Baldosa (`src/ui/Baldosa.tsx`)
- `Baldosa` (una pieza), `BaldosaCampo` (mosaico), `Avatar` (baldosa según provincia, o apodo en modo discreto; el color lo elige la persona).
- 6 diseños y 8 paletas. Cada celda del mosaico se gira de 90 en 90.

## Pantallas base
Entrada con mosaico y hoja que sube · inicio con banner de la cuadra y atajos · barra inferior de 5 pestañas (Cuadra, Servicios, Mercado, Noticias, Chat) · "Yo" desde el avatar · "El Socio" como botón flotante · estados vacíos con mosaico.
