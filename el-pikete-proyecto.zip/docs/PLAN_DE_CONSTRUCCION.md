# Plan de construcción (para quien retome el trabajo)

Lee primero `docs/PROGRESO.md`. Reglas fijas:
1. Todo texto de interfaz va en `src/i18n/es.json` y `pt.json` (mismas claves; hay una prueba que lo exige).
2. Todo contenido de usuarios se muestra como texto, nunca como HTML.
3. Cada tabla nueva: `enable row level security`, `revoke all ... from anon`, políticas mínimas y una prueba en `supabase/tests`.
4. Antes de dar una fase por terminada: `npm run typecheck && npm test && npm run build` en verde y actualizar `docs/PROGRESO.md`.
5. Funciona en teléfono de gama baja: primera carga menos de 200 KB comprimidos; módulos por ruta con carga diferida.
6. Español cubano natural y de hoy. Sin caricatura. Ver glosario del documento maestro.
7. No se descargan ni ejecutan herramientas de terceros desconocidas.

## Fase 0. Cimientos ✅
Proyecto Vite + React + TypeScript, PWA, HashRouter, listas de Cuba y Brasil (IBGE), flujo de GitHub Pages, guía de puesta en marcha.

## Fase 1. Entrar y existir ✅ (beta)
Registro de 7 pantallas, sesión por dispositivo, perfil, privacidad, descargar y borrar datos, ES/PT, migración SQL con reglas y prueba de reglas.
Pendiente de esta fase: subida de foto con borrado de metadatos (necesita Storage), verificación Turnstile en el registro, aviso por correo de nuevo dispositivo.

## Fase 2. Valor sin multitud
- 2a. Recién Llegado: datos en `src/data/guias/*.json` (8 etapas, tarjetas con qué es, dónde, qué llevar, costo, tiempo, errores, enlace oficial, fecha de revisión). Pantalla de ruta con porcentaje de avance guardado (`progreso_guia`). Empezar por Boa Vista. Cada dato oficial con fuente y la frase "según gov.br, a fecha de".
- 2b. Noticias: función de Supabase `noticias` (RSS de CiberCuba, 14ymedio, elTOQUE, Diario de Cuba, CubaNet, Martí Noticias), tabla `noticias`, agrupación de repetidas, etiqueta confirmada / un solo medio / sin confirmar por regla fija, pantalla con filtros.
- 2c. Panel del dólar: función `tasas`, tabla `tasas`, gráfica 30 días, calculadora.
- 2d. El Socio básico: función `socio` (clave de IA en secretos de Supabase), límite diario por usuario, tope mensual, respuestas solo desde la base de guías.

## Fase 3. Servicios
Tablas `servicios`, `solicitudes`, `presupuestos`, `resenas`; buscador por ciudad y oficio; pedir presupuesto; reseñas solo de contrataciones confirmadas; sello de confianza.

## Fase 4. Cuadra y chat
`publicaciones`, `comentarios`, `conversaciones`, `mensajes` con Realtime; notas de voz; amigos; bloquear y reportar.

## Fase 5. El Socio completo
Traducir, currículo en portugués, buscar por voz, presentar paisanos, 30 preguntas de prueba.

## Fase 6. La Bolsa y Pincha
`anuncios`, `ofertas_trabajo`, `candidaturas`; rechazo automático de ofertas que pidan dinero.

## Fase 7. Beta cerrada (20 usuarios en Boa Vista)
## Fase 8. Lanzamiento, mapa, verificación, segunda ciudad

## Regla fija de diseño (obligatoria en TODA fase)
Antes de crear o cambiar cualquier pantalla, lee `docs/DISENO.md` y úsalo tal cual: colores solo con variables CSS, letras Young Serif / Instrument Sans, espacios de la escala, iconos solo de `src/ui/Icon.tsx` (si falta uno, dibújalo ahí con las mismas reglas), baldosas y avatares de `src/ui/Baldosa.tsx`, estados vacíos con mosaico. Prohibido: emojis, mayúsculas sostenidas en etiquetas, colores sueltos, tarjetas idénticas para todo. Al terminar cada pantalla, hazle captura con Playwright en tamaño de teléfono (390 px), en modo claro y oscuro, MÍRALA y corrige lo que se vea mal antes de dar la fase por hecha.
