import { HashRouter, MemoryRouter, Navigate, Route, Routes } from 'react-router-dom'
import { lazy, Suspense } from 'react'
import type { ReactNode } from 'react'
import { AuthProvider } from './features/auth/AuthProvider'
import Login from './features/auth/Login'
import Onboarding from './features/onboarding/Onboarding'
import Me from './features/profile/Me'
import Home from './features/shell/Home'
import Layout from './features/shell/Layout'

const Cuadra = lazy(() => import('./features/cuadra/Cuadra'))
const Mercado = lazy(() => import('./features/mercado/Mercado'))
const Noticias = lazy(() => import('./features/noticias/Noticias'))
const Chat = lazy(() => import('./features/chat/Chat'))
const Servicios = lazy(() => import('./features/servicios/Servicios'))

/**
 * HashRouter: funciona en GitHub Pages sin errores 404 al recargar y sin importar la ruta base.
 * Dentro de un visor que no da una dirección web normal (about:srcdoc, blob:, etc.) el enrutador
 * del navegador falla con "Invalid URL"; ahí usamos uno en memoria.
 */
function Enrutador({ children }: { children: ReactNode }) {
  const normal = ['http:', 'https:', 'file:'].includes(window.location.protocol)
  return normal ? <HashRouter>{children}</HashRouter> : <MemoryRouter>{children}</MemoryRouter>
}

export default function App() {
  return (
    <Enrutador>
      <AuthProvider>
        <Routes>
          <Route path="/entrar" element={<Login />} />
          <Route path="/registro" element={<Onboarding />} />
          <Route element={<Layout />}>
            <Route index element={<Suspense fallback={<p className="fino">…</p>}><Cuadra /></Suspense>} />
            <Route path="inicio" element={<Home />} />
            <Route path="servicios" element={<Suspense fallback={<p className="fino">…</p>}><Servicios /></Suspense>} />
            <Route path="mercado" element={<Suspense fallback={<p className="fino">…</p>}><Mercado /></Suspense>} />
            <Route path="noticias" element={<Suspense fallback={<p className="fino">…</p>}><Noticias /></Suspense>} />
            <Route path="chat" element={<Suspense fallback={<p className="fino">…</p>}><Chat /></Suspense>} />
            <Route path="yo" element={<Me />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </Enrutador>
  )
}
