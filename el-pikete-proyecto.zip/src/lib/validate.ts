/** Validaciones puras: se prueban en tests/validate.test.ts */

export function validarApodo(v: string): string | null {
  const t = v.trim()
  if (t.length < 2) return 'apodo_corto'
  if (t.length > 30) return 'apodo_largo'
  if (/https?:|www\.|@|\.com|\.br/i.test(t)) return 'apodo_enlace'
  return null
}

export function validarCorreo(v: string): string | null {
  const t = v.trim()
  if (!t) return 'correo_vacio'
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(t)) return 'correo_invalido'
  return null
}

/**
 * Devuelve solo dígitos (formato internacional sin "+").
 * Con "+" o "00" se respeta el país escrito (ej. +53 de Cuba). Sin ellos y con 10 u 11 dígitos se asume Brasil (+55).
 */
export function normalizarWhatsapp(v: string): string {
  const t = v.trim()
  const internacional = t.startsWith('+') || t.startsWith('00')
  const d = t.replace(/\D/g, '').replace(/^00/, '')
  if (!internacional && (d.length === 10 || d.length === 11)) return '55' + d
  return d
}

export function validarWhatsapp(v: string): string | null {
  if (!v.trim()) return null
  const d = normalizarWhatsapp(v)
  if (!/^[1-9][0-9]{7,14}$/.test(d)) return 'whatsapp_invalido'
  if (d.startsWith('55') && d.length !== 12 && d.length !== 13) return 'whatsapp_invalido'
  return null
}

/** Teléfono para entrar con SMS: con código de país (+55 Brasil, +53 Cuba). */
export function validarTelefono(v: string): string | null {
  if (!v.trim()) return 'telefono_vacio'
  return validarWhatsapp(v) ? 'telefono_invalido' : null
}

/** Identificador que viaja al backend: el correo en minúsculas o el teléfono en formato +5595999999999. */
export function identificador(via: 'correo' | 'telefono', correo: string, telefono: string): string {
  return via === 'correo' ? correo.trim().toLowerCase() : '+' + normalizarWhatsapp(telefono)
}

export function validarCodigo(v: string): string | null {
  return /^\d{6}$/.test(v.trim()) ? null : 'codigo_invalido'
}

export function normalizarTexto(v: string): string {
  return v.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
}
