/** Tasas del día (API pública con CORS abierto). Si falla, la pantalla lo dice: nunca inventa números. */
export interface Tasas { brl_por_usd: number; brl_por_eur: number; actualizado: string }
const URL_TASAS = 'https://open.er-api.com/v6/latest/USD'

export function leerTasas(d: unknown): Tasas | null {
  const o = d as { result?: string; rates?: Record<string, number>; time_last_update_utc?: string }
  const brl = o?.rates?.BRL, eur = o?.rates?.EUR
  if (o?.result !== 'success' || !brl || !eur || !(brl > 0) || !(eur > 0)) return null
  return { brl_por_usd: brl, brl_por_eur: brl / eur, actualizado: o.time_last_update_utc ?? '' }
}
export async function cargarTasas(f: typeof fetch = fetch): Promise<Tasas | null> {
  try {
    const r = await f(URL_TASAS)
    if (!r.ok) return null
    return leerTasas(await r.json())
  } catch { return null }
}
export function aReales(monto: number, tasa: number): number { return Math.round(monto * tasa * 100) / 100 }
export function aDolares(reales: number, tasa: number): number { return Math.round((reales / tasa) * 100) / 100 }

export const FUENTES = [
  { id: 'eltoque', nombre: 'elTOQUE', url: 'https://eltoque.com' },
  { id: '14ymedio', nombre: '14ymedio', url: 'https://www.14ymedio.com' },
  { id: 'cubanet', nombre: 'CubaNet', url: 'https://www.cubanet.org' },
  { id: 'diariodecuba', nombre: 'Diario de Cuba', url: 'https://diariodecuba.com' },
  { id: 'cibercuba', nombre: 'CiberCuba', url: 'https://www.cibercuba.com' },
  { id: 'marti', nombre: 'Martí Noticias', url: 'https://www.radiotelevisionmarti.com' },
  { id: 'havana', nombre: 'Havana Times', url: 'https://havanatimes.org' },
] as const
