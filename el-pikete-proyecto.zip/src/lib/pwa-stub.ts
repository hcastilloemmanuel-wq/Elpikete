/** Sustituto para la versión de un solo archivo (sin service worker). */
type Par = [boolean, (v: boolean) => void]
export function useRegisterSW(): { needRefresh: Par; offlineReady: Par; updateServiceWorker: (recargar?: boolean) => Promise<void> } {
  const par: Par = [false, () => {}]
  return { needRefresh: par, offlineReady: par, updateServiceWorker: async () => {} }
}
