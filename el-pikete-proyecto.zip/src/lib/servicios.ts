import { OFICIOS_PLANOS } from './data'

/** Un servicio que ofrece un paisano (electricista, barbero, dulces por encargo…). */
export interface Servicio {
  id: string
  user_id: string
  apodo: string
  provincia_cuba: string | null
  avatar_color: string
  oficio: string
  descripcion: string
  ciudad_ibge: number
  ciudad_nombre: string
  barrio: string | null
  zonas: string | null
  precio: string | null
  horario: string | null
  habla_pt: boolean
  domicilio: boolean
  urgencias: boolean
  disponible_hoy: boolean
  mostrar_whatsapp: boolean
  trabajos: number
  rapidez_min: number | null
  resenas: number
  promedio: number | null
  ejemplo?: boolean
}

export type BorradorServicio = Pick<Servicio,
  'oficio' | 'descripcion' | 'zonas' | 'precio' | 'horario' | 'habla_pt' | 'domicilio' | 'urgencias' | 'disponible_hoy' | 'mostrar_whatsapp'>

export interface Filtros {
  texto: string
  ciudad: number | null
  barrio: string
  habla_pt: boolean
  domicilio: boolean
  urgencias: boolean
  disponible_hoy: boolean
}
export const FILTROS_VACIOS: Filtros = { texto: '', ciudad: null, barrio: '', habla_pt: false, domicilio: false, urgencias: false, disponible_hoy: false }

export type Orden = 'reputacion' | 'trabajos' | 'rapidez'

const sinTildes = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim()

/** Sugerencias de oficio mientras se escribe (sin tildes, empieza por o contiene). */
export function sugerirOficios(texto: string, max = 6): string[] {
  const q = sinTildes(texto)
  if (q.length < 1) return []
  const empieza = OFICIOS_PLANOS.filter((o) => sinTildes(o).startsWith(q))
  const contiene = OFICIOS_PLANOS.filter((o) => !sinTildes(o).startsWith(q) && sinTildes(o).includes(q))
  return [...empieza, ...contiene].slice(0, max)
}

export function filtrarServicios(lista: Servicio[], f: Filtros): Servicio[] {
  const q = sinTildes(f.texto)
  const b = sinTildes(f.barrio)
  return lista.filter((s) => {
    if (f.ciudad != null && s.ciudad_ibge !== f.ciudad) return false
    if (b && !sinTildes(s.barrio ?? '').includes(b) && !sinTildes(s.zonas ?? '').includes(b)) return false
    if (f.habla_pt && !s.habla_pt) return false
    if (f.domicilio && !s.domicilio) return false
    if (f.urgencias && !s.urgencias) return false
    if (f.disponible_hoy && !s.disponible_hoy) return false
    if (q && !sinTildes(s.oficio).includes(q) && !sinTildes(s.descripcion).includes(q)) return false
    return true
  })
}

/** Reputación sencilla: el promedio solo pesa cuando hay reseñas suficientes. */
export function etiquetaReputacion(s: Pick<Servicio, 'trabajos' | 'promedio'>): 'nuevo' | 'con_nota' {
  return s.trabajos < 3 || s.promedio == null ? 'nuevo' : 'con_nota'
}

export function ordenarServicios(lista: Servicio[], orden: Orden): Servicio[] {
  const copia = [...lista]
  const nota = (s: Servicio) => (etiquetaReputacion(s) === 'con_nota' ? (s.promedio as number) : 0)
  const rap = (s: Servicio) => s.rapidez_min ?? Number.MAX_SAFE_INTEGER
  if (orden === 'trabajos') copia.sort((a, b) => b.trabajos - a.trabajos || nota(b) - nota(a))
  else if (orden === 'rapidez') copia.sort((a, b) => rap(a) - rap(b) || b.trabajos - a.trabajos)
  else copia.sort((a, b) => nota(b) - nota(a) || b.trabajos - a.trabajos)
  return copia
}

/** Devuelve el código de error (clave i18n "err.<codigo>") o null si está bien. */
export function validarServicio(b: BorradorServicio): string | null {
  if (!b.oficio.trim()) return 'servicio_oficio'
  if (b.descripcion.trim().length < 10) return 'servicio_descripcion'
  if (b.descripcion.length > 400) return 'servicio_descripcion_larga'
  if ((b.precio ?? '').length > 60 || (b.horario ?? '').length > 60 || (b.zonas ?? '').length > 120) return 'servicio_largo'
  return null
}

const EJ = (n: number, o: Partial<Servicio> & Pick<Servicio, 'apodo' | 'oficio' | 'descripcion'>): Servicio => ({
  id: `ejemplo-${n}`, user_id: `ejemplo-${n}`, provincia_cuba: null, avatar_color: '#2B3FD4',
  ciudad_ibge: 1400100, ciudad_nombre: 'Boa Vista', barrio: null, zonas: null, precio: null, horario: null,
  habla_pt: false, domicilio: false, urgencias: false, disponible_hoy: false, mostrar_whatsapp: false,
  trabajos: 0, rapidez_min: null, resenas: 0, promedio: null, ejemplo: true, ...o,
})

/** Datos de ejemplo del modo demostración. Todos marcados como "ejemplo": no son personas reales. */
export const SERVICIOS_EJEMPLO: Servicio[] = [
  EJ(1, { apodo: 'Yunior', provincia_cuba: 'Camagüey', avatar_color: '#FFC93C', oficio: 'Electricista', descripcion: 'Instalaciones, cortocircuitos y cambio de breakers. Trabajo limpio y con garantía.', barrio: 'Centro', zonas: 'Centro, São Pedro, Asa Branca', precio: 'Desde R$ 80 la visita', horario: 'Lun a sáb, 8 a 18', habla_pt: true, domicilio: true, urgencias: true, disponible_hoy: true, trabajos: 14, rapidez_min: 25, resenas: 11, promedio: 4.8 }),
  EJ(2, { apodo: 'Dayami', provincia_cuba: 'Santiago de Cuba', avatar_color: '#F6B7CB', oficio: 'Manicura', descripcion: 'Uñas acrílicas y semipermanente. Atiendo en mi casa o voy a la tuya.', barrio: 'Pintolândia', precio: 'R$ 60 a R$ 120', horario: 'Todos los días, tarde', habla_pt: true, domicilio: true, disponible_hoy: true, trabajos: 31, rapidez_min: 15, resenas: 24, promedio: 4.9 }),
  EJ(3, { apodo: 'Raúl', provincia_cuba: 'La Habana', avatar_color: '#0E9F96', oficio: 'Plomero', descripcion: 'Salideros, destupiciones, instalación de tanques y griferías.', barrio: 'Cinturão Verde', zonas: 'Toda la ciudad', precio: 'Presupuesto gratis', horario: 'Lun a sáb', domicilio: true, urgencias: true, trabajos: 9, rapidez_min: 60, resenas: 6, promedio: 4.5 }),
  EJ(4, { apodo: 'Lázaro', provincia_cuba: 'Matanzas', avatar_color: '#E03A3E', oficio: 'Barbero', descripcion: 'Cortes clásicos, degradé y barba. Cuba en la navaja.', barrio: 'Mecejana', precio: 'R$ 35', horario: 'Mar a dom, 10 a 20', habla_pt: true, disponible_hoy: true, trabajos: 58, rapidez_min: 10, resenas: 40, promedio: 4.7 }),
  EJ(5, { apodo: 'Mailén', provincia_cuba: 'Holguín', avatar_color: '#2B3FD4', oficio: 'Dulces por encargo', descripcion: 'Cakes, pastelitos de guayaba y turrones. Pedidos con 2 días de anticipación.', barrio: 'Caçari', precio: 'Desde R$ 40', horario: 'Pedidos por la mañana', habla_pt: true, domicilio: true, trabajos: 22, rapidez_min: 40, resenas: 17, promedio: 4.9 }),
  EJ(6, { apodo: 'Osmany', provincia_cuba: 'Villa Clara', avatar_color: '#7A4FD0', oficio: 'Mecánico', descripcion: 'Motor, frenos, suspensión y diagnóstico con escáner. Carros y motos.', barrio: 'Distrito Industrial', precio: 'Diagnóstico R$ 50', horario: 'Lun a vie, 8 a 17', habla_pt: true, trabajos: 17, rapidez_min: 90, resenas: 12, promedio: 4.6 }),
  EJ(7, { apodo: 'Yaneisy', provincia_cuba: 'Granma', avatar_color: '#F28A2E', oficio: 'Limpieza de casas', descripcion: 'Limpieza profunda y mudanzas. Llevo mis productos.', zonas: 'Centro y alrededores', precio: 'R$ 150 por día', horario: 'Lun a sáb', habla_pt: true, domicilio: true, disponible_hoy: true, trabajos: 6, rapidez_min: 30, resenas: 4, promedio: 5 }),
  EJ(8, { apodo: 'Ernesto', provincia_cuba: 'Cienfuegos', avatar_color: '#3E9B4F', oficio: 'Instalador de aire acondicionado', descripcion: 'Instalación y limpieza de splits. Con herramienta propia.', barrio: 'Paraviana', precio: 'Instalación R$ 350', horario: 'Lun a sáb', habla_pt: true, domicilio: true, urgencias: true, trabajos: 26, rapidez_min: 45, resenas: 19, promedio: 4.7 }),
  EJ(9, { apodo: 'Liudmila', provincia_cuba: 'Pinar del Río', avatar_color: '#FFC93C', oficio: 'Peluquera', descripcion: 'Corte, tinte, alisado y peinados. Atiendo con cita.', barrio: 'Aeroporto', precio: 'Desde R$ 50', horario: 'Mar a sáb', habla_pt: true, trabajos: 2, rapidez_min: 20, resenas: 2, promedio: 5 }),
  EJ(10, { apodo: 'Alexei', provincia_cuba: 'Las Tunas', avatar_color: '#E03A3E', oficio: 'Pintor', descripcion: 'Casas por dentro y por fuera, resanes y textura.', zonas: 'Boa Vista y Cantá', precio: 'Por metro, te cotizo', horario: 'Lun a sáb', domicilio: true, trabajos: 0 }),
  EJ(11, { apodo: 'Yosvany', provincia_cuba: 'Artemisa', avatar_color: '#0E9F96', oficio: 'Mensajero', descripcion: 'Entregas en moto por toda la ciudad, paquetes y comida.', zonas: 'Toda la ciudad', precio: 'Desde R$ 12', horario: 'Todos los días', habla_pt: true, domicilio: true, disponible_hoy: true, trabajos: 73, rapidez_min: 5, resenas: 52, promedio: 4.6 }),
  EJ(12, { apodo: 'Marisel', provincia_cuba: 'Sancti Spíritus', avatar_color: '#2B3FD4', oficio: 'Traductor', descripcion: 'Traducción de documentos y acompañamiento en trámites (portugués-español).', ciudad_ibge: 1302603, ciudad_nombre: 'Manaus', precio: 'R$ 40 por página', horario: 'Por correo, todo el día', habla_pt: true, trabajos: 12, rapidez_min: 120, resenas: 9, promedio: 4.8 }),
]
