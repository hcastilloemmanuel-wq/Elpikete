import estados from '../data/estados_br.json'
import oficiosJson from '../data/oficios.json'

export const PROVINCIAS_CUBA = [
  'Pinar del Río', 'Artemisa', 'La Habana', 'Mayabeque', 'Matanzas', 'Cienfuegos', 'Villa Clara',
  'Sancti Spíritus', 'Ciego de Ávila', 'Camagüey', 'Las Tunas', 'Holguín', 'Granma', 'Santiago de Cuba',
  'Guantánamo', 'Isla de la Juventud',
] as const

export interface Estado { uf: string; codigo: number; nombre: string }
export const ESTADOS_BR = estados as Estado[]

export type Ciudad = { ibge: number; nombre: string }
const loaders = import.meta.glob<{ default: [number, string][] }>('../data/ciudades/*.json')

export async function ciudadesDe(uf: string): Promise<Ciudad[]> {
  const key = `../data/ciudades/${uf}.json`
  const load = loaders[key]
  if (!load) return []
  const mod = await load()
  return mod.default.map(([ibge, nombre]) => ({ ibge, nombre }))
}

export const OFICIOS = oficiosJson as Record<string, string[]>
export const OFICIOS_PLANOS = Object.values(OFICIOS).flat()

export const PROPOSITOS = ['llegue', 'pincha', 'servicio', 'gente', 'noticias', 'mercado'] as const
export type Proposito = (typeof PROPOSITOS)[number]

export function nombreEstado(uf: string | null): string {
  return ESTADOS_BR.find((e) => e.uf === uf)?.nombre ?? ''
}
