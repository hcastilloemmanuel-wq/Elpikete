export const BASE = import.meta.env.BASE_URL
export const SUPABASE_URL: string | undefined = import.meta.env.VITE_SUPABASE_URL || undefined
export const SUPABASE_ANON_KEY: string | undefined = import.meta.env.VITE_SUPABASE_ANON_KEY || undefined
export const TURNSTILE_SITE_KEY: string | undefined = import.meta.env.VITE_TURNSTILE_SITE_KEY || undefined
export const DEMO_MODE = !SUPABASE_URL || !SUPABASE_ANON_KEY
export const DEMO_CODE = '123456'
