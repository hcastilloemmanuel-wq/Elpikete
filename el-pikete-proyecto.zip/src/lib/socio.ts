import guiasJson from '../data/guias.json'

export interface Guia { id: string; titulo: string; claves: string[]; texto: string; oficial: string }
export const GUIAS = guiasJson as Guia[]

const norm = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()

/** Peticiones que El Socio nunca atiende: localizar o exponer a otras personas. */
const PROHIBIDO = /(donde vive|d[oó]nde (vive|est[aá])|direcci[oó]n de|tel[eé]fono de|n[uú]mero de (tel|cel|whats)|busca a|encuentra a|localiza|rastrea|datos de (otro|otra|un|una)|onde (mora|vive)|endere[cç]o de)/i
export type Respuesta = { tipo: 'guia' | 'rechazo' | 'sin_dato'; texto: string; guia?: Guia }

export function puntuar(consulta: string, g: Guia): number {
  const q = norm(consulta)
  let p = 0
  for (const c of g.claves) if (q.includes(norm(c))) p += c.includes(' ') ? 3 : 2
  return p
}

/** Modo demostración: busca la tarjeta de guía que mejor responde. Si no hay nada, lo dice. */
export function responderDemo(consulta: string): Respuesta {
  if (PROHIBIDO.test(consulta)) return { tipo: 'rechazo', texto: 'socio.rechazo' }
  const mejor = [...GUIAS].map((g) => ({ g, p: puntuar(consulta, g) })).sort((a, b) => b.p - a.p)[0]
  if (!mejor || mejor.p === 0) return { tipo: 'sin_dato', texto: 'socio.sin_dato' }
  return { tipo: 'guia', texto: mejor.g.texto, guia: mejor.g }
}
export const PREGUNTAS_EJEMPLO = ['socio.ej1', 'socio.ej2', 'socio.ej3']
