import { createClient } from '@supabase/supabase-js'
import type { SupabaseClient } from '@supabase/supabase-js'
import { SUPABASE_ANON_KEY, SUPABASE_URL } from '../config'
import { sessionAdapter } from '../storage'
import type { Servicio } from '../servicios'
import { responderDemo } from '../socio'
import type { Anuncio } from '../mercado'
import type { Amistad, Comentario, Mensaje, Persona, Publicacion } from '../social'
import { BackendError } from './types'
import type { Backend, Contacto, Perfil, Sesion } from './types'

/**
 * Backend real. La clave "anon" es pública por diseño: la seguridad la ponen las reglas (RLS) de la base de datos.
 * La sesión se guarda con sessionAdapter: solo en este dispositivo, y solo mientras la pestaña si es dispositivo compartido.
 */
let cliente: SupabaseClient | null = null
function sb(): SupabaseClient {
  if (!cliente) {
    cliente = createClient(SUPABASE_URL as string, SUPABASE_ANON_KEY as string, {
      auth: { storage: sessionAdapter, persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
    })
  }
  return cliente
}
const aSesion = (u: { id: string; email?: string | null; phone?: string | null } | undefined | null): Sesion | null => (u ? { userId: u.id, email: u.email || (u.phone ? '+' + u.phone.replace(/^\+/, '') : '') } : null)
const esTelefono = (id: string) => id.startsWith('+')
function falla(e: { message?: string; status?: number } | null, code: string): never { throw new BackendError(code, e?.message) }

async function uid(): Promise<string> {
  const { data } = await sb().auth.getSession()
  if (!data.session) throw new BackendError('sin_sesion')
  return data.session.user.id
}

export const supabaseBackend: Backend = {
  mode: 'supabase',
  async getSession() { const { data } = await sb().auth.getSession(); return aSesion(data.session?.user) },
  onAuthChange(cb) {
    const { data } = sb().auth.onAuthStateChange((_ev, session) => cb(aSesion(session?.user)))
    return () => data.subscription.unsubscribe()
  },
  async requestCode(id, apodo) {
    const opciones = { shouldCreateUser: true, data: { apodo } }
    const { error } = await sb().auth.signInWithOtp(esTelefono(id) ? { phone: id, options: opciones } : { email: id, options: opciones })
    if (error) falla(error, error.status === 429 ? 'demasiados_intentos' : 'no_se_envio')
  },
  async verifyCode(id, code) {
    const token = code.trim()
    const { data, error } = await sb().auth.verifyOtp(esTelefono(id) ? { phone: id, token, type: 'sms' } : { email: id, token, type: 'email' })
    if (error || !data.user) falla(error, 'codigo_incorrecto')
    return aSesion(data.user) as Sesion
  },
  async signOut(scope) { await sb().auth.signOut({ scope }) },
  async getPerfil() {
    const id = await uid()
    const { data, error } = await sb().from('perfiles').select('*').eq('id', id).maybeSingle()
    if (error) falla(error, 'perfil_no_disponible')
    return (data as Perfil | null) ?? null
  },
  async savePerfil(patch) {
    const id = await uid()
    const { data, error } = await sb().from('perfiles').update(patch).eq('id', id).select().single()
    if (error) falla(error, 'no_se_guardo')
    return data as Perfil
  },
  async getContacto() {
    const id = await uid()
    const { data, error } = await sb().from('contactos_privados').select('whatsapp, whatsapp_visibilidad').eq('user_id', id).maybeSingle()
    if (error) falla(error, 'no_disponible')
    return (data as Contacto | null) ?? { whatsapp: null, whatsapp_visibilidad: 'nadie' }
  },
  async saveContacto(c) {
    const id = await uid()
    const { data, error } = await sb().from('contactos_privados').upsert({ user_id: id, ...c }).select('whatsapp, whatsapp_visibilidad').single()
    if (error) falla(error, 'no_se_guardo')
    return data as Contacto
  },
  async listServicios() {
    const { data, error } = await sb().from('servicios_publicos').select('*').limit(300)
    if (error) falla(error, 'no_disponible')
    return (data ?? []) as Servicio[]
  },
  async getMiServicio() {
    const id = await uid()
    const { data, error } = await sb().from('servicios_publicos').select('*').eq('user_id', id).maybeSingle()
    if (error) falla(error, 'no_disponible')
    return (data as Servicio | null) ?? null
  },
  async saveMiServicio(b) {
    const id = await uid()
    const { error } = await sb().from('servicios').upsert({ user_id: id, ...b, activo: true }, { onConflict: 'user_id' })
    if (error) falla(error, 'no_se_guardo')
    const mi = await this.getMiServicio()
    if (!mi) throw new BackendError('no_se_guardo')
    return mi
  },
  async deleteMiServicio() {
    const id = await uid()
    const { error } = await sb().from('servicios').delete().eq('user_id', id)
    if (error) falla(error, 'no_se_guardo')
  },
  async verWhatsapp(userId) {
    const { data, error } = await sb().rpc('ver_whatsapp', { objetivo: userId })
    if (error) falla(error, 'no_disponible')
    return (data as string | null) ?? null
  },
  async listPosts() {
    const { data, error } = await sb().from('cuadra_muro').select('*').order('creado_en', { ascending: false }).limit(100)
    if (error) falla(error, 'no_disponible')
    return (data ?? []).map((r) => ({
      id: r.id, tipo: r.tipo, texto: r.texto, creado_en: r.creado_en, comentarios: Number(r.comentarios), likes: Number(r.likes), yo_like: !!r.yo_like,
      autor: { id: r.user_id, apodo: r.apodo, provincia_cuba: r.provincia_cuba, avatar_color: r.avatar_color, ciudad_nombre: r.ciudad_nombre },
    })) as Publicacion[]
  },
  async createPost(tipo, texto) {
    const id = await uid()
    const perfil = await this.getPerfil()
    const { error } = await sb().from('publicaciones').insert({ user_id: id, ciudad_ibge: perfil?.ciudad_ibge, tipo, texto: texto.trim() })
    if (error) falla(error, 'no_se_guardo')
  },
  async deletePost(id) { const { error } = await sb().from('publicaciones').delete().eq('id', id); if (error) falla(error, 'no_se_guardo') },
  async toggleLike(id) {
    const u = await uid()
    const { data } = await sb().from('me_gusta').select('post_id').eq('post_id', id).eq('user_id', u).maybeSingle()
    const { error } = data ? await sb().from('me_gusta').delete().eq('post_id', id).eq('user_id', u) : await sb().from('me_gusta').insert({ post_id: id, user_id: u })
    if (error) falla(error, 'no_se_guardo')
  },
  async listComments(postId) {
    const { data, error } = await sb().from('cuadra_comentarios').select('*').eq('post_id', postId).order('creado_en')
    if (error) falla(error, 'no_disponible')
    return (data ?? []).map((r) => ({ id: r.id, texto: r.texto, creado_en: r.creado_en, autor: { id: r.user_id, apodo: r.apodo, provincia_cuba: r.provincia_cuba, avatar_color: r.avatar_color, ciudad_nombre: null } })) as Comentario[]
  },
  async addComment(postId, texto) {
    const u = await uid()
    const { error } = await sb().from('comentarios').insert({ post_id: postId, user_id: u, texto: texto.trim() })
    if (error) falla(error, 'no_se_guardo')
  },
  async reportarPost(id) { const { error } = await sb().rpc('reportar_post', { post: id }); if (error) falla(error, 'no_se_guardo') },
  async bloquear(userId) { const { error } = await sb().rpc('bloquear_usuario', { objetivo: userId }); if (error) falla(error, 'no_se_guardo') },
  async listPaisanos() {
    const { data, error } = await sb().rpc('paisanos_cerca')
    if (error) falla(error, 'no_disponible')
    const am = await this.listAmistades()
    const ya = new Set(am.map((a) => a.persona.id))
    return ((data ?? []) as Persona[]).filter((p) => !ya.has(p.id))
  },
  async listAmistades() {
    const { data, error } = await sb().rpc('mis_amistades')
    if (error) falla(error, 'no_disponible')
    return ((data ?? []) as (Persona & { estado: Amistad['estado'] })[]).map((r) => ({ estado: r.estado, persona: { id: r.id, apodo: r.apodo, provincia_cuba: r.provincia_cuba, avatar_color: r.avatar_color, ciudad_nombre: r.ciudad_nombre } })) as Amistad[]
  },
  async pedirAmistad(id) {
    const u = await uid()
    const { error } = await sb().from('amistades').insert({ de: u, para: id, estado: 'pendiente' })
    if (error) falla(error, 'no_se_guardo')
  },
  async responderAmistad(id, aceptar) {
    const u = await uid()
    const { error } = aceptar ? await sb().from('amistades').update({ estado: 'aceptada' }).eq('de', id).eq('para', u) : await sb().from('amistades').delete().eq('de', id).eq('para', u)
    if (error) falla(error, 'no_se_guardo')
  },
  async quitarAmigo(id) {
    const u = await uid()
    const { error } = await sb().from('amistades').delete().or(`and(de.eq.${u},para.eq.${id}),and(de.eq.${id},para.eq.${u})`)
    if (error) falla(error, 'no_se_guardo')
  },
  async listMensajes(conId) {
    const u = await uid()
    const { data, error } = await sb().from('mensajes').select('*').or(`and(de.eq.${u},para.eq.${conId}),and(de.eq.${conId},para.eq.${u})`).order('creado_en').limit(300)
    if (error) falla(error, 'no_disponible')
    return (data ?? []) as Mensaje[]
  },
  async enviarMensaje(aId, texto) {
    const u = await uid()
    const { error } = await sb().from('mensajes').insert({ de: u, para: aId, texto: texto.trim() })
    if (error) falla(error, 'no_amigos')
  },
  async listAnuncios() {
    const { data, error } = await sb().from('anuncios_publicos').select('*').order('creado_en', { ascending: false }).limit(200)
    if (error) falla(error, 'no_disponible')
    return (data ?? []) as Anuncio[]
  },
  async createAnuncio(b) {
    const { data, error } = await sb().rpc('publicar_anuncio', { p: b })
    if (error) falla(error, 'no_se_guardo')
    return data as Anuncio
  },
  async cerrarAnuncio(id) { const { error } = await sb().from('anuncios').update({ estado: 'cerrado' }).eq('id', id); if (error) falla(error, 'no_se_guardo') },
  async renovarAnuncio(id) { const { error } = await sb().rpc('renovar_anuncio', { anuncio: id }); if (error) falla(error, 'no_se_guardo') },
  async reportarAnuncio(id) { const { error } = await sb().rpc('reportar_anuncio', { anuncio: id }); if (error) falla(error, 'no_se_guardo') },
  async preguntarSocio(mensaje, idioma) {
    const { data, error } = await sb().functions.invoke('socio', { body: { mensaje, idioma } })
    if (error) {
      const status = (error as { context?: { status?: number } }).context?.status
      if (status === 429) throw new BackendError('socio_limite')
      // La IA no está activada o falló: se responde con las guías de la app, avisando que es modo básico.
      const r = responderDemo(mensaje)
      return { texto: r.texto, clave: r.tipo !== 'guia', demo: true, oficial: r.guia?.oficial }
    }
    return { texto: String((data as { texto?: string })?.texto ?? ''), clave: false, demo: false }
  },
  async exportData() {
    const [perfil, contacto] = await Promise.all([this.getPerfil(), this.getContacto()])
    const s = await this.getSession()
    return { correo: s?.email, perfil, contacto, servicio: await this.getMiServicio() }
  },
  async deleteAccount() {
    const { error } = await sb().rpc('borrar_mi_cuenta')
    if (error) falla(error, 'no_se_borro')
    await sb().auth.signOut({ scope: 'local' })
  },
}
