import { nuevoIdCorto } from '../id'
import { detectarRiesgo, venceEn } from '../mercado'
import type { Anuncio, BorradorAnuncio } from '../mercado'
import type { Perfil } from './types'

const KEY = 'pk_demo_mercado'
interface Est { anuncios: Anuncio[]; reportes: { anuncio: string; user: string }[] }
let memoria: Est | null = null
const BV = { ciudad_ibge: 1400100, ciudad_nombre: 'Boa Vista' }

function semilla(): Est {
  const h = (d: number) => new Date(Date.now() - d * 86400000).toISOString()
  const A = (n: number, o: Partial<Anuncio> & Pick<Anuncio, 'apodo' | 'tipo' | 'titulo' | 'descripcion'>): Anuncio => ({
    id: 'ej-an' + n, user_id: 'ej-p' + n, avatar_color: '#2B3FD4', ...BV, precio: null, barrio: null, jornada: null, idioma: null,
    mostrar_whatsapp: false, creado_en: h(n), vence_en: venceEn(Date.now() - n * 86400000), estado: 'activo', ejemplo: true, ...o,
  })
  return { reportes: [], anuncios: [
    A(1, { apodo: 'Yunior', tipo: 'vendo', titulo: 'Bicicleta aro 26, buen estado', descripcion: 'La uso poco. Cambio de marchas nuevo. Se puede ver en el centro.', precio: 450, barrio: 'Centro', avatar_color: '#FFC93C' }),
    A(2, { apodo: 'Dayami', tipo: 'vendo', titulo: 'Dulces y cakes por encargo', descripcion: 'Cumpleaños y fiestas. Pedidos con dos días de anticipación.', precio: 40, barrio: 'Pintolândia', avatar_color: '#F6B7CB' }),
    A(3, { apodo: 'Raúl', tipo: 'alquilo', titulo: 'Cuarto amueblado cerca del centro', descripcion: 'Con baño propio y wifi. Solo personas trabajadoras, sin fiestas.', precio: 700, barrio: 'São Francisco', avatar_color: '#0E9F96' }),
    A(4, { apodo: 'Mailén', tipo: 'compro', titulo: 'Compro microondas usado', descripcion: 'Que funcione bien. Pago en efectivo al recogerlo.', barrio: 'Caçari' }),
    A(5, { apodo: 'Lázaro', tipo: 'servicio', titulo: 'Fletes y mudanzas pequeñas', descripcion: 'Tengo camioneta. Precio según la distancia, te cotizo gratis.', barrio: 'Mecejana', avatar_color: '#E03A3E' }),
    A(6, { apodo: 'Osmany', tipo: 'empleo', titulo: 'Ayudante de cocina, restaurante en el centro', descripcion: 'Se necesita ayudante con ganas de aprender. Turno de tarde y noche. No hace falta portugués perfecto.', precio: 1700, jornada: 'Tiempo completo', idioma: 'Portugués básico', barrio: 'Centro' }),
    A(7, { apodo: 'Yaneisy', tipo: 'empleo', titulo: 'Se busca ayudante de albañil', descripcion: 'Obra en Cauamé por dos meses. Pago semanal, con EPI incluido.', precio: 120, jornada: 'Por día', idioma: 'No hace falta', barrio: 'Cauamé' }),
    A(8, { apodo: 'Ernesto', tipo: 'busco_empleo', titulo: 'Busco trabajo de limpieza o carga', descripcion: 'Responsable, con ganas de trabajar. Disponible de lunes a sábado.', jornada: 'Medio tiempo', idioma: 'Portugués básico' }),
  ] }
}
function leer(): Est {
  if (memoria) return memoria
  try { const r = localStorage.getItem(KEY); if (r) return JSON.parse(r) as Est } catch { /* sin almacenamiento */ }
  const s = semilla(); guardar(s); return memoria ?? s
}
function guardar(s: Est) { try { localStorage.setItem(KEY, JSON.stringify(s)); memoria = null } catch { memoria = s } }

export const mercado = {
  list(yo: Perfil): Anuncio[] {
    // Lo mío siempre lo veo (también en revisión o cerrado); lo de los demás solo si está activo.
    return leer().anuncios.filter((a) => a.user_id === yo.id || a.estado === 'activo')
  },
  create(yo: Perfil, b: BorradorAnuncio): Anuncio {
    const s = leer()
    const riesgo = detectarRiesgo(b.titulo, b.descripcion).length > 0
    const a: Anuncio = {
      ...b, id: nuevoIdCorto(), user_id: yo.id, apodo: yo.apodo, avatar_color: yo.avatar_color,
      ciudad_ibge: yo.ciudad_ibge ?? 0, ciudad_nombre: yo.ciudad_nombre ?? '', creado_en: new Date().toISOString(), vence_en: venceEn(),
      estado: riesgo ? 'revision' : 'activo',
    }
    s.anuncios.push(a); guardar(s); return a
  },
  cerrar(yo: Perfil, id: string) { const s = leer(); s.anuncios = s.anuncios.map((a) => (a.id === id && a.user_id === yo.id ? { ...a, estado: 'cerrado' as const } : a)); guardar(s) },
  renovar(yo: Perfil, id: string) {
    const s = leer()
    s.anuncios = s.anuncios.map((a) => (a.id === id && a.user_id === yo.id && a.estado !== 'revision' ? { ...a, estado: 'activo' as const, vence_en: venceEn() } : a)); guardar(s)
  },
  reportar(yo: Perfil, id: string) {
    const s = leer()
    if (!s.reportes.some((r) => r.anuncio === id && r.user === yo.id)) s.reportes.push({ anuncio: id, user: yo.id })
    // Tres reportes de personas distintas lo sacan de circulación hasta que lo revise un moderador.
    if (s.reportes.filter((r) => r.anuncio === id).length >= 3) s.anuncios = s.anuncios.map((a) => (a.id === id ? { ...a, estado: 'revision' as const } : a))
    guardar(s)
  },
}
