import { nuevoIdCorto } from '../id'
import type { Amistad, Comentario, Mensaje, Persona, Publicacion, TipoPost } from '../social'
import type { Perfil } from './types'

/** Parte social del modo demostración. Vive en este teléfono; las personas de ejemplo están marcadas. */
const KEY = 'pk_demo_social'
interface PostD { id: string; user_id: string; ciudad: number; tipo: TipoPost; texto: string; creado_en: string }
interface ComD { id: string; post_id: string; user_id: string; texto: string; creado_en: string }
interface AmiD { de: string; para: string; estado: 'pendiente' | 'aceptada' }
interface Social { posts: PostD[]; coms: ComD[]; likes: string[]; amigos: AmiD[]; mensajes: Mensaje[]; bloqueos?: { de: string; a: string }[]; reportes?: { post: string; user: string }[] }
export interface Ctx { yo: Perfil; otros: Perfil[] }

const BV = 1400100
export const PERSONAS_EJEMPLO: Persona[] = [
  { id: 'ej-p1', apodo: 'Yunior', provincia_cuba: 'Camagüey', avatar_color: '#FFC93C', ciudad_nombre: 'Boa Vista', ejemplo: true },
  { id: 'ej-p2', apodo: 'Dayami', provincia_cuba: 'Santiago de Cuba', avatar_color: '#F6B7CB', ciudad_nombre: 'Boa Vista', ejemplo: true },
  { id: 'ej-p3', apodo: 'Raúl', provincia_cuba: 'La Habana', avatar_color: '#0E9F96', ciudad_nombre: 'Boa Vista', ejemplo: true },
  { id: 'ej-p4', apodo: 'Mailén', provincia_cuba: 'Holguín', avatar_color: '#2B3FD4', ciudad_nombre: 'Boa Vista', ejemplo: true },
  { id: 'ej-p5', apodo: 'Lázaro', provincia_cuba: 'Matanzas', avatar_color: '#E03A3E', ciudad_nombre: 'Boa Vista', ejemplo: true },
]
const RESPUESTAS = ['Dale, qué bolá. Ya te leo.', 'Claro asere, cuéntame.', 'Perfecto, hablamos ahora que salgo del trabajo.', 'Gracias por escribir. Estoy por aquí.']

function semilla(): Social {
  const h = (min: number) => new Date(Date.now() - min * 60000).toISOString()
  const p = (n: number, user: string, tipo: TipoPost, texto: string, min: number): PostD => ({ id: 'ej-post' + n, user_id: user, ciudad: BV, tipo, texto, creado_en: h(min) })
  return {
    posts: [
      p(1, 'ej-p1', 'pregunta', '¿Alguien sabe dónde sacar el CPF sin turno en el centro? Llevo dos días dando vueltas.', 25),
      p(2, 'ej-p2', 'recomendacion', 'Recomiendo la feria del sábado en Pintolândia: frutas buenas y bien de precio.', 130),
      p(3, 'ej-p3', 'aviso', 'Busco a alguien que me ayude con un tanque de agua este fin de semana. Pago bien.', 300),
      p(4, 'ej-p4', 'llegue', 'Llegué hoy a Boa Vista desde Pacaraima. Estoy buscando cuarto barato por el centro.', 600),
      p(5, 'ej-p5', 'evento', 'Dominó y malta el domingo a las 4 en la plaza. Trae tu ficha.', 1500),
    ],
    coms: [
      { id: 'ej-c1', post_id: 'ej-post1', user_id: 'ej-p3', texto: 'Ve temprano, antes de las 7 hay menos fila.', creado_en: h(20) },
      { id: 'ej-c2', post_id: 'ej-post4', user_id: 'ej-p1', texto: 'Bienvenido. Escríbeme y te oriento.', creado_en: h(550) },
    ],
    likes: [], amigos: [], mensajes: [],
  }
}

let memoria: Social | null = null
function leer(): Social {
  if (memoria) return memoria
  try {
    const raw = localStorage.getItem(KEY)
    if (raw) return JSON.parse(raw) as Social
  } catch { /* sin almacenamiento */ }
  const s = semilla(); guardar(s); return memoria ?? s
}
function guardar(s: Social) { try { localStorage.setItem(KEY, JSON.stringify(s)); memoria = null } catch { memoria = s } }

function persona(id: string, c: Ctx): Persona {
  const ej = PERSONAS_EJEMPLO.find((x) => x.id === id)
  if (ej) return ej
  const p = [c.yo, ...c.otros].find((x) => x.id === id)
  if (!p) return { id, apodo: '—', provincia_cuba: null, avatar_color: '#2B3FD4', ciudad_nombre: null }
  return { id: p.id, apodo: p.apodo, provincia_cuba: p.modo_discreto && p.id !== c.yo.id ? null : p.provincia_cuba, avatar_color: p.avatar_color, ciudad_nombre: p.ciudad_nombre }
}
const bloqueado = (s: Social, yo: string, otro: string) => (s.bloqueos ?? []).some((b) => (b.de === yo && b.a === otro) || (b.de === otro && b.a === yo))
const esAmigo = (s: Social, a: string, b: string) => s.amigos.some((x) => x.estado === 'aceptada' && ((x.de === a && x.para === b) || (x.de === b && x.para === a)))

export const social = {
  listPosts(c: Ctx): Publicacion[] {
    const s = leer()
    return s.posts.filter((p) => p.ciudad === c.yo.ciudad_ibge && !bloqueado(s, c.yo.id, p.user_id) && (s.reportes ?? []).filter((r) => r.post === p.id).length < 3)
      .sort((a, b) => b.creado_en.localeCompare(a.creado_en))
      .map((p) => ({
        id: p.id, autor: persona(p.user_id, c), tipo: p.tipo, texto: p.texto, creado_en: p.creado_en,
        comentarios: s.coms.filter((x) => x.post_id === p.id).length,
        likes: s.likes.filter((l) => l.startsWith(p.id + ':')).length,
        yo_like: s.likes.includes(`${p.id}:${c.yo.id}`),
      }))
  },
  createPost(c: Ctx, tipo: TipoPost, texto: string): void {
    const s = leer()
    s.posts.push({ id: nuevoIdCorto(), user_id: c.yo.id, ciudad: c.yo.ciudad_ibge ?? 0, tipo, texto: texto.trim(), creado_en: new Date().toISOString() })
    guardar(s)
  },
  deletePost(c: Ctx, id: string): void {
    const s = leer()
    s.posts = s.posts.filter((p) => !(p.id === id && p.user_id === c.yo.id))
    s.coms = s.coms.filter((x) => s.posts.some((p) => p.id === x.post_id)); guardar(s)
  },
  toggleLike(c: Ctx, id: string): void {
    const s = leer(); const k = `${id}:${c.yo.id}`
    s.likes = s.likes.includes(k) ? s.likes.filter((x) => x !== k) : [...s.likes, k]; guardar(s)
  },
  listComments(c: Ctx, id: string): Comentario[] {
    const s = leer()
    return s.coms.filter((x) => x.post_id === id && !bloqueado(s, c.yo.id, x.user_id)).sort((a, b) => a.creado_en.localeCompare(b.creado_en))
      .map((x) => ({ id: x.id, autor: persona(x.user_id, c), texto: x.texto, creado_en: x.creado_en }))
  },
  addComment(c: Ctx, id: string, texto: string): void {
    const s = leer(); s.coms.push({ id: nuevoIdCorto(), post_id: id, user_id: c.yo.id, texto: texto.trim(), creado_en: new Date().toISOString() }); guardar(s)
  },
  paisanos(c: Ctx): Persona[] {
    const s = leer()
    const reales = c.otros.filter((p) => p.completado && !p.modo_discreto && p.ciudad_ibge === c.yo.ciudad_ibge).map((p) => persona(p.id, c))
    const ej = c.yo.ciudad_ibge === BV ? PERSONAS_EJEMPLO : []
    return [...reales, ...ej].filter((p) => !bloqueado(s, c.yo.id, p.id)).filter((p) => !s.amigos.some((a) => (a.de === c.yo.id && a.para === p.id) || (a.para === c.yo.id && a.de === p.id)))
  },
  amistades(c: Ctx): Amistad[] {
    const s = leer()
    return s.amigos.filter((a) => (a.de === c.yo.id || a.para === c.yo.id) && !bloqueado(s, c.yo.id, a.de === c.yo.id ? a.para : a.de)).map((a) => {
      const otro = a.de === c.yo.id ? a.para : a.de
      return { persona: persona(otro, c), estado: a.estado === 'aceptada' ? 'amigo' as const : a.de === c.yo.id ? 'enviada' as const : 'recibida' as const }
    })
  },
  pedirAmistad(c: Ctx, id: string): void {
    const s = leer()
    if (s.amigos.some((a) => (a.de === c.yo.id && a.para === id) || (a.para === c.yo.id && a.de === id))) return
    // Las personas de ejemplo aceptan al instante para poder probar el chat.
    s.amigos.push({ de: c.yo.id, para: id, estado: id.startsWith('ej-') ? 'aceptada' : 'pendiente' }); guardar(s)
  },
  responderAmistad(c: Ctx, id: string, aceptar: boolean): void {
    const s = leer()
    s.amigos = aceptar
      ? s.amigos.map((a) => (a.de === id && a.para === c.yo.id ? { ...a, estado: 'aceptada' as const } : a))
      : s.amigos.filter((a) => !(a.de === id && a.para === c.yo.id)); guardar(s)
  },
  quitarAmigo(c: Ctx, id: string): void {
    const s = leer(); s.amigos = s.amigos.filter((a) => !((a.de === c.yo.id && a.para === id) || (a.para === c.yo.id && a.de === id))); guardar(s)
  },
  reportarPost(c: Ctx, id: string): void {
    const s = leer(); s.reportes = s.reportes ?? []
    if (!s.reportes.some((r) => r.post === id && r.user === c.yo.id)) s.reportes.push({ post: id, user: c.yo.id })
    guardar(s)
  },
  bloquear(c: Ctx, id: string): void {
    const s = leer(); s.bloqueos = s.bloqueos ?? []
    if (!s.bloqueos.some((b) => b.de === c.yo.id && b.a === id)) s.bloqueos.push({ de: c.yo.id, a: id })
    s.amigos = s.amigos.filter((a) => !((a.de === c.yo.id && a.para === id) || (a.para === c.yo.id && a.de === id))); guardar(s)
  },
  mensajes(c: Ctx, id: string): Mensaje[] {
    return leer().mensajes.filter((m) => (m.de === c.yo.id && m.para === id) || (m.de === id && m.para === c.yo.id)).sort((a, b) => a.creado_en.localeCompare(b.creado_en))
  },
  enviar(c: Ctx, id: string, texto: string): void {
    const s = leer()
    if (!esAmigo(s, c.yo.id, id) || bloqueado(s, c.yo.id, id)) throw new Error('no_amigos')
    s.mensajes.push({ id: nuevoIdCorto(), de: c.yo.id, para: id, texto: texto.trim(), creado_en: new Date().toISOString() })
    if (id.startsWith('ej-')) s.mensajes.push({ id: nuevoIdCorto(), de: id, para: c.yo.id, texto: RESPUESTAS[s.mensajes.length % RESPUESTAS.length], creado_en: new Date(Date.now() + 1500).toISOString() })
    guardar(s)
  },
}
