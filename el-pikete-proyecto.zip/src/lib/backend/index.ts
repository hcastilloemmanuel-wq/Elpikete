import { DEMO_MODE } from '../config'
import { demoBackend } from './demo'
import { supabaseBackend } from './supabase'
export const backend = DEMO_MODE ? demoBackend : supabaseBackend
export * from './types'
