import type { BorradorServicio, Servicio } from '../servicios'
import type { Anuncio, BorradorAnuncio } from '../mercado'
import type { Amistad, Comentario, Mensaje, Persona, Publicacion, TipoPost } from '../social'

export type VisOficio = 'todos' | 'amigos' | 'servicios'
export type VisWhatsapp = 'nadie' | 'amigos' | 'todos'

export interface Perfil {
  id: string
  apodo: string
  provincia_cuba: string | null
  estado_br: string | null
  ciudad_ibge: number | null
  ciudad_nombre: string | null
  barrio: string | null
  oficios: string[]
  oficio_visibilidad: VisOficio
  modo_discreto: boolean
  recien_llegado: boolean
  propositos: string[]
  frase: string | null
  avatar_color: string
  paso: number
  completado: boolean
}

export interface RespuestaSocio { texto: string; /** true si `texto` es una clave de traducción (respuestas fijas de la demostración) */ clave: boolean; demo: boolean; oficial?: string }
export interface Contacto { whatsapp: string | null; whatsapp_visibilidad: VisWhatsapp }
export interface Sesion { userId: string; email: string }
export type AlcanceSalida = 'local' | 'global'

export interface Backend {
  mode: 'demo' | 'supabase'
  getSession(): Promise<Sesion | null>
  onAuthChange(cb: (s: Sesion | null) => void): () => void
  /** `id` es un correo o un teléfono con "+" (+5595999999999). */
  requestCode(id: string, apodo: string): Promise<void>
  verifyCode(id: string, code: string): Promise<Sesion>
  signOut(scope: AlcanceSalida): Promise<void>
  getPerfil(): Promise<Perfil | null>
  savePerfil(patch: Partial<Perfil>): Promise<Perfil>
  getContacto(): Promise<Contacto>
  saveContacto(c: Partial<Contacto>): Promise<Contacto>
  /** Servicios de todos los paisanos (en demo, 12 de ejemplo + el tuyo). */
  listServicios(): Promise<Servicio[]>
  getMiServicio(): Promise<Servicio | null>
  saveMiServicio(b: BorradorServicio): Promise<Servicio>
  deleteMiServicio(): Promise<void>
  /** WhatsApp del profesional, solo si lo muestra y la regla del servidor lo permite. */
  verWhatsapp(userId: string): Promise<string | null>
  listPosts(): Promise<Publicacion[]>
  createPost(tipo: TipoPost, texto: string): Promise<void>
  deletePost(id: string): Promise<void>
  toggleLike(id: string): Promise<void>
  listComments(postId: string): Promise<Comentario[]>
  addComment(postId: string, texto: string): Promise<void>
  reportarPost(id: string): Promise<void>
  bloquear(userId: string): Promise<void>
  listPaisanos(): Promise<Persona[]>
  listAmistades(): Promise<Amistad[]>
  pedirAmistad(id: string): Promise<void>
  responderAmistad(id: string, aceptar: boolean): Promise<void>
  quitarAmigo(id: string): Promise<void>
  listMensajes(conId: string): Promise<Mensaje[]>
  enviarMensaje(aId: string, texto: string): Promise<void>
  listAnuncios(): Promise<Anuncio[]>
  createAnuncio(b: BorradorAnuncio): Promise<Anuncio>
  cerrarAnuncio(id: string): Promise<void>
  renovarAnuncio(id: string): Promise<void>
  reportarAnuncio(id: string): Promise<void>
  preguntarSocio(mensaje: string, idioma: string): Promise<RespuestaSocio>
  exportData(): Promise<unknown>
  deleteAccount(): Promise<void>
}

export class BackendError extends Error {
  code: string
  constructor(code: string, message?: string) { super(message ?? code); this.code = code }
}
