import { DEMO_CODE } from '../config'
import { sessionAdapter } from '../storage'
import { validarCodigo } from '../validate'
import { SERVICIOS_EJEMPLO } from '../servicios'
import type { BorradorServicio, Servicio } from '../servicios'
import { responderDemo } from '../socio'
import { mercado } from './demo-mercado'
import { social } from './demo-social'
import type { Ctx } from './demo-social'
import { BackendError } from './types'
import type { Backend, Contacto, Perfil, Sesion } from './types'

/**
 * Modo demostración: se usa cuando todavía no hay Supabase configurado.
 * Todo vive en ESTE navegador (nada sale del teléfono). El código de entrada es siempre 123456.
 */
const DB_KEY = 'pk_demo_db'
const SES_KEY = 'pk_demo_session'

interface Usuario { id: string; email: string; perfil: Perfil; contacto: Contacto; servicio?: BorradorServicio | null }
type Db = Record<string, Usuario>
const listeners = new Set<(s: Sesion | null) => void>()

// Si el teléfono bloquea el almacenamiento (pasa al abrir un .html suelto desde Descargas),
// la demo sigue funcionando guardando en memoria hasta que se cierre la página.
let memoria: Db | null = null
function leerDb(): Db {
  if (memoria) return memoria
  try { return JSON.parse(localStorage.getItem(DB_KEY) ?? '{}') as Db } catch { return {} }
}
function escribirDb(db: Db) {
  try { localStorage.setItem(DB_KEY, JSON.stringify(db)); memoria = null } catch { memoria = db }
}
function leerSesion(): Sesion | null {
  const raw = sessionAdapter.getItem(SES_KEY)
  if (!raw) return null
  try { return JSON.parse(raw) as Sesion } catch { return null }
}
function emit(s: Sesion | null) { listeners.forEach((cb) => cb(s)) }
/** crypto.randomUUID solo existe en contextos seguros; en un .html suelto puede faltar. */
function nuevoId(): string {
  try { if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID() } catch { /* sigue abajo */ }
  return 'u-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10)
}
const pendientes = new Map<string, string>()
const colores = ['#2B3FD4', '#FFC93C', '#E03A3E', '#0E9F96', '#F6B7CB', '#7A4FD0', '#F28A2E', '#3E9B4F']

function usuarioActual(): Usuario {
  const s = leerSesion()
  if (!s) throw new BackendError('sin_sesion')
  const u = Object.values(leerDb()).find((x) => x.id === s.userId)
  if (!u) throw new BackendError('sin_sesion')
  return u
}
function ctx(): Ctx {
  const yo = usuarioActual()
  return { yo: yo.perfil, otros: Object.values(leerDb()).filter((x) => x.id !== yo.id).map((x) => x.perfil) }
}
function guardar(u: Usuario) { const db = leerDb(); db[u.email] = u; escribirDb(db) }

function aServicio(u: Usuario): Servicio {
  const b = u.servicio as BorradorServicio
  const p = u.perfil
  return {
    ...b, id: 'mio-' + u.id, user_id: u.id, apodo: p.apodo, provincia_cuba: p.modo_discreto ? null : p.provincia_cuba,
    avatar_color: p.avatar_color, ciudad_ibge: p.ciudad_ibge ?? 0, ciudad_nombre: p.ciudad_nombre ?? '', barrio: p.barrio,
    trabajos: 0, rapidez_min: null, resenas: 0, promedio: null,
  }
}

export const demoBackend: Backend = {
  mode: 'demo',
  async getSession() { return leerSesion() },
  onAuthChange(cb) {
    listeners.add(cb)
    const onStorage = (e: StorageEvent) => { if (e.key === SES_KEY) cb(leerSesion()) }
    window.addEventListener('storage', onStorage)
    return () => { listeners.delete(cb); window.removeEventListener('storage', onStorage) }
  },
  async requestCode(email, apodo) {
    pendientes.set(email.toLowerCase(), apodo)
    await new Promise((r) => setTimeout(r, 250))
  },
  async verifyCode(email, code) {
    const mail = email.toLowerCase()
    if (validarCodigo(code) || code.trim() !== DEMO_CODE) throw new BackendError('codigo_incorrecto')
    const db = leerDb()
    let u = db[mail]
    if (!u) {
      const apodo = pendientes.get(mail) ?? mail.split('@')[0]
      const id = nuevoId()
      u = {
        id, email: mail, contacto: { whatsapp: null, whatsapp_visibilidad: 'nadie' },
        perfil: {
          id, apodo, provincia_cuba: null, estado_br: null, ciudad_ibge: null, ciudad_nombre: null, barrio: null,
          oficios: [], oficio_visibilidad: 'todos', modo_discreto: false, recien_llegado: false, propositos: [],
          frase: null, avatar_color: colores[Math.floor(Math.random() * colores.length)], paso: 2, completado: false,
        },
      }
      db[mail] = u; escribirDb(db)
    }
    const ses: Sesion = { userId: u.id, email: mail }
    sessionAdapter.setItem(SES_KEY, JSON.stringify(ses))
    emit(ses)
    return ses
  },
  async signOut() { sessionAdapter.removeItem(SES_KEY); emit(null) },
  async getPerfil() { try { return usuarioActual().perfil } catch { return null } },
  async savePerfil(patch) {
    const u = usuarioActual()
    u.perfil = { ...u.perfil, ...patch, id: u.id }
    guardar(u); return u.perfil
  },
  async getContacto() { return usuarioActual().contacto },
  async saveContacto(c) { const u = usuarioActual(); u.contacto = { ...u.contacto, ...c }; guardar(u); return u.contacto },
  async listServicios() {
    const propios = Object.values(leerDb()).flatMap((u) => (u.servicio && u.perfil.completado ? [aServicio(u)] : []))
    return [...propios, ...SERVICIOS_EJEMPLO]
  },
  async getMiServicio() { const u = usuarioActual(); return u.servicio ? aServicio(u) : null },
  async saveMiServicio(b) { const u = usuarioActual(); u.servicio = b; guardar(u); return aServicio(u) },
  async deleteMiServicio() { const u = usuarioActual(); u.servicio = null; guardar(u) },
  async verWhatsapp(userId) {
    const u = Object.values(leerDb()).find((x) => x.id === userId)
    return u && u.servicio?.mostrar_whatsapp ? u.contacto.whatsapp : null
  },
  async listPosts() { return social.listPosts(ctx()) },
  async createPost(tipo, texto) { social.createPost(ctx(), tipo, texto) },
  async deletePost(id) { social.deletePost(ctx(), id) },
  async toggleLike(id) { social.toggleLike(ctx(), id) },
  async listComments(id) { return social.listComments(ctx(), id) },
  async addComment(id, texto) { social.addComment(ctx(), id, texto) },
  async reportarPost(id) { social.reportarPost(ctx(), id) },
  async bloquear(id) { social.bloquear(ctx(), id) },
  async listPaisanos() { return social.paisanos(ctx()) },
  async listAmistades() { return social.amistades(ctx()) },
  async pedirAmistad(id) { social.pedirAmistad(ctx(), id) },
  async responderAmistad(id, ok) { social.responderAmistad(ctx(), id, ok) },
  async quitarAmigo(id) { social.quitarAmigo(ctx(), id) },
  async listMensajes(id) { return social.mensajes(ctx(), id) },
  async enviarMensaje(id, texto) { try { social.enviar(ctx(), id, texto) } catch { throw new BackendError('no_amigos') } },
  async listAnuncios() { return mercado.list(usuarioActual().perfil) },
  async createAnuncio(b) { return mercado.create(usuarioActual().perfil, b) },
  async cerrarAnuncio(id) { mercado.cerrar(usuarioActual().perfil, id) },
  async renovarAnuncio(id) { mercado.renovar(usuarioActual().perfil, id) },
  async reportarAnuncio(id) { mercado.reportar(usuarioActual().perfil, id) },
  async preguntarSocio(mensaje) {
    await new Promise((r) => setTimeout(r, 500))
    const r = responderDemo(mensaje)
    return { texto: r.texto, clave: r.tipo !== 'guia', demo: true, oficial: r.guia?.oficial }
  },
  async exportData() { const u = usuarioActual(); return { correo: u.email, perfil: u.perfil, contacto: u.contacto, servicio: u.servicio ?? null } },
  async deleteAccount() {
    const u = usuarioActual(); const db = leerDb(); delete db[u.email]; escribirDb(db)
    sessionAdapter.removeItem(SES_KEY); emit(null)
  },
}
