/** Núcleo social: publicaciones de la cuadra (por ciudad), comentarios, "me gusta", amigos y mensajes. */
export const TIPOS_POST = ['pregunta', 'aviso', 'evento', 'recomendacion', 'llegue'] as const
export type TipoPost = (typeof TIPOS_POST)[number]

export interface Persona {
  id: string
  apodo: string
  provincia_cuba: string | null
  avatar_color: string
  ciudad_nombre: string | null
  ejemplo?: boolean
}
export interface Publicacion {
  id: string
  autor: Persona
  tipo: TipoPost
  texto: string
  creado_en: string
  comentarios: number
  likes: number
  yo_like: boolean
}
export interface Comentario { id: string; autor: Persona; texto: string; creado_en: string }
export type EstadoAmistad = 'amigo' | 'enviada' | 'recibida'
export interface Amistad { persona: Persona; estado: EstadoAmistad }
export interface Mensaje { id: string; de: string; para: string; texto: string; creado_en: string }

export const MAX_POST = 500
export const MAX_MENSAJE = 1000

/** Devuelve el código de error (clave "err.<codigo>") o null. */
export function validarTexto(texto: string, max: number): string | null {
  const x = texto.trim()
  if (x.length === 0) return 'texto_vacio'
  if (x.length > max) return 'texto_largo'
  return null
}

export function tiempoRelativo(iso: string, ahora = Date.now()): { k: string; n?: number } {
  const s = Math.max(0, Math.round((ahora - new Date(iso).getTime()) / 1000))
  if (s < 60) return { k: 'tiempo.ahora' }
  if (s < 3600) return { k: 'tiempo.min', n: Math.floor(s / 60) }
  if (s < 86400) return { k: 'tiempo.h', n: Math.floor(s / 3600) }
  return { k: 'tiempo.d', n: Math.floor(s / 86400) }
}
