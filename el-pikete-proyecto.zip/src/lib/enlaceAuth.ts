/**
 * Entrar con el enlace del correo. Supabase devuelve a la web con "#access_token=...&refresh_token=...".
 * Como la app usa rutas con "#", se leen esas claves ANTES de que el router arranque y se limpia la barra.
 */
export interface FichaEnlace { access_token: string; refresh_token: string }
let pendiente: FichaEnlace | null = null

export function capturarEnlaceAuth(loc: Pick<Location, 'hash' | 'pathname' | 'search'> = window.location): void {
  const h = loc.hash.startsWith('#') ? loc.hash.slice(1) : loc.hash
  if (!h.includes('access_token=') && !h.includes('error_description=')) return
  const p = new URLSearchParams(h)
  const a = p.get('access_token'); const r = p.get('refresh_token')
  if (a && r) pendiente = { access_token: a, refresh_token: r }
  try { window.history.replaceState(null, '', loc.pathname + loc.search + '#/') } catch { /* sin historial: no pasa nada */ }
}
export function tomarEnlacePendiente(): FichaEnlace | null { const f = pendiente; pendiente = null; return f }
