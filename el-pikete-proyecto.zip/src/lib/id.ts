/** Identificador corto para datos de la demostración (crypto.randomUUID puede faltar en un .html suelto). */
export function nuevoIdCorto(): string {
  return 'd-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 9)
}
