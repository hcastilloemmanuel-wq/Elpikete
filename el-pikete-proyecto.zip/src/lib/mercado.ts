/** La Bolsa (comprar, vender, alquilar, servicios) y Pincha (trabajo). Anuncios por ciudad que vencen a los 30 días. */
export const TIPOS_BOLSA = ['vendo', 'compro', 'alquilo', 'servicio'] as const
export const TIPOS_PINCHA = ['empleo', 'busco_empleo'] as const
export type TipoAnuncio = (typeof TIPOS_BOLSA)[number] | (typeof TIPOS_PINCHA)[number]
export type Seccion = 'bolsa' | 'pincha'
export const seccionDe = (t: TipoAnuncio): Seccion => ((TIPOS_PINCHA as readonly string[]).includes(t) ? 'pincha' : 'bolsa')
export const DIAS_VIGENCIA = 30

export interface Anuncio {
  id: string
  user_id: string
  apodo: string
  avatar_color: string
  ciudad_ibge: number
  ciudad_nombre: string
  tipo: TipoAnuncio
  titulo: string
  descripcion: string
  precio: number | null
  barrio: string | null
  jornada: string | null
  idioma: string | null
  mostrar_whatsapp: boolean
  creado_en: string
  vence_en: string
  estado: 'activo' | 'cerrado' | 'revision'
  ejemplo?: boolean
}
export type BorradorAnuncio = Pick<Anuncio, 'tipo' | 'titulo' | 'descripcion' | 'precio' | 'barrio' | 'jornada' | 'idioma' | 'mostrar_whatsapp'>

/** Señales típicas de estafa. Si el anuncio las tiene, queda en revisión y no se publica solo. */
const RIESGOS: { id: string; re: RegExp }[] = [
  { id: 'adelantado', re: /(pago|pagar|paga|deposit\w*|dep[oó]sito|taxa|tarifa|cuota|pix)\s+(por\s+)?(adelantad\w*|adiantad\w*|previ\w*|antes)|adelantad[oa]|adiantad[oa]|taxa de (inscri|cadastro|admiss)/i },
  { id: 'terceros', re: /western union|moneygram|transferencia a (un )?tercero|transfer[eê]ncia para (um )?terceiro|giro a nombre de|cuenta de (un )?amigo|conta de (um )?amigo/i },
  { id: 'facil', re: /gan(a|e|ar) (dinero )?f[aá]cil|ganancias? garantizad\w*|ganhe dinheiro f[aá]cil|ganhos garantidos|sin experiencia.{0,25}(r\$|reales|\d{3,})|sem experi[eê]ncia.{0,25}(r\$|\d{3,})|multiplica tu dinero|renda extra garantida/i },
  { id: 'documentos', re: /(env[ií]a|manda|mand[ae]|envie)\s+(tu|seu|su)?\s*(pasaporte|passaporte|cpf|documentos?|foto del documento|selfie con)/i },
]
export function detectarRiesgo(...textos: (string | null | undefined)[]): string[] {
  const t = textos.filter(Boolean).join(' \n ')
  return RIESGOS.filter((r) => r.re.test(t)).map((r) => r.id)
}

export function vencido(a: Pick<Anuncio, 'vence_en'>, ahora = Date.now()): boolean { return new Date(a.vence_en).getTime() <= ahora }
export function venceEn(desde = Date.now()): string { return new Date(desde + DIAS_VIGENCIA * 86400000).toISOString() }
export function diasRestantes(a: Pick<Anuncio, 'vence_en'>, ahora = Date.now()): number { return Math.max(0, Math.ceil((new Date(a.vence_en).getTime() - ahora) / 86400000)) }

export function validarAnuncio(b: BorradorAnuncio): string | null {
  if (b.titulo.trim().length < 4) return 'anuncio_titulo'
  if (b.titulo.length > 80) return 'anuncio_titulo_largo'
  if (b.descripcion.trim().length < 10) return 'anuncio_descripcion'
  if (b.descripcion.length > 600) return 'anuncio_descripcion_larga'
  if (b.precio != null && (!Number.isFinite(b.precio) || b.precio < 0 || b.precio > 10_000_000)) return 'anuncio_precio'
  return null
}

export interface FiltrosAnuncio { texto: string; seccion: Seccion; tipo: TipoAnuncio | null; solo_mi_ciudad: boolean; ciudad: number | null }
const sinTildes = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
export function filtrarAnuncios(lista: Anuncio[], f: FiltrosAnuncio, ahora = Date.now()): Anuncio[] {
  const q = sinTildes(f.texto.trim())
  return lista
    .filter((a) => a.estado === 'activo' && !vencido(a, ahora) && seccionDe(a.tipo) === f.seccion)
    .filter((a) => (f.tipo ? a.tipo === f.tipo : true))
    .filter((a) => (f.solo_mi_ciudad && f.ciudad != null ? a.ciudad_ibge === f.ciudad : true))
    .filter((a) => (q ? sinTildes(a.titulo + ' ' + a.descripcion).includes(q) : true))
    .sort((a, b) => b.creado_en.localeCompare(a.creado_en))
}
