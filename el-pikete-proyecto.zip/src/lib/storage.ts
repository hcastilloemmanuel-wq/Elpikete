/**
 * Dónde vive la sesión en ESTE teléfono.
 * - "Este es mi teléfono" (por defecto): localStorage, la sesión sigue al cerrar el navegador.
 * - Dispositivo compartido: sessionStorage, la sesión muere al cerrar la pestaña.
 * Nada de esto viaja a otros dispositivos.
 */
const REMEMBER_KEY = 'pk_remember'
export const PRIVATE_PREFIX = 'pk_priv_'

function safe<T>(fn: () => T, fallback: T): T { try { return fn() } catch { return fallback } }

export function getRemember(): boolean { return safe(() => localStorage.getItem(REMEMBER_KEY) !== '0', true) }
export function setRemember(v: boolean) { safe(() => localStorage.setItem(REMEMBER_KEY, v ? '1' : '0'), undefined) }

// Respaldo en memoria SOLO si el teléfono bloquea el almacenamiento (pasa al abrir un .html
// suelto desde Descargas): la sesión dura mientras la página siga abierta en vez de fallar.
// Con almacenamiento normal, la memoria no se usa: manda lo que hay guardado.
const memoria = new Map<string, string>()
function almacenamientoOk(): boolean {
  return safe(() => { const k = '__pk_prueba'; localStorage.setItem(k, '1'); localStorage.removeItem(k); return true }, false)
}

export const sessionAdapter = {
  getItem(k: string): string | null {
    if (!almacenamientoOk()) return memoria.get(k) ?? null
    return safe(() => sessionStorage.getItem(k), null) ?? safe(() => localStorage.getItem(k), null)
  },
  setItem(k: string, v: string) {
    if (!almacenamientoOk()) { memoria.set(k, v); return }
    if (getRemember()) { safe(() => sessionStorage.removeItem(k), undefined); safe(() => localStorage.setItem(k, v), undefined) }
    else { safe(() => localStorage.removeItem(k), undefined); safe(() => sessionStorage.setItem(k, v), undefined) }
  },
  removeItem(k: string) { memoria.delete(k); safe(() => localStorage.removeItem(k), undefined); safe(() => sessionStorage.removeItem(k), undefined) },
}

/** Borra del teléfono todo lo privado: borradores, cachés de mensajes y de perfil. */
export function limpiarCachePrivada() {
  for (const k of [...memoria.keys()]) if (k.startsWith(PRIVATE_PREFIX)) memoria.delete(k)
  for (const st of [safe(() => localStorage, null), safe(() => sessionStorage, null)]) {
    if (!st) continue
    const claves: string[] = []
    for (let i = 0; i < st.length; i++) { const k = st.key(i); if (k && k.startsWith(PRIVATE_PREFIX)) claves.push(k) }
    claves.forEach((k) => st.removeItem(k))
  }
}

export function guardarBorrador(nombre: string, valor: unknown) {
  safe(() => sessionAdapter.setItem(PRIVATE_PREFIX + nombre, JSON.stringify(valor)), undefined)
}
export function leerBorrador<T>(nombre: string): T | null {
  return safe(() => { const v = sessionAdapter.getItem(PRIVATE_PREFIX + nombre); return v ? (JSON.parse(v) as T) : null }, null)
}
