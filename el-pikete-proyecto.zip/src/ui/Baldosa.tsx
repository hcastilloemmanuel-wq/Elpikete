import { useId } from 'react'
import type { CSSProperties, ReactNode } from 'react'

/**
 * La baldosa hidráulica cubana: la firma visual de El Pikete.
 * Seis diseños base que se combinan girándolos de 90 en 90 grados.
 */
export type Paleta = { bg: string; p: string; q: string }

export const CAL = '#F6F5F0'
export const NOCHE = '#0B0E2A'
export const ANIL = '#2B3FD4'
export const SOL = '#FFC93C'
export const ROJO = '#E03A3E'
export const MAR = '#0E9F96'
export const ROSA = '#F6B7CB'

export const PALETAS: Paleta[] = [
  { bg: ANIL, p: CAL, q: SOL },
  { bg: CAL, p: ANIL, q: ROJO },
  { bg: MAR, p: CAL, q: '#1C2A8F' },
  { bg: SOL, p: ANIL, q: ROJO },
  { bg: ROJO, p: CAL, q: SOL },
  { bg: NOCHE, p: SOL, q: MAR },
  { bg: ROSA, p: ANIL, q: CAL },
  { bg: CAL, p: MAR, q: SOL },
]

function motivo(i: number, c: Paleta): ReactNode {
  switch (i % 6) {
    case 0: // esquinas
      return (<>
        <rect width="100" height="100" fill={c.bg} />
        {[[0, 0], [100, 0], [0, 100], [100, 100]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="36" fill={c.p} />)}
        <circle cx="50" cy="50" r="14" fill={c.q} />
      </>)
    case 1: // sol
      return (<>
        <rect width="100" height="100" fill={c.bg} />
        <circle cx="50" cy="50" r="38" fill={c.p} />
        <circle cx="50" cy="50" r="23" fill={c.bg} />
        <circle cx="50" cy="50" r="9" fill={c.q} />
        {[[0, 0], [100, 0], [0, 100], [100, 100]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="13" fill={c.q} />)}
      </>)
    case 2: // rombo
      return (<>
        <rect width="100" height="100" fill={c.bg} />
        <polygon points="50,5 95,50 50,95 5,50" fill={c.p} />
        <polygon points="50,26 74,50 50,74 26,50" fill={c.q} />
        <circle cx="50" cy="50" r="6" fill={c.bg} />
      </>)
    case 3: // ola
      return (<>
        <rect width="100" height="100" fill={c.bg} />
        <path d="M0 50A25 25 0 0 1 50 50A25 25 0 0 1 100 50V100H0z" fill={c.p} />
        <circle cx="25" cy="76" r="9" fill={c.q} />
        <circle cx="75" cy="76" r="9" fill={c.q} />
      </>)
    case 4: // flor
      return (<>
        <rect width="100" height="100" fill={c.bg} />
        {[[50, 24], [76, 50], [50, 76], [24, 50]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="25" fill={c.p} />)}
        <circle cx="50" cy="50" r="13" fill={c.q} />
        {[[8, 8], [92, 8], [8, 92], [92, 92]].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="7" fill={c.q} />)}
      </>)
    default: // abanico
      return (<>
        <rect width="100" height="100" fill={c.bg} />
        {[[0, 0], [100, 100]].map(([x, y]) => (<g key={`${x}${y}`}>
          <circle cx={x} cy={y} r="74" fill={c.p} />
          <circle cx={x} cy={y} r="54" fill={c.bg} />
          <circle cx={x} cy={y} r="36" fill={c.q} />
          <circle cx={x} cy={y} r="18" fill={c.bg} />
        </g>))}
      </>)
  }
}

function hash(s: string): number {
  let h = 7
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return h
}

/** Una baldosa suelta, con esquinas redondeadas. */
export function Baldosa({ diseno = 0, paleta = PALETAS[0], size = 40, radio = 0.26, titulo }: {
  diseno?: number; paleta?: Paleta; size?: number; radio?: number; titulo?: string
}) {
  const id = useId()
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} role={titulo ? 'img' : undefined} aria-label={titulo} aria-hidden={titulo ? undefined : true}>
      <clipPath id={id}><rect width="100" height="100" rx={radio * 100} /></clipPath>
      <g clipPath={`url(#${id})`}>{motivo(diseno, paleta)}</g>
    </svg>
  )
}

/** Un campo de baldosas que llena todo el ancho (la entrada, los vacíos). */
export function BaldosaCampo({ columnas = 4, filas = 3, celdas, className }: {
  columnas?: number; filas?: number; celdas?: { d: number; p: number }[]; className?: string
}) {
  const id = useId()
  const lista = celdas ?? defecto(columnas, filas)
  return (
    <svg className={className} viewBox={`0 0 ${columnas * 100} ${filas * 100}`} preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs>
        {lista.map((c, k) => (
          <symbol key={k} id={`${id}-${k}`} viewBox="0 0 100 100">{motivo(c.d, PALETAS[c.p % PALETAS.length])}</symbol>
        ))}
      </defs>
      {lista.slice(0, columnas * filas).map((_, k) => {
        const x = (k % columnas) * 100, y = Math.floor(k / columnas) * 100
        const giro = ((k % columnas) + Math.floor(k / columnas)) % 4 * 90
        return (
          <g key={k} transform={`rotate(${giro} ${x + 50} ${y + 50})`}>
            <use href={`#${id}-${k}`} x={x} y={y} width="100" height="100" className="b-entra" style={{ ["--i" as string]: k } as CSSProperties} />
          </g>
        )
      })}
    </svg>
  )
}

function defecto(columnas: number, filas: number) {
  const n = columnas * filas
  return Array.from({ length: n }, (_, k) => {
    const x = k % columnas, y = Math.floor(k / columnas)
    return { d: (x + y) % 2 === 0 ? 0 : 5, p: (x + y) % 2 === 0 ? 0 : 1 }
  })
}

/** Avatar: baldosa según la provincia (o el apodo en modo discreto) con la inicial al centro. */
export function Avatar({ apodo, provincia, discreto, color, size = 40 }: {
  apodo: string; provincia?: string | null; discreto?: boolean; color: string; size?: number
}) {
  const semilla = !discreto && provincia ? provincia : apodo
  const diseno = hash(semilla) % 6
  return (
    <span className="avatar-b" style={{ width: size, height: size }}>
      <Baldosa diseno={diseno} paleta={{ bg: color, p: CAL, q: NOCHE }} size={size} radio={0.3} />
      <span className="avatar-b-letra" style={{ fontSize: size * 0.4, color: NOCHE }}>
        {apodo.slice(0, 1).toUpperCase()}
      </span>
    </span>
  )
}

