import type { SVGProps } from 'react'

/**
 * Familia de iconos de El Pikete.
 * Reglas: cuadrícula de 24 px, trazo de 1.75, puntas redondas.
 * Cada icono tiene una parte base (b) y un detalle (a) que toma el color de acento.
 * "dots" son puntos pequeños (trazo grueso) que también van en acento.
 */
type Def = { b: string[]; a?: string[]; dots?: string[] }

const ICONS = {
  cuadra: { b: ['M4 10.5 12 4l8 6.5V19a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z'], a: ['M10 20v-4.5a2 2 0 0 1 4 0V20'] },
  servicios: {
    b: ['M14.5 5.5a4 4 0 0 0-4.9 5.2l-5.2 5.2a1.8 1.8 0 0 0 2.5 2.5l5.2-5.2a4 4 0 0 0 5.2-4.9l-2.4 2.4-2-.6-.6-2z'],
    dots: ['M6.3 17.1h.01'],
  },
  bolsa: { b: ['M5 8h14l-1 11a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1z'], a: ['M9 8V7a3 3 0 0 1 6 0v1'] },
  noticias: {
    b: ['M4 5a1 1 0 0 1 1-1h12v15a1 1 0 0 0 1 1H6a2 2 0 0 1-2-2z', 'M17 9h2a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1'],
    a: ['M8 8h5M8 11.5h5M8 15h3'],
  },
  chat: {
    b: ['M5 5h14a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-8l-4.5 3.5V16H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z'],
    dots: ['M8.5 10.5h.01', 'M12 10.5h.01', 'M15.5 10.5h.01'],
  },
  yo: { b: ['M12 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z'], a: ['M5 20a7 7 0 0 1 14 0'] },
  amigos: {
    b: ['M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6z', 'M3.5 19a5.5 5.5 0 0 1 11 0'],
    a: ['M16 5.4a3 3 0 0 1 0 5.2', 'M17.5 14a5.5 5.5 0 0 1 3 5'],
  },
  pincha: {
    b: ['M4 8.5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1V18a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z', 'M4 12.5h16'],
    a: ['M9 7.5V6a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1.5'],
  },
  socio: {
    b: ['M12 3.5l1.9 4.9 4.9 1.9-4.9 1.9L12 17.1l-1.9-4.9L5.2 10.3l4.9-1.9z'],
    a: ['M18.5 15v4M16.5 17h4'],
  },
  buscar: { b: ['M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z'], a: ['m20 20-4-4'] },
  campana: { b: ['M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15z'], a: ['M10 21h4'] },
  mas: { b: ['M12 5v14M5 12h14'] },
  check: { b: ['m5 12.5 4.5 4.5L19 7.5'] },
  cerrar: { b: ['m6 6 12 12M18 6 6 18'] },
  der: { b: ['m9 6 6 6-6 6'] },
  izq: { b: ['m15 6-6 6 6 6'] },
  abajo: { b: ['m6 9 6 6 6-6'] },
  atras: { b: ['M19 12H5'], a: ['m11 6-6 6 6 6'] },
  pin: { b: ['M12 21s-6.5-5.6-6.5-10.5a6.5 6.5 0 0 1 13 0C18.5 15.4 12 21 12 21z'], a: ['M12 12.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4z'] },
  camara: {
    b: ['M4 8.5a1 1 0 0 1 1-1h2.5L9 5h6l1.5 2.5H19a1 1 0 0 1 1 1V18a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z'],
    a: ['M12 16a3 3 0 1 0 0-6 3 3 0 0 0 0 6z'],
  },
  candado: { b: ['M6 11h12v8a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1z'], a: ['M8.5 11V8a3.5 3.5 0 0 1 7 0v3'] },
  ojo: { b: ['M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6z'], a: ['M12 14.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z'] },
  discreto: {
    b: ['M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6z', 'M12 14.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z'],
    a: ['m4 4 16 16'],
  },
  idioma: { b: ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z', 'M3 12h18'], a: ['M12 3c2.5 2.5 3.5 5.5 3.5 9S14.5 18.5 12 21c-2.5-2.5-3.5-5.5-3.5-9S9.5 5.5 12 3z'] },
  sol: {
    b: ['M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z'],
    a: ['M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6 7 7M17 17l1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4'],
  },
  luna: { b: ['M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z'], a: ['M17 4.5v3M15.5 6h3'] },
  salir: { b: ['M10 4H6a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h4'], a: ['m15 8 4 4-4 4M19 12H9'] },
  basura: {
    b: ['M5 7h14M10 7V5h4v2M7 7l1 12a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1l1-12'],
    a: ['M10.5 11v5M13.5 11v5'],
  },
  descargar: { b: ['M5 15v3a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3'], a: ['M12 4v10M8 10.5l4 4 4-4'] },
  escudo: { b: ['M12 3l7 3v5.5c0 4.5-3 8-7 9.5-4-1.5-7-5-7-9.5V6z'], a: ['m9 12 2.2 2.2L15.5 10'] },
  estrella: { b: ['M12 4l2.4 5 5.4.7-4 3.8 1 5.4-4.8-2.7-4.8 2.7 1-5.4-4-3.8 5.4-.7z'] },
  enviar: { b: ['M20 4 4 10l6 4 4 6z'], a: ['M20 4 10 14'] },
  bandera: { b: ['M6 21V4'], a: ['M6 5h11l-2 4 2 4H6'] },
  corazon: { b: ['M12 20s-7.5-4.5-7.5-10a4.2 4.2 0 0 1 7.5-2.5A4.2 4.2 0 0 1 19.5 10c0 5.5-7.5 10-7.5 10z'] },
  telefono: { b: ['M5 5a1 1 0 0 1 1-1h2.6L10 8l-2 1.3a10 10 0 0 0 5.7 5.7l1.3-2 4 1.4V17a1 1 0 0 1-1 1A13 13 0 0 1 5 5z'] },
  reloj: { b: ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z'], a: ['M12 7v5l3 2'] },
  filtro: { b: ['M4 6h16M7 12h10'], a: ['M10 18h4'] },
  dolar: {
    b: ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z'],
    a: ['M14.5 9.5c-.4-1-1.4-1.5-2.5-1.5-1.4 0-2.5.8-2.5 2s1 1.7 2.5 2 2.5.8 2.5 2-1.1 2-2.5 2c-1.1 0-2.1-.5-2.5-1.5M12 6.5V8M12 16v1.5'],
  },
  ruta: { b: ['M9 5 4 7v12l5-2 6 2 5-2V5l-5 2z'], a: ['M9 5v12M15 7v12'] },
  lapiz: { b: ['M5 19l1-4L16.5 4.5a2 2 0 0 1 3 3L9 18z'], a: ['m14.5 6.5 3 3'] },
  info: { b: ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z'], a: ['M12 11v5'], dots: ['M12 8h.01'] },
  alerta: { b: ['M12 4 21 20H3z'], a: ['M12 10v4'], dots: ['M12 17h.01'] },
  wifioff: { b: ['M5 12.5a10 10 0 0 1 4-2.3M19 12.5a10 10 0 0 0-3-1.9M8.5 16a5 5 0 0 1 7 0'], a: ['m4 4 16 16'], dots: ['M12 19.5h.01'] },
} satisfies Record<string, Def>

export type IconName = keyof typeof ICONS

type Props = Omit<SVGProps<SVGSVGElement>, 'name'> & {
  name: IconName
  size?: number
  /** Relleno suave en la parte base (para el estado activo). */
  relleno?: boolean
  title?: string
}

export function Icon({ name, size = 24, relleno = false, title, className, ...rest }: Props) {
  const d = ICONS[name] as Def
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={'ic' + (relleno ? ' ic-fill' : '') + (className ? ' ' + className : '')}
      role={title ? 'img' : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
      {...rest}
    >
      <g className="ic-b" stroke="currentColor">{d.b.map((p) => <path key={p} d={p} />)}</g>
      {d.a && <g className="ic-a">{d.a.map((p) => <path key={p} d={p} />)}</g>}
      {d.dots && <g className="ic-a" strokeWidth={2.6}>{d.dots.map((p) => <path key={p} d={p} />)}</g>}
    </svg>
  )
}

export const NOMBRES_ICONOS = Object.keys(ICONS) as IconName[]
