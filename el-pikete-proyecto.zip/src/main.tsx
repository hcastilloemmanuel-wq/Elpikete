import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './styles.css'
import App from './App'
import { aplicarTema, temaGuardado } from './features/profile/Me'
import { getLang, setLang } from './i18n'

aplicarTema(temaGuardado())
setLang(getLang())

createRoot(document.getElementById('root') as HTMLElement).render(<StrictMode><App /></StrictMode>)
