import { useSyncExternalStore } from 'react'
import es from './es.json'
import pt from './pt.json'

export type Lang = 'es' | 'pt'
const dict: Record<Lang, Record<string, string>> = { es, pt }
const KEY = 'pk_lang'
let lang: Lang = (() => { try { return (localStorage.getItem(KEY) as Lang) === 'pt' ? 'pt' : 'es' } catch { return 'es' } })()
const subs = new Set<() => void>()

export function setLang(l: Lang) {
  lang = l
  try { localStorage.setItem(KEY, l) } catch { /* sin almacenamiento */ }
  document.documentElement.lang = l
  subs.forEach((f) => f())
}
export function getLang(): Lang { return lang }
export function t(key: string, vars?: Record<string, string | number>): string {
  let s = dict[lang][key] ?? dict.es[key] ?? key
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(v))
  return s
}
/** Hook: vuelve a dibujar cuando cambia el idioma. */
export function useLang(): Lang {
  return useSyncExternalStore((cb) => { subs.add(cb); return () => subs.delete(cb) }, () => lang)
}
export const IDIOMAS = { es, pt }
