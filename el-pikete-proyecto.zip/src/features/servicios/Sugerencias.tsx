import { sugerirOficios } from '../../lib/servicios'

export function Sugerencias({ texto, onElegir }: { texto: string; onElegir: (o: string) => void }) {
  const sug = sugerirOficios(texto).filter((o) => o.toLowerCase() !== texto.trim().toLowerCase())
  if (sug.length === 0) return null
  return (
    <ul className="chips sugerencias" aria-label="sugerencias">
      {sug.map((o) => <li key={o}><button type="button" className="chip" onClick={() => onElegir(o)}>{o}</button></li>)}
    </ul>
  )
}
