import { useState } from 'react'
import { t } from '../../i18n'
import { backend } from '../../lib/backend'
import { etiquetaReputacion } from '../../lib/servicios'
import type { Servicio } from '../../lib/servicios'
import { Avatar } from '../../ui/Baldosa'
import { Icon } from '../../ui/Icon'

/** Todo el texto del profesional se muestra como texto (React lo escapa): nunca como HTML. */
export function Tarjeta({ s }: { s: Servicio }) {
  const [msg, setMsg] = useState<string | null>(null)
  const nuevo = etiquetaReputacion(s) === 'nuevo'

  async function contactar() {
    setMsg(null)
    if (!s.mostrar_whatsapp || s.ejemplo) { setMsg(s.ejemplo ? 'svc.contacto_ejemplo' : 'svc.contacto_chat'); return }
    try {
      const num = await backend.verWhatsapp(s.user_id)
      if (!num) { setMsg('svc.contacto_chat'); return }
      const texto = encodeURIComponent(t('svc.wa_texto', { oficio: s.oficio }))
      window.open(`https://wa.me/${num.replace(/\D/g, '')}?text=${texto}`, '_blank', 'noopener,noreferrer')
    } catch { setMsg('err.no_disponible') }
  }

  return (
    <article className="tarjeta svc">
      <header className="svc-cab">
        <Avatar apodo={s.apodo} provincia={s.provincia_cuba} color={s.avatar_color} size={46} />
        <div className="svc-quien">
          <h2>{s.oficio}</h2>
          <span className="fino">{s.apodo}{s.provincia_cuba ? ` · ${s.provincia_cuba}` : ''}</span>
        </div>
        {s.ejemplo && <span className="sello-ej">{t('svc.ejemplo')}</span>}
      </header>
      <p className="svc-desc">{s.descripcion}</p>
      <p className="svc-dato"><Icon name="pin" size={16} /><span>{s.ciudad_nombre}{s.barrio && !(s.zonas ?? '').includes(s.barrio) ? `, ${s.barrio}` : ''}{s.zonas ? ` · ${s.zonas}` : ''}</span></p>
      {s.precio && <p className="svc-dato"><Icon name="dolar" size={16} /><span>{s.precio}</span></p>}
      {s.horario && <p className="svc-dato"><Icon name="reloj" size={16} /><span>{s.horario}</span></p>}
      <ul className="etiquetas">
        {s.disponible_hoy && <li className="et hoy">{t('svc.hoy')}</li>}
        {s.urgencias && <li className="et">{t('svc.urgencias')}</li>}
        {s.domicilio && <li className="et">{t('svc.domicilio')}</li>}
        {s.habla_pt && <li className="et">{t('svc.habla_pt')}</li>}
      </ul>
      <div className="svc-pie">
        <span className="rep">
          {nuevo
            ? <strong>{t('svc.nuevo')}</strong>
            : <strong><Icon name="estrella" size={16} relleno />{s.promedio?.toFixed(1)}</strong>}
          <span className="fino">{t('svc.trabajos', { n: s.trabajos })}{s.rapidez_min != null ? ` · ${t('svc.responde', { min: s.rapidez_min })}` : ''}</span>
        </span>
        <button className="boton chico" onClick={contactar}><Icon name="chat" size={18} />{t('svc.contactar')}</button>
      </div>
      {msg && <p className="fino" role="status">{t(msg)}</p>}
    </article>
  )
}
