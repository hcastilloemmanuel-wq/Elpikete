import { useEffect, useMemo, useState } from 'react'
import { t, useLang } from '../../i18n'
import { backend } from '../../lib/backend'
import { FILTROS_VACIOS, filtrarServicios, ordenarServicios } from '../../lib/servicios'
import type { Filtros, Orden, Servicio } from '../../lib/servicios'
import { useAuth } from '../auth/AuthProvider'
import { Icon } from '../../ui/Icon'
import { Avatar } from '../../ui/Baldosa'
import { Sugerencias } from './Sugerencias'
import { MiServicio } from './MiServicio'
import { Tarjeta } from './Tarjeta'

export default function Servicios() {
  useLang()
  const { perfil } = useAuth()
  const [lista, setLista] = useState<Servicio[] | null>(null)
  const [mio, setMio] = useState<Servicio | null>(null)
  const [error, setError] = useState(false)
  const [editando, setEditando] = useState(false)
  const [f, setF] = useState<Filtros>({ ...FILTROS_VACIOS, ciudad: perfil?.ciudad_ibge ?? null })
  const [orden, setOrden] = useState<Orden>('reputacion')

  const cargar = () => {
    setError(false)
    Promise.all([backend.listServicios(), backend.getMiServicio()])
      .then(([l, m]) => { setLista(l); setMio(m) })
      .catch(() => setError(true))
  }
  useEffect(cargar, [])

  const resultados = useMemo(() => ordenarServicios(filtrarServicios(lista ?? [], f), orden), [lista, f, orden])
  const set = (p: Partial<Filtros>) => setF((x) => ({ ...x, ...p }))
  const todasCiudades = f.ciudad == null

  if (editando) {
    return <MiServicio actual={mio} onListo={() => { setEditando(false); cargar() }} onCancelar={() => setEditando(false)} />
  }

  return (
    <div className="stack servicios">
      <h1>{t('svc.titulo')}</h1>
      <p className="sub">{t('svc.sub')}</p>

      <div className="buscador">
        <Icon name="buscar" size={20} />
        <input type="search" value={f.texto} onChange={(e) => set({ texto: e.target.value })} placeholder={t('svc.buscar')} aria-label={t('svc.buscar')} autoComplete="off" />
      </div>
      <Sugerencias texto={f.texto} onElegir={(o) => set({ texto: o })} />

      <div className="chips" role="group" aria-label={t('svc.filtros')}>
        <button className={'chip' + (!todasCiudades ? ' on' : '')} aria-pressed={!todasCiudades} onClick={() => set({ ciudad: todasCiudades ? perfil?.ciudad_ibge ?? null : null })}>
          <Icon name="pin" size={16} /> {todasCiudades ? t('svc.todas_ciudades') : perfil?.ciudad_nombre}
        </button>
        {([['disponible_hoy', 'svc.hoy'], ['habla_pt', 'svc.habla_pt'], ['domicilio', 'svc.domicilio'], ['urgencias', 'svc.urgencias']] as const).map(([k, tx]) => (
          <button key={k} className={'chip' + (f[k] ? ' on' : '')} aria-pressed={f[k]} onClick={() => set({ [k]: !f[k] })}>{t(tx)}</button>
        ))}
      </div>

      <div className="fila-orden">
        <input type="text" value={f.barrio} onChange={(e) => set({ barrio: e.target.value })} placeholder={t('svc.barrio')} aria-label={t('svc.barrio')} />
        <select value={orden} onChange={(e) => setOrden(e.target.value as Orden)} aria-label={t('svc.orden')}>
          <option value="reputacion">{t('svc.orden_reputacion')}</option>
          <option value="trabajos">{t('svc.orden_trabajos')}</option>
          <option value="rapidez">{t('svc.orden_rapidez')}</option>
        </select>
      </div>

      <section className="tarjeta mi-servicio" aria-label={t('svc.mio')}>
        {mio ? (<>
          <div className="mi-fila"><Avatar apodo={mio.apodo} provincia={mio.provincia_cuba} color={mio.avatar_color} size={40} /><div><strong>{mio.oficio}</strong><small>{t('svc.mio_activo')}</small></div></div>
          <button className="boton sec" onClick={() => setEditando(true)}><Icon name="lapiz" size={18} />{t('svc.editar')}</button>
        </>) : (<>
          <strong>{t('svc.ofrecer_titulo')}</strong>
          <small>{t('svc.ofrecer_texto')}</small>
          <button className="boton" onClick={() => setEditando(true)}>{t('svc.ofrecer')}</button>
        </>)}
      </section>

      {error && (
        <div className="tarjeta vacia"><p role="alert">{t('err.no_disponible')}</p><button className="boton sec" onClick={cargar}>{t('svc.reintentar')}</button></div>
      )}
      {!error && lista == null && <p className="fino">{t('common.cargando')}</p>}
      {!error && lista != null && resultados.length === 0 && (
        <div className="tarjeta vacia">
          <strong>{t('svc.vacio_titulo')}</strong>
          <p className="sub">{t('svc.vacio_texto')}</p>
          {!todasCiudades && <button className="boton sec" onClick={() => set({ ciudad: null })}>{t('svc.ver_todas')}</button>}
        </div>
      )}
      <ul className="lista-svc" aria-live="polite">
        {resultados.map((s) => <li key={s.id}><Tarjeta s={s} /></li>)}
      </ul>
      <p className="fino">{t('svc.aviso')}</p>
    </div>
  )
}
