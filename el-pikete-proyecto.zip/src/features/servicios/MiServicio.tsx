import { useState } from 'react'
import { t } from '../../i18n'
import { backend } from '../../lib/backend'
import { validarServicio } from '../../lib/servicios'
import type { BorradorServicio, Servicio } from '../../lib/servicios'
import { useAuth } from '../auth/AuthProvider'
import { Icon } from '../../ui/Icon'
import { Sugerencias } from './Sugerencias'

export function MiServicio({ actual, onListo, onCancelar }: { actual: Servicio | null; onListo: () => void; onCancelar: () => void }) {
  const { perfil } = useAuth()
  const [b, setB] = useState<BorradorServicio>({
    oficio: actual?.oficio ?? perfil?.oficios[0] ?? '', descripcion: actual?.descripcion ?? '', zonas: actual?.zonas ?? '',
    precio: actual?.precio ?? '', horario: actual?.horario ?? '', habla_pt: actual?.habla_pt ?? false,
    domicilio: actual?.domicilio ?? false, urgencias: actual?.urgencias ?? false,
    disponible_hoy: actual?.disponible_hoy ?? false, mostrar_whatsapp: actual?.mostrar_whatsapp ?? false,
  })
  const [error, setError] = useState<string | null>(null)
  const [guardando, setGuardando] = useState(false)
  const set = (p: Partial<BorradorServicio>) => setB((x) => ({ ...x, ...p }))

  async function guardar(e?: React.FormEvent) {
    e?.preventDefault()
    const limpio: BorradorServicio = { ...b, oficio: b.oficio.trim(), descripcion: b.descripcion.trim(), zonas: b.zonas?.trim() || null, precio: b.precio?.trim() || null, horario: b.horario?.trim() || null }
    const err = validarServicio(limpio)
    if (err) { setError(err); return }
    setGuardando(true); setError(null)
    try { await backend.saveMiServicio(limpio); onListo() } catch { setError('no_se_guardo'); setGuardando(false) }
  }
  async function quitar() {
    setGuardando(true)
    try { await backend.deleteMiServicio(); onListo() } catch { setError('no_se_guardo'); setGuardando(false) }
  }

  const casillas = [['disponible_hoy', 'svc.hoy'], ['urgencias', 'svc.urgencias'], ['domicilio', 'svc.domicilio'], ['habla_pt', 'svc.habla_pt'], ['mostrar_whatsapp', 'svc.mostrar_wa']] as const

  return (
    <form className="stack" onSubmit={guardar} noValidate>
      <button type="button" className="atras" onClick={onCancelar}><Icon name="atras" size={20} />{t('onb.atras')}</button>
      <h1>{actual ? t('svc.editar') : t('svc.ofrecer')}</h1>
      <p className="sub">{t('svc.form_sub')}</p>

      <label htmlFor="s-oficio">{t('svc.f_oficio')}</label>
      <input id="s-oficio" type="text" value={b.oficio} maxLength={60} onChange={(e) => set({ oficio: e.target.value })} autoComplete="off" />
      <Sugerencias texto={b.oficio} onElegir={(o) => set({ oficio: o })} />

      <label htmlFor="s-desc">{t('svc.f_descripcion')}</label>
      <textarea id="s-desc" rows={4} maxLength={400} value={b.descripcion} onChange={(e) => set({ descripcion: e.target.value })} />
      <small>{b.descripcion.length}/400</small>

      <label htmlFor="s-zonas">{t('svc.f_zonas')}</label>
      <input id="s-zonas" type="text" maxLength={120} value={b.zonas ?? ''} onChange={(e) => set({ zonas: e.target.value })} />
      <label htmlFor="s-precio">{t('svc.f_precio')}</label>
      <input id="s-precio" type="text" maxLength={60} value={b.precio ?? ''} onChange={(e) => set({ precio: e.target.value })} placeholder={t('svc.f_precio_ej')} />
      <label htmlFor="s-horario">{t('svc.f_horario')}</label>
      <input id="s-horario" type="text" maxLength={60} value={b.horario ?? ''} onChange={(e) => set({ horario: e.target.value })} />

      {casillas.map(([k, tx]) => (
        <label key={k} className="casilla"><input type="checkbox" checked={b[k]} onChange={(e) => set({ [k]: e.target.checked })} /> {t(tx)}</label>
      ))}
      <small>{t('svc.mostrar_wa_ayuda')}</small>

      {error && <p className="error" role="alert"><Icon name="alerta" size={20} />{t('err.' + error)}</p>}
      <button type="button" className="boton" disabled={guardando} onClick={() => void guardar()}>{t('svc.guardar')}</button>
      {actual && <button type="button" className="boton sec peligro-txt" disabled={guardando} onClick={quitar}><Icon name="basura" size={18} />{t('svc.quitar')}</button>}
    </form>
  )
}
