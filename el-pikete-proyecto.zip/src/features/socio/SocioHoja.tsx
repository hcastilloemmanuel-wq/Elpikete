import { useEffect, useRef, useState } from 'react'
import { getLang, t } from '../../i18n'
import { backend, BackendError } from '../../lib/backend'
import { PREGUNTAS_EJEMPLO } from '../../lib/socio'
import { Icon } from '../../ui/Icon'

interface Msg { de: 'yo' | 'socio'; texto: string; oficial?: string }

export function SocioHoja({ cerrar }: { cerrar: () => void }) {
  const [msgs, setMsgs] = useState<Msg[]>([{ de: 'socio', texto: t('socio.saludo') }])
  const [texto, setTexto] = useState('')
  const [pensando, setPensando] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [basico, setBasico] = useState(false)
  const fin = useRef<HTMLDivElement>(null)
  useEffect(() => { fin.current?.scrollIntoView?.({ block: 'end' }) }, [msgs, pensando])

  async function preguntar(q: string) {
    const m = q.trim()
    if (!m || pensando) return
    setMsgs((x) => [...x, { de: 'yo', texto: m }]); setTexto(''); setPensando(true); setError(null)
    try {
      const r = await backend.preguntarSocio(m, getLang())
      if (r.demo && backend.mode !== 'demo') setBasico(true)
      setMsgs((x) => [...x, { de: 'socio', texto: r.clave ? t(r.texto) : r.texto, oficial: r.oficial }])
    } catch (e) {
      setError(e instanceof BackendError && e.code === 'socio_limite' ? 'socio_limite' : 'socio_error')
    }
    setPensando(false)
  }

  return (
    <div className="hoja-fondo" role="presentation" onClick={cerrar}>
      <div className="hoja socio-hoja" role="dialog" aria-modal="true" aria-label={t('socio.nombre')} onClick={(e) => e.stopPropagation()}>
        <div className="socio-cab"><h2>{t('socio.nombre')}</h2><button type="button" className="chip chico" onClick={cerrar}>{t('socio.cerrar')}</button></div>
        {backend.mode === 'demo' && <p className="fino">{t('socio.demo')}</p>}
        {basico && <p className="fino">{t('socio.basico')}</p>}
        <div className="hilo" aria-live="polite">
          {msgs.map((m, i) => (
            <p key={i} className={'burbuja' + (m.de === 'yo' ? ' mia' : '')}>{m.texto}{m.oficial && <small className="fino"> {t('socio.oficial', { sitio: m.oficial })}</small>}</p>
          ))}
          {pensando && <p className="burbuja" aria-label={t('socio.escribiendo')}>…</p>}
          <div ref={fin} />
        </div>
        {msgs.length === 1 && <div className="chips">{PREGUNTAS_EJEMPLO.map((k) => <button key={k} type="button" className="chip chico" onClick={() => void preguntar(t(k))}>{t(k)}</button>)}</div>}
        {error && <p className="error" role="alert"><Icon name="alerta" size={20} />{t('err.' + error)}</p>}
        <p className="fino">{t('socio.aviso')}</p>
        <div className="fila-com">
          <input type="text" value={texto} maxLength={500} onChange={(e) => setTexto(e.target.value)} placeholder={t('socio.ph')} aria-label={t('socio.ph')} onKeyDown={(e) => { if (e.key === 'Enter') void preguntar(texto) }} />
          <button type="button" className="boton chico" disabled={pensando} onClick={() => void preguntar(texto)}><Icon name="enviar" size={18} /><span className="sr">{t('cuadra.enviar')}</span></button>
        </div>
      </div>
    </div>
  )
}
