import { useEffect, useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { backend, BackendError } from '../../lib/backend'
import type { Contacto, Perfil, VisOficio, VisWhatsapp } from '../../lib/backend'
import { ESTADOS_BR, OFICIOS_PLANOS, PROPOSITOS, PROVINCIAS_CUBA } from '../../lib/data'
import { normalizarTexto, normalizarWhatsapp, validarWhatsapp } from '../../lib/validate'
import { t, useLang } from '../../i18n'
import { useAuth } from '../auth/AuthProvider'
import { Logo } from '../shell/Logo'
import { CityPicker } from './CityPicker'

const COLORES = ['#2B3FD4', '#FFC93C', '#E03A3E', '#0E9F96', '#F6B7CB', '#7A4FD0', '#F28A2E', '#3E9B4F']

function Radios<T extends string>({ nombre, valor, opciones, onCambio }: { nombre: string; valor: T; opciones: { v: T; k: string }[]; onCambio: (v: T) => void }) {
  return (
    <div role="radiogroup" className="radios">
      {opciones.map((o) => (
        <label key={o.v} className={'radio' + (valor === o.v ? ' on' : '')}>
          <input type="radio" name={nombre} checked={valor === o.v} onChange={() => onCambio(o.v)} /> {t(o.k)}
        </label>
      ))}
    </div>
  )
}

export default function Onboarding() {
  useLang()
  const { sesion, perfil, cargando, setPerfil } = useAuth()
  const nav = useNavigate()
  const [paso, setPaso] = useState(2)
  const [f, setF] = useState<Perfil | null>(null)
  const [contacto, setContacto] = useState<Contacto>({ whatsapp: null, whatsapp_visibilidad: 'nadie' })
  const [wa, setWa] = useState('')
  const [nuevoOficio, setNuevoOficio] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [guardando, setGuardando] = useState(false)

  useEffect(() => {
    if (perfil && !f) { setF(perfil); setPaso(Math.min(7, Math.max(2, perfil.paso || 2))) }
  }, [perfil, f])
  useEffect(() => {
    if (!sesion) return
    backend.getContacto().then((c) => { setContacto(c); setWa(c.whatsapp ?? '') }).catch(() => undefined)
  }, [sesion])

  if (cargando) return <main className="pantalla centrada"><p>{t('common.cargando')}</p></main>
  if (!sesion) return <Navigate to="/entrar" replace />
  if (perfil?.completado) return <Navigate to="/" replace />
  if (!f) return <main className="pantalla centrada"><p>{t('common.cargando')}</p></main>

  const set = (p: Partial<Perfil>) => setF({ ...f, ...p })

  async function guardar(patch: Partial<Perfil>, siguiente: number, extra?: () => Promise<unknown>) {
    if (guardando || !f) return
    setGuardando(true); setError(null)
    try {
      if (extra) await extra()
      const nuevo = await backend.savePerfil({ ...patch, paso: Math.max(siguiente, 2) })
      setPerfil(nuevo); setF(nuevo)
      if (patch.completado) nav('/', { replace: true }); else setPaso(siguiente)
    } catch (e) { setError(e instanceof BackendError ? e.code : 'no_se_guardo') }
    finally { setGuardando(false) }
  }

  function siguiente() {
    if (!f) return
    setError(null)
    if (paso === 2) {
      if (!f.provincia_cuba) return setError('falta_provincia')
      return void guardar({ provincia_cuba: f.provincia_cuba }, 3)
    }
    if (paso === 3) {
      if (!f.estado_br) return setError('falta_estado')
      if (!f.ciudad_ibge) return setError('falta_ciudad')
      return void guardar({ estado_br: f.estado_br, ciudad_ibge: f.ciudad_ibge, ciudad_nombre: f.ciudad_nombre, barrio: f.barrio?.trim() || null, recien_llegado: f.recien_llegado }, 4)
    }
    if (paso === 4) return void guardar({ oficios: f.oficios, oficio_visibilidad: f.oficio_visibilidad }, 5)
    if (paso === 5) {
      const problema = validarWhatsapp(wa)
      if (problema) return setError(problema)
      const num = wa.trim() ? normalizarWhatsapp(wa) : null
      return void guardar({}, 6, async () => setContacto(await backend.saveContacto({ whatsapp: num, whatsapp_visibilidad: num ? contacto.whatsapp_visibilidad : 'nadie' })))
    }
    if (paso === 6) return void guardar({ propositos: f.propositos, recien_llegado: f.recien_llegado || f.propositos.includes('llegue') }, 7)
    return void guardar({ frase: f.frase?.trim() || null, avatar_color: f.avatar_color, modo_discreto: f.modo_discreto, completado: true }, 7)
  }

  function saltar() {
    if (paso === 4) return void guardar({ oficios: [], oficio_visibilidad: 'todos' }, 5)
    if (paso === 5) return void guardar({}, 6, async () => { setWa(''); setContacto(await backend.saveContacto({ whatsapp: null, whatsapp_visibilidad: 'nadie' })) })
  }

  const sugeridos = (() => {
    const n = normalizarTexto(nuevoOficio.trim())
    return OFICIOS_PLANOS.filter((o) => !f.oficios.includes(o) && (!n || normalizarTexto(o).includes(n))).slice(0, 8)
  })()
  const agregarOficio = (o: string) => {
    const limpio = o.trim().slice(0, 40)
    if (limpio && !f.oficios.includes(limpio) && f.oficios.length < 6) set({ oficios: [...f.oficios, limpio] })
    setNuevoOficio('')
  }

  return (
    <main className="pantalla">
      <header className="onb-cab">
        <Logo />
        <span className="paso">{t('onb.paso', { n: paso })}</span>
      </header>
      <div className="progreso" aria-hidden="true"><span style={{ width: `${(paso / 7) * 100}%` }} /></div>

      <section className="tarjeta">
        {paso === 2 && (<>
          <h1>{t('onb.origen.titulo')}</h1>
          <p className="sub">{t('onb.origen.sub')}</p>
          <label htmlFor="prov">{t('onb.origen.label')}</label>
          <select id="prov" value={f.provincia_cuba ?? ''} onChange={(e) => set({ provincia_cuba: e.target.value || null })}>
            <option value="">{t('onb.origen.placeholder')}</option>
            {PROVINCIAS_CUBA.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
        </>)}

        {paso === 3 && (<>
          <h1>{t('onb.vives.titulo')}</h1>
          <label htmlFor="uf">{t('onb.vives.estado')}</label>
          <select id="uf" value={f.estado_br ?? ''} onChange={(e) => set({ estado_br: e.target.value || null, ciudad_ibge: null, ciudad_nombre: null })}>
            <option value="">{t('onb.vives.estado_ph')}</option>
            {ESTADOS_BR.map((e) => <option key={e.uf} value={e.uf}>{e.nombre}</option>)}
          </select>
          {f.estado_br && (<>
            <label>{t('onb.vives.ciudad')}</label>
            <CityPicker uf={f.estado_br} valor={f.ciudad_ibge} onElegir={(c) => set({ ciudad_ibge: c.ibge, ciudad_nombre: c.nombre })} />
          </>)}
          <label htmlFor="barrio">{t('onb.vives.barrio')}</label>
          <input id="barrio" value={f.barrio ?? ''} maxLength={60} onChange={(e) => set({ barrio: e.target.value })} />
          <label className="casilla"><input type="checkbox" checked={f.recien_llegado} onChange={(e) => set({ recien_llegado: e.target.checked })} /> {t('onb.vives.recien')}</label>
        </>)}

        {paso === 4 && (<>
          <h1>{t('onb.oficio.titulo')} <span className="etiqueta">{t('onb.sugerido')}</span></h1>
          <p className="sub">{t('onb.oficio.sub')}</p>
          <div className="chips">{f.oficios.map((o) => <button type="button" key={o} className="chip on" onClick={() => set({ oficios: f.oficios.filter((x) => x !== o) })}>{o} ✕</button>)}</div>
          <input aria-label={t('onb.oficio.buscar')} placeholder={t('onb.oficio.buscar')} value={nuevoOficio} maxLength={40}
            onChange={(e) => setNuevoOficio(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); agregarOficio(nuevoOficio) } }} />
          <div className="chips">
            {sugeridos.map((o) => <button type="button" key={o} className="chip" onClick={() => agregarOficio(o)}>{o}</button>)}
            {nuevoOficio.trim() && !OFICIOS_PLANOS.some((o) => normalizarTexto(o) === normalizarTexto(nuevoOficio.trim())) &&
              <button type="button" className="chip" onClick={() => agregarOficio(nuevoOficio)}>+ {t('onb.oficio.agregar')} “{nuevoOficio.trim()}”</button>}
          </div>
          {f.oficios.length > 0 && (<>
            <p className="etq">{t('onb.oficio.vis')}</p>
            <Radios<VisOficio> nombre="visof" valor={f.oficio_visibilidad} onCambio={(v) => set({ oficio_visibilidad: v })}
              opciones={[{ v: 'todos', k: 'vis.todos' }, { v: 'amigos', k: 'vis.amigos' }, { v: 'servicios', k: 'vis.servicios' }]} />
            <p className="fino">{t('onb.oficio.servicio')}</p>
          </>)}
        </>)}

        {paso === 5 && (<>
          <h1>{t('onb.wa.titulo')} <span className="etiqueta">{t('onb.opcional')}</span></h1>
          <p className="sub">{t('onb.wa.sub')}</p>
          <label htmlFor="wa">{t('onb.wa.label')}</label>
          <input id="wa" inputMode="tel" autoComplete="tel" placeholder="+55 95 99999-9999" value={wa} onChange={(e) => setWa(e.target.value)} />
          <small>{t('onb.wa.ayuda')}</small>
          {wa.trim() && (<>
            <p className="etq">{t('onb.wa.quien')}</p>
            <Radios<VisWhatsapp> nombre="viswa" valor={contacto.whatsapp_visibilidad} onCambio={(v) => setContacto({ ...contacto, whatsapp_visibilidad: v })}
              opciones={[{ v: 'nadie', k: 'vis.nadie' }, { v: 'amigos', k: 'vis.amigos' }, { v: 'todos', k: 'vis.todos' }]} />
          </>)}
        </>)}

        {paso === 6 && (<>
          <h1>{t('onb.prop.titulo')}</h1>
          <p className="sub">{t('onb.prop.sub')}</p>
          <div className="chips grandes">
            {PROPOSITOS.map((p) => {
              const on = f.propositos.includes(p)
              return <button type="button" key={p} aria-pressed={on} className={'chip' + (on ? ' on' : '')}
                onClick={() => set({ propositos: on ? f.propositos.filter((x) => x !== p) : [...f.propositos, p] })}>{t('prop.' + p)}</button>
            })}
          </div>
        </>)}

        {paso === 7 && (<>
          <h1>{t('onb.cierre.titulo')}</h1>
          <label htmlFor="frase">{t('onb.cierre.frase')}</label>
          <input id="frase" maxLength={120} placeholder={t('onb.cierre.frase_ph')} value={f.frase ?? ''} onChange={(e) => set({ frase: e.target.value })} />
          <p className="etq">{t('onb.cierre.color')}</p>
          <div className="colores">{COLORES.map((c) => <button type="button" key={c} aria-label={c} aria-pressed={f.avatar_color === c} className={f.avatar_color === c ? 'sel' : ''} style={{ background: c }} onClick={() => set({ avatar_color: c })} />)}</div>
          <small>{t('onb.cierre.foto')}</small>
          <label className="casilla grande"><input type="checkbox" checked={f.modo_discreto} onChange={(e) => set({ modo_discreto: e.target.checked })} /> <span><strong>{t('onb.cierre.discreto')}</strong><br /><small>{t('onb.cierre.discreto_ayuda')}</small></span></label>
        </>)}

        {error && <p className="error" role="alert">{t('err.' + error)}</p>}
        <div className="acciones">
          {paso > 2 && <button type="button" className="boton sec" disabled={guardando} onClick={() => { setError(null); setPaso(paso - 1) }}>{t('onb.atras')}</button>}
          <button type="button" className="boton" disabled={guardando} onClick={siguiente}>{guardando ? t('onb.guardando') : paso === 7 ? t('onb.cierre.terminar') : t('onb.siguiente')}</button>
        </div>
        {(paso === 4 || paso === 5) && <button type="button" className="enlace centro" disabled={guardando} onClick={saltar}>{t('onb.saltar')}</button>}
      </section>
    </main>
  )
}
