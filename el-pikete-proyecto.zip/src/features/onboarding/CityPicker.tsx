import { useEffect, useMemo, useState } from 'react'
import { ciudadesDe } from '../../lib/data'
import type { Ciudad } from '../../lib/data'
import { normalizarTexto } from '../../lib/validate'
import { t } from '../../i18n'

interface Props { uf: string; valor: number | null; onElegir: (c: Ciudad) => void }

export function CityPicker({ uf, valor, onElegir }: Props) {
  const [lista, setLista] = useState<Ciudad[]>([])
  const [cargando, setCargando] = useState(true)
  const [q, setQ] = useState('')

  useEffect(() => {
    let vivo = true
    setCargando(true); setQ('')
    ciudadesDe(uf).then((l) => { if (vivo) { setLista(l); setCargando(false) } })
    return () => { vivo = false }
  }, [uf])

  const filtradas = useMemo(() => {
    const n = normalizarTexto(q.trim())
    const base = n ? lista.filter((c) => normalizarTexto(c.nombre).includes(n)) : lista
    return base.slice(0, 40)
  }, [lista, q])
  const elegida = lista.find((c) => c.ibge === valor)

  return (
    <div>
      {elegida && <p className="elegida">{t('onb.vives.elegida')}: <strong>{elegida.nombre}</strong></p>}
      <input aria-label={t('onb.vives.ciudad')} placeholder={t('onb.vives.buscar')} value={q} onChange={(e) => setQ(e.target.value)} autoComplete="off" />
      {cargando ? <p className="fino">{t('common.cargando')}</p> : (
        <ul className="lista-ciudades" role="listbox" aria-label={t('onb.vives.ciudad')}>
          {filtradas.map((c) => (
            <li key={c.ibge}>
              <button type="button" role="option" aria-selected={c.ibge === valor} className={c.ibge === valor ? 'sel' : ''} onClick={() => onElegir(c)}>{c.nombre}</button>
            </li>
          ))}
          {filtradas.length === 0 && <li className="fino">{t('onb.vives.sin_resultados')}</li>}
        </ul>
      )}
    </div>
  )
}
