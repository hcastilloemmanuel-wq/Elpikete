import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { backend } from '../../lib/backend'
import type { AlcanceSalida, Perfil, Sesion } from '../../lib/backend'
import { limpiarCachePrivada } from '../../lib/storage'

interface Ctx {
  sesion: Sesion | null
  perfil: Perfil | null
  cargando: boolean
  setPerfil: (p: Perfil) => void
  recargar: () => Promise<void>
  salir: (scope: AlcanceSalida) => Promise<void>
}
const AuthCtx = createContext<Ctx | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [sesion, setSesion] = useState<Sesion | null>(null)
  const [perfil, setPerfil] = useState<Perfil | null>(null)
  const [cargando, setCargando] = useState(true)

  const cargarPerfil = useCallback(async (s: Sesion | null) => {
    if (!s) { setPerfil(null); return }
    try { setPerfil(await backend.getPerfil()) } catch { setPerfil(null) }
  }, [])

  useEffect(() => {
    let vivo = true
    ;(async () => {
      const s = await backend.getSession().catch(() => null)
      if (!vivo) return
      setSesion(s); await cargarPerfil(s); if (vivo) setCargando(false)
    })()
    const off = backend.onAuthChange((s) => {
      setSesion((prev) => (prev?.userId === s?.userId ? prev : s))
      if (!s) { limpiarCachePrivada(); setPerfil(null) } else void cargarPerfil(s)
    })
    return () => { vivo = false; off() }
  }, [cargarPerfil])

  const salir = useCallback(async (scope: AlcanceSalida) => {
    await backend.signOut(scope)
    limpiarCachePrivada(); setSesion(null); setPerfil(null)
  }, [])

  const valor = useMemo<Ctx>(() => ({
    sesion, perfil, cargando, setPerfil, salir,
    recargar: async () => { await cargarPerfil(sesion) },
  }), [sesion, perfil, cargando, salir, cargarPerfil])

  return <AuthCtx.Provider value={valor}>{children}</AuthCtx.Provider>
}

export function useAuth(): Ctx {
  const c = useContext(AuthCtx)
  if (!c) throw new Error('useAuth fuera de AuthProvider')
  return c
}
