import { useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import { Navigate } from 'react-router-dom'
import { backend, BackendError } from '../../lib/backend'
import { DEMO_MODE } from '../../lib/config'
import { getRemember, setRemember } from '../../lib/storage'
import { identificador, validarApodo, validarCodigo, validarCorreo, validarTelefono } from '../../lib/validate'
import { t, useLang } from '../../i18n'
import { Logo } from '../shell/Logo'
import { useAuth } from './AuthProvider'
import { Icon } from '../../ui/Icon'
import { BaldosaCampo } from '../../ui/Baldosa'

const MOSAICO = [
  { d: 0, p: 0 }, { d: 1, p: 4 }, { d: 2, p: 3 }, { d: 4, p: 2 },
  { d: 5, p: 4 }, { d: 3, p: 0 }, { d: 0, p: 2 }, { d: 1, p: 3 },
]

export default function Login() {
  useLang()
  const { sesion, perfil, cargando } = useAuth()
  const [fase, setFase] = useState<'datos' | 'codigo'>('datos')
  const [apodo, setApodo] = useState('')
  const [via, setVia] = useState<'correo' | 'telefono'>('correo')
  const [correo, setCorreo] = useState('')
  const [telefono, setTelefono] = useState('')
  const [mayor, setMayor] = useState(false)
  const [mio, setMio] = useState(getRemember())
  const [codigo, setCodigo] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [enviando, setEnviando] = useState(false)
  const [espera, setEspera] = useState(0)

  useEffect(() => {
    if (espera <= 0) return
    const id = setTimeout(() => setEspera((e) => e - 1), 1000)
    return () => clearTimeout(id)
  }, [espera])

  if (!cargando && sesion) return <Navigate to={perfil?.completado ? '/' : '/registro'} replace />

  async function enviar(e?: FormEvent) {
    e?.preventDefault()
    if (enviando) return
    const problema = validarApodo(apodo) ?? (via === 'correo' ? validarCorreo(correo) : validarTelefono(telefono)) ?? (mayor ? null : 'falta_mayor')
    if (problema) { setError(problema); return }
    setError(null); setEnviando(true); setRemember(mio)
    try { await backend.requestCode(identificador(via, correo, telefono), apodo.trim()); setFase('codigo'); setEspera(30); setTimeout(() => document.querySelector('.entrada-hoja')?.scrollIntoView?.({ behavior: 'smooth', block: 'start' }), 60) }
    catch (err) { setError(err instanceof BackendError ? err.code : 'no_se_envio') }
    finally { setEnviando(false) }
  }

  async function verificar(e?: FormEvent) {
    e?.preventDefault()
    if (enviando) return
    const problema = validarCodigo(codigo)
    if (problema) { setError(problema); return }
    setError(null); setEnviando(true)
    try { await backend.verifyCode(identificador(via, correo, telefono), codigo) }
    catch (err) { setError(err instanceof BackendError ? err.code : 'codigo_incorrecto') }
    finally { setEnviando(false) }
  }

  return (
    <main className="entrada">
      <header className="entrada-cab">
        <div className="entrada-mosaico">
          <BaldosaCampo columnas={4} filas={2} celdas={MOSAICO} />
        </div>
        <div className="entrada-texto">
          <Logo grande claro />
          <p className="entrada-lema">{t('login.lema')}</p>
        </div>
      </header>
      <div className="entrada-hoja">
      {DEMO_MODE && fase === 'datos' && <p className="aviso-demo" role="note"><Icon name="info" size={20} />{t('demo.aviso')}</p>}
      {fase === 'datos' ? (
        <form onSubmit={enviar} noValidate className="tarjeta">
          <h1>{t('login.titulo')}</h1>
          <p className="sub">{t(via === 'correo' ? 'login.sub_correo' : 'login.sub_telefono')}</p>
          <label htmlFor="apodo">{t('login.apodo')}</label>
          <input id="apodo" value={apodo} onChange={(e) => setApodo(e.target.value)} autoComplete="nickname" maxLength={40} />
          <small>{t('login.apodo_ayuda')}</small>
          <p className="etq" id="via-etq">{t('login.entrar_con')}</p>
          <div className="via" role="group" aria-labelledby="via-etq">
            {(['correo', 'telefono'] as const).map((v) => (
              <button type="button" key={v} className={'via-op' + (via === v ? ' on' : '')} aria-pressed={via === v} onClick={() => { setVia(v); setError(null) }}>
                <Icon name={v === 'correo' ? 'noticias' : 'telefono'} size={18} />{t('login.via_' + v)}
              </button>
            ))}
          </div>
          {via === 'correo' ? (<>
            <label htmlFor="correo">{t('login.correo')}</label>
            <input id="correo" type="email" inputMode="email" autoComplete="email" value={correo} onChange={(e) => setCorreo(e.target.value)} />
          </>) : (<>
            <label htmlFor="telefono">{t('login.telefono')}</label>
            <input id="telefono" type="tel" inputMode="tel" autoComplete="tel" placeholder="+55 95 99999-9999" value={telefono} onChange={(e) => setTelefono(e.target.value)} />
            <small>{t('login.telefono_ayuda')}</small>
          </>)}
          <label className="casilla"><input type="checkbox" checked={mayor} onChange={(e) => setMayor(e.target.checked)} /> {t('login.mayor')}</label>
          <label className="casilla"><input type="checkbox" checked={mio} onChange={(e) => setMio(e.target.checked)} /> {t('login.mi_telefono')}</label>
          <small>{t('login.mi_telefono_ayuda')}</small>
          {error && <p className="error" role="alert"><Icon name="alerta" size={20} />{t('err.' + error)}</p>}
          <button type="button" className="boton" disabled={enviando} onClick={() => void enviar()}>{enviando ? t('login.enviando') : t('login.enviar')}</button>
          <p className="fino">{t('login.privacidad')}</p>
        </form>
      ) : (
        <form onSubmit={verificar} noValidate className="tarjeta">
          <h1>{t(via === 'correo' ? 'login.codigo_titulo' : 'login.codigo_titulo_tel')}</h1>
          <p className="sub">{t(via === 'correo' ? 'login.codigo_sub' : 'login.codigo_sub_tel', { correo: via === 'correo' ? correo.trim() : identificador(via, correo, telefono) })}</p>
          {DEMO_MODE && (
            <div className="aviso-demo demo-codigo" role="note">
              <Icon name="info" size={20} />
              <div>
                <strong>{t('login.demo_codigo_titulo')}</strong>
                <p>{t('login.demo_codigo_texto', { medio: t('login.medio_' + via) })}</p>
                <button type="button" className="enlace" onClick={() => setCodigo('123456')}>{t('login.demo_poner')}</button>
              </div>
            </div>
          )}
          <label htmlFor="codigo">{t('login.codigo')}</label>
          <input id="codigo" className="codigo" inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={codigo}
            onChange={(e) => setCodigo(e.target.value.replace(/\D/g, ''))} autoFocus />
          {error && <p className="error" role="alert"><Icon name="alerta" size={20} />{t('err.' + error)}</p>}
          <button type="button" className="boton" disabled={enviando} onClick={() => void verificar()}>{t('login.entrar')}</button>
          <div className="fila">
            <button type="button" className="enlace" onClick={() => { setFase('datos'); setCodigo(''); setError(null) }}>{t(via === 'correo' ? 'login.cambiar_correo' : 'login.cambiar_telefono')}</button>
            <button type="button" className="enlace" disabled={espera > 0 || enviando} onClick={() => void enviar()}>
              {t('login.reenviar')}{espera > 0 ? ` (${espera})` : ''}
            </button>
          </div>
        </form>
      )}
      </div>
    </main>
  )
}
