import { useEffect, useState } from 'react'
import { t, useLang } from '../../i18n'
import { aDolares, aReales, cargarTasas, FUENTES } from '../../lib/cambio'
import type { Tasas } from '../../lib/cambio'
import { Icon } from '../../ui/Icon'

export default function Noticias() {
  useLang()
  const [tasas, setTasas] = useState<Tasas | null | undefined>(undefined)
  const [monto, setMonto] = useState('100')
  const [saliendo, setSaliendo] = useState<{ nombre: string; url: string } | null>(null)
  const cargar = () => { setTasas(undefined); void cargarTasas().then(setTasas) }
  useEffect(cargar, [])

  const n = Number(monto.replace(',', '.'))
  const valido = Number.isFinite(n) && n >= 0

  return (
    <div className="stack">
      <h1>{t('nav.noticias')}</h1>
      <p className="sub">{t('noticias.sub')}</p>

      <section className="tarjeta" aria-label={t('noticias.dolar')}>
        <h2>{t('noticias.dolar')}</h2>
        {tasas === undefined && <p className="fino">{t('common.cargando')}</p>}
        {tasas === null && (<><p className="error" role="alert"><Icon name="wifioff" size={20} />{t('noticias.sin_tasas')}</p><button type="button" className="boton sec" onClick={cargar}>{t('svc.reintentar')}</button></>)}
        {tasas && (<>
          <div className="tasas">
            <div><small>1 USD</small><strong>R$ {tasas.brl_por_usd.toFixed(2)}</strong></div>
            <div><small>1 EUR</small><strong>R$ {tasas.brl_por_eur.toFixed(2)}</strong></div>
          </div>
          <label htmlFor="monto">{t('noticias.calc')}</label>
          <input id="monto" type="text" inputMode="decimal" value={monto} onChange={(e) => setMonto(e.target.value)} />
          {valido && <p className="calc"><strong>US$ {n.toFixed(2)}</strong> = R$ {aReales(n, tasas.brl_por_usd).toFixed(2)}<br /><strong>R$ {n.toFixed(2)}</strong> = US$ {aDolares(n, tasas.brl_por_usd).toFixed(2)}</p>}
          <small>{t('noticias.fuente_tasas')}</small>
        </>)}
        <small>{t('noticias.nota_cup')}</small>
      </section>

      <h2>{t('noticias.prensa')}</h2>
      <p className="fino">{t('noticias.prensa_ayuda')}</p>
      <ul className="lista-p">
        {FUENTES.map((f) => (
          <li key={f.id} className="fila-persona">
            <span><strong>{f.nombre}</strong><small>{f.url.replace('https://', '')}</small></span>
            <button type="button" className="boton chico sec" onClick={() => setSaliendo(f)}>{t('noticias.abrir')}</button>
          </li>
        ))}
      </ul>

      {saliendo && (
        <div className="hoja-fondo" role="presentation" onClick={() => setSaliendo(null)}>
          <div className="hoja" role="dialog" aria-modal="true" aria-label={t('noticias.saliendo')} onClick={(e) => e.stopPropagation()}>
            <h2>{t('noticias.saliendo')}</h2>
            <p>{t('noticias.saliendo_texto', { sitio: saliendo.nombre })}</p>
            <div className="acciones">
              <button type="button" className="boton sec" onClick={() => setSaliendo(null)}>{t('me.cancelar')}</button>
              <button type="button" className="boton" onClick={() => { window.open(saliendo.url, '_blank', 'noopener,noreferrer'); setSaliendo(null) }}>{t('noticias.continuar')}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
