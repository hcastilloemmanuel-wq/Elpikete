import { useState } from 'react'
import { t } from '../../i18n'
import { backend } from '../../lib/backend'
import { TIPOS_BOLSA, TIPOS_PINCHA, validarAnuncio } from '../../lib/mercado'
import type { BorradorAnuncio, Seccion } from '../../lib/mercado'
import { Icon } from '../../ui/Icon'

export function FormAnuncio({ seccion, onListo, onCancelar }: { seccion: Seccion; onListo: (revision: boolean) => void; onCancelar: () => void }) {
  const tipos = seccion === 'bolsa' ? TIPOS_BOLSA : TIPOS_PINCHA
  const [b, setB] = useState<BorradorAnuncio>({ tipo: tipos[0], titulo: '', descripcion: '', precio: null, barrio: null, jornada: null, idioma: null, mostrar_whatsapp: false })
  const [precio, setPrecio] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [guardando, setGuardando] = useState(false)
  const set = (p: Partial<BorradorAnuncio>) => setB((x) => ({ ...x, ...p }))

  async function guardar() {
    const n = precio.trim() === '' ? null : Number(precio.replace(',', '.'))
    const limpio: BorradorAnuncio = { ...b, titulo: b.titulo.trim(), descripcion: b.descripcion.trim(), precio: n, barrio: b.barrio?.trim() || null, jornada: b.jornada?.trim() || null, idioma: b.idioma?.trim() || null }
    const err = validarAnuncio(limpio)
    if (err) { setError(err); return }
    setGuardando(true); setError(null)
    try { const a = await backend.createAnuncio(limpio); onListo(a.estado === 'revision') } catch { setError('no_se_guardo'); setGuardando(false) }
  }

  return (
    <div className="stack">
      <button type="button" className="atras" onClick={onCancelar}><Icon name="atras" size={20} />{t('onb.atras')}</button>
      <h1>{t(seccion === 'bolsa' ? 'mercado.publicar_bolsa' : 'mercado.publicar_pincha')}</h1>
      {seccion === 'pincha' && <p className="banner-aviso" role="note"><Icon name="alerta" size={18} />{t('mercado.aviso_pincha')}</p>}
      <div className="chips" role="group" aria-label={t('mercado.tipo')}>
        {tipos.map((x) => <button key={x} type="button" className={'chip' + (b.tipo === x ? ' on' : '')} aria-pressed={b.tipo === x} onClick={() => set({ tipo: x })}>{t('mercado.tipo_' + x)}</button>)}
      </div>
      <label htmlFor="a-titulo">{t('mercado.f_titulo')}</label>
      <input id="a-titulo" type="text" maxLength={80} value={b.titulo} onChange={(e) => set({ titulo: e.target.value })} />
      <label htmlFor="a-desc">{t('mercado.f_descripcion')}</label>
      <textarea id="a-desc" rows={4} maxLength={600} value={b.descripcion} onChange={(e) => set({ descripcion: e.target.value })} />
      <label htmlFor="a-precio">{t(seccion === 'bolsa' ? 'mercado.f_precio' : 'mercado.f_pago')}</label>
      <input id="a-precio" type="text" inputMode="decimal" value={precio} onChange={(e) => setPrecio(e.target.value)} placeholder="R$" />
      <label htmlFor="a-barrio">{t('mercado.f_barrio')}</label>
      <input id="a-barrio" type="text" maxLength={60} value={b.barrio ?? ''} onChange={(e) => set({ barrio: e.target.value })} />
      {seccion === 'pincha' && (<>
        <label htmlFor="a-jornada">{t('mercado.f_jornada')}</label>
        <input id="a-jornada" type="text" maxLength={40} value={b.jornada ?? ''} onChange={(e) => set({ jornada: e.target.value })} placeholder={t('mercado.f_jornada_ej')} />
        <label htmlFor="a-idioma">{t('mercado.f_idioma')}</label>
        <input id="a-idioma" type="text" maxLength={40} value={b.idioma ?? ''} onChange={(e) => set({ idioma: e.target.value })} placeholder={t('mercado.f_idioma_ej')} />
      </>)}
      <label className="casilla"><input type="checkbox" checked={b.mostrar_whatsapp} onChange={(e) => set({ mostrar_whatsapp: e.target.checked })} /> {t('svc.mostrar_wa')}</label>
      <small>{t('mercado.revision_ayuda')}</small>
      {error && <p className="error" role="alert"><Icon name="alerta" size={20} />{t('err.' + error)}</p>}
      <button type="button" className="boton" disabled={guardando} onClick={() => void guardar()}>{t('mercado.guardar')}</button>
    </div>
  )
}
