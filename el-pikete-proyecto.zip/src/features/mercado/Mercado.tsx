import { useCallback, useEffect, useMemo, useState } from 'react'
import { t, useLang } from '../../i18n'
import { backend } from '../../lib/backend'
import { TIPOS_BOLSA, TIPOS_PINCHA, diasRestantes, filtrarAnuncios, seccionDe, vencido } from '../../lib/mercado'
import type { Anuncio, Seccion, TipoAnuncio } from '../../lib/mercado'
import { useAuth } from '../auth/AuthProvider'
import { Avatar } from '../../ui/Baldosa'
import { Icon } from '../../ui/Icon'
import { FormAnuncio } from './FormAnuncio'

export default function Mercado() {
  useLang()
  const { perfil } = useAuth()
  const [lista, setLista] = useState<Anuncio[] | null>(null)
  const [seccion, setSeccion] = useState<Seccion>('bolsa')
  const [tipo, setTipo] = useState<TipoAnuncio | null>(null)
  const [texto, setTexto] = useState('')
  const [miCiudad, setMiCiudad] = useState(true)
  const [creando, setCreando] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [aviso, setAviso] = useState<string | null>(null)

  const cargar = useCallback(() => { backend.listAnuncios().then((l) => { setLista(l); setError(null) }).catch(() => setError('no_disponible')) }, [])
  useEffect(() => { cargar() }, [cargar])

  const visibles = useMemo(() => filtrarAnuncios(lista ?? [], { texto, seccion, tipo, solo_mi_ciudad: miCiudad, ciudad: perfil?.ciudad_ibge ?? null }), [lista, texto, seccion, tipo, miCiudad, perfil])
  const mios = (lista ?? []).filter((a) => a.user_id === perfil?.id && seccionDe(a.tipo) === seccion)
  const accion = (f: () => Promise<void>, ok?: string) => f().then(() => { if (ok) setAviso(ok); cargar() }).catch(() => setError('no_se_guardo'))

  if (creando) return <FormAnuncio seccion={seccion} onListo={(revision) => { setCreando(false); setAviso(revision ? 'mercado.en_revision' : 'mercado.publicado'); cargar() }} onCancelar={() => setCreando(false)} />

  const tipos = seccion === 'bolsa' ? TIPOS_BOLSA : TIPOS_PINCHA
  return (
    <div className="stack">
      <h1>{t('nav.mercado')}</h1>
      <div className="via" role="tablist">
        {(['bolsa', 'pincha'] as const).map((s) => (
          <button key={s} type="button" role="tab" aria-selected={seccion === s} className={'via-op' + (seccion === s ? ' on' : '')} onClick={() => { setSeccion(s); setTipo(null) }}>{t('mercado.' + s)}</button>
        ))}
      </div>
      <p className="sub">{t('mercado.sub_' + seccion)}</p>
      {seccion === 'pincha' && <p className="banner-aviso" role="note"><Icon name="alerta" size={18} />{t('mercado.aviso_pincha')}</p>}

      <div className="buscador"><Icon name="buscar" size={20} /><input type="search" value={texto} onChange={(e) => setTexto(e.target.value)} placeholder={t('mercado.buscar')} aria-label={t('mercado.buscar')} /></div>
      <div className="chips" role="group" aria-label={t('svc.filtros')}>
        <button type="button" className={'chip' + (miCiudad ? ' on' : '')} aria-pressed={miCiudad} onClick={() => setMiCiudad(!miCiudad)}><Icon name="pin" size={16} /> {miCiudad ? perfil?.ciudad_nombre : t('svc.todas_ciudades')}</button>
        {tipos.map((x) => <button key={x} type="button" className={'chip' + (tipo === x ? ' on' : '')} aria-pressed={tipo === x} onClick={() => setTipo(tipo === x ? null : x)}>{t('mercado.tipo_' + x)}</button>)}
      </div>
      <button type="button" className="boton" onClick={() => setCreando(true)}>{t(seccion === 'bolsa' ? 'mercado.publicar_bolsa' : 'mercado.publicar_pincha')}</button>
      {aviso && <p className="fino" role="status">{t(aviso)}</p>}
      {error && <p className="error" role="alert">{t('err.' + error)}</p>}

      {mios.length > 0 && (<>
        <h2>{t('mercado.mios')}</h2>
        <ul className="lista-svc">{mios.map((a) => (
          <li key={a.id}><article className="tarjeta svc">
            <strong>{a.titulo}</strong>
            <p className="fino">{a.estado === 'revision' ? t('mercado.estado_revision') : a.estado === 'cerrado' || vencido(a) ? t('mercado.estado_cerrado') : t('mercado.vence_en', { n: diasRestantes(a) })}</p>
            <div className="acciones-post">
              {a.estado === 'activo' && !vencido(a) && <button type="button" className="chip chico" onClick={() => void accion(() => backend.cerrarAnuncio(a.id))}>{t('mercado.cerrar')}</button>}
              {a.estado !== 'revision' && <button type="button" className="chip chico" onClick={() => void accion(() => backend.renovarAnuncio(a.id), 'mercado.renovado')}>{t('mercado.renovar')}</button>}
            </div>
          </article></li>
        ))}</ul>
      </>)}

      {lista != null && visibles.length === 0 && <div className="tarjeta vacia"><strong>{t('mercado.vacio_titulo')}</strong><p className="sub">{t('mercado.vacio_texto')}</p></div>}
      <ul className="lista-svc" aria-live="polite">{visibles.map((a) => <li key={a.id}><Tarjeta a={a} yo={perfil?.id ?? ''} onReportar={() => void accion(() => backend.reportarAnuncio(a.id), 'mercado.reportado')} /></li>)}</ul>
    </div>
  )
}

function Tarjeta({ a, yo, onReportar }: { a: Anuncio; yo: string; onReportar: () => void }) {
  const [msg, setMsg] = useState<string | null>(null)
  async function contactar() {
    if (a.ejemplo || !a.mostrar_whatsapp) { setMsg(a.ejemplo ? 'svc.contacto_ejemplo' : 'svc.contacto_chat'); return }
    try {
      const n = await backend.verWhatsapp(a.user_id)
      if (!n) { setMsg('svc.contacto_chat'); return }
      window.open(`https://wa.me/${n.replace(/\D/g, '')}?text=${encodeURIComponent(t('mercado.wa_texto', { titulo: a.titulo }))}`, '_blank', 'noopener,noreferrer')
    } catch { setMsg('err.no_disponible') }
  }
  return (
    <article className="tarjeta svc">
      <header className="svc-cab">
        <Avatar apodo={a.apodo} color={a.avatar_color} size={42} />
        <div className="svc-quien"><h2>{a.titulo}</h2><span className="fino">{a.apodo} · {a.ciudad_nombre}{a.barrio ? `, ${a.barrio}` : ''}</span></div>
        {a.ejemplo && <span className="sello-ej">{t('svc.ejemplo')}</span>}
      </header>
      <p className="svc-desc">{a.descripcion}</p>
      <ul className="etiquetas">
        <li className="et">{t('mercado.tipo_' + a.tipo)}</li>
        {a.precio != null && <li className="et hoy">R$ {a.precio.toLocaleString('pt-BR')}</li>}
        {a.jornada && <li className="et">{a.jornada}</li>}
        {a.idioma && <li className="et">{a.idioma}</li>}
      </ul>
      <div className="acciones-post">
        {a.user_id !== yo && <button type="button" className="boton chico" onClick={() => void contactar()}><Icon name="chat" size={18} />{t('svc.contactar')}</button>}
        {a.user_id !== yo && !a.ejemplo && <button type="button" className="chip chico" onClick={onReportar}><Icon name="alerta" size={16} />{t('mercado.reportar')}</button>}
      </div>
      {msg && <p className="fino" role="status">{t(msg)}</p>}
    </article>
  )
}
