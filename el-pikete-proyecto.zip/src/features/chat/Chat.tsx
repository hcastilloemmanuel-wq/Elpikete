import { useCallback, useEffect, useState } from 'react'
import { t, useLang } from '../../i18n'
import { backend } from '../../lib/backend'
import { MAX_MENSAJE, validarTexto } from '../../lib/social'
import type { Amistad, Mensaje, Persona } from '../../lib/social'
import { useAuth } from '../auth/AuthProvider'
import { Avatar } from '../../ui/Baldosa'
import { Icon } from '../../ui/Icon'

export default function Chat() {
  useLang()
  const [ami, setAmi] = useState<Amistad[] | null>(null)
  const [cerca, setCerca] = useState<Persona[]>([])
  const [con, setCon] = useState<Persona | null>(null)
  const [error, setError] = useState<string | null>(null)

  const cargar = useCallback(() => {
    Promise.all([backend.listAmistades(), backend.listPaisanos()]).then(([a, p]) => { setAmi(a); setCerca(p); setError(null) }).catch(() => setError('no_disponible'))
  }, [])
  useEffect(() => { cargar() }, [cargar])

  if (con) return <Conversacion con={con} atras={() => setCon(null)} />

  const accion = (f: () => Promise<void>) => f().then(cargar).catch(() => setError('no_se_guardo'))
  const amigos = (ami ?? []).filter((a) => a.estado === 'amigo')
  const recibidas = (ami ?? []).filter((a) => a.estado === 'recibida')
  const enviadas = (ami ?? []).filter((a) => a.estado === 'enviada')

  const fila = (p: Persona, extra: React.ReactNode, onClick?: () => void) => (
    <li className="fila-persona" key={p.id}>
      <button type="button" className="persona" onClick={onClick} disabled={!onClick}>
        <Avatar apodo={p.apodo} provincia={p.provincia_cuba} color={p.avatar_color} size={44} />
        <span><strong>{p.apodo}</strong><small>{p.provincia_cuba ?? ''}{p.ejemplo ? ` · ${t('svc.ejemplo')}` : ''}</small></span>
      </button>
      {extra}
    </li>
  )

  return (
    <div className="stack">
      <h1>{t('nav.chat')}</h1>
      <p className="sub">{t('chat.sub')}</p>
      {error && <p className="error" role="alert">{t('err.' + error)}</p>}

      {recibidas.length > 0 && (<>
        <h2>{t('chat.solicitudes')}</h2>
        <ul className="lista-p">{recibidas.map((a) => fila(a.persona, (
          <span className="duo">
            <button type="button" className="boton chico" onClick={() => void accion(() => backend.responderAmistad(a.persona.id, true))}>{t('chat.aceptar')}</button>
            <button type="button" className="boton chico sec" onClick={() => void accion(() => backend.responderAmistad(a.persona.id, false))}>{t('chat.rechazar')}</button>
          </span>))
        )}</ul>
      </>)}

      <h2>{t('chat.amigos')}</h2>
      {ami != null && amigos.length === 0 && <div className="tarjeta vacia"><p className="sub">{t('chat.sin_amigos')}</p></div>}
      <ul className="lista-p">{amigos.map((a) => fila(a.persona, <Icon name="chat" size={20} />, () => setCon(a.persona)))}</ul>

      {enviadas.length > 0 && (<>
        <h2>{t('chat.enviadas')}</h2>
        <ul className="lista-p">{enviadas.map((a) => fila(a.persona, <small>{t('chat.pendiente')}</small>))}</ul>
      </>)}

      <h2>{t('chat.cerca')}</h2>
      <p className="fino">{t('chat.cerca_ayuda')}</p>
      {ami != null && cerca.length === 0 && <div className="tarjeta vacia"><p className="sub">{t('chat.nadie_cerca')}</p></div>}
      <ul className="lista-p">{cerca.map((p) => fila(p, <button type="button" className="boton chico sec" onClick={() => void accion(() => backend.pedirAmistad(p.id))}>{t('chat.agregar')}</button>))}</ul>
    </div>
  )
}

function Conversacion({ con, atras }: { con: Persona; atras: () => void }) {
  const { perfil } = useAuth()
  const [msgs, setMsgs] = useState<Mensaje[]>([])
  const [texto, setTexto] = useState('')
  const [error, setError] = useState<string | null>(null)

  const cargar = useCallback(() => { backend.listMensajes(con.id).then(setMsgs).catch(() => setError('no_disponible')) }, [con.id])
  useEffect(() => { cargar(); const i = setInterval(cargar, 4000); return () => clearInterval(i) }, [cargar])
  useEffect(() => { document.querySelector('.hilo')?.scrollTo?.({ top: 1e6 }) }, [msgs.length])

  async function enviar() {
    const e = validarTexto(texto, MAX_MENSAJE)
    if (e) { setError(e); return }
    try { await backend.enviarMensaje(con.id, texto); setTexto(''); setError(null); cargar(); setTimeout(cargar, 1800) } catch { setError('no_se_guardo') }
  }

  return (
    <div className="stack conv">
      <button type="button" className="atras" onClick={atras}><Icon name="atras" size={20} />{t('onb.atras')}</button>
      <div className="mi-fila"><Avatar apodo={con.apodo} provincia={con.provincia_cuba} color={con.avatar_color} size={44} /><div><strong>{con.apodo}</strong>{con.ejemplo && <small>{t('chat.ejemplo_aviso')}</small>}</div></div>
      <div className="hilo" aria-live="polite">
        {msgs.length === 0 && <p className="fino">{t('chat.escribe_primero')}</p>}
        {msgs.map((m) => <p key={m.id} className={'burbuja' + (m.de === perfil?.id ? ' mia' : '')}>{m.texto}</p>)}
      </div>
      {error && <p className="error" role="alert">{t('err.' + error)}</p>}
      <div className="fila-com">
        <input type="text" value={texto} maxLength={MAX_MENSAJE} onChange={(e) => setTexto(e.target.value)} placeholder={t('chat.ph')} aria-label={t('chat.ph')} onKeyDown={(e) => { if (e.key === 'Enter') void enviar() }} />
        <button type="button" className="boton chico" onClick={() => void enviar()}><Icon name="enviar" size={18} /><span className="sr">{t('cuadra.enviar')}</span></button>
      </div>
    </div>
  )
}
