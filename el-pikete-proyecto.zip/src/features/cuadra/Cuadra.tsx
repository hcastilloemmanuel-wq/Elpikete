import { Link } from 'react-router-dom'
import { useCallback, useEffect, useState } from 'react'
import { t, useLang } from '../../i18n'
import { backend } from '../../lib/backend'
import { MAX_POST, TIPOS_POST, validarTexto } from '../../lib/social'
import type { Publicacion, TipoPost } from '../../lib/social'
import { useAuth } from '../auth/AuthProvider'
import { Publicacion as Post } from './Publicacion'
import { Reglas } from './Reglas'

export default function Cuadra() {
  useLang()
  const { perfil } = useAuth()
  const [posts, setPosts] = useState<Publicacion[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [tipo, setTipo] = useState<TipoPost>('pregunta')
  const [texto, setTexto] = useState('')
  const [enviando, setEnviando] = useState(false)

  const cargar = useCallback(() => {
    backend.listPosts().then((p) => { setPosts(p); setError(null) }).catch(() => setError('no_disponible'))
  }, [])
  useEffect(() => { cargar(); const i = setInterval(cargar, 15000); return () => clearInterval(i) }, [cargar])

  async function publicar() {
    const e = validarTexto(texto, MAX_POST)
    if (e) { setError(e); return }
    setEnviando(true); setError(null)
    try { await backend.createPost(tipo, texto); setTexto(''); cargar() } catch { setError('no_se_guardo') }
    setEnviando(false)
  }

  return (
    <div className="stack cuadra">
      <Reglas />
      <h1>{t('cuadra.titulo', { ciudad: perfil?.ciudad_nombre ?? '' })}</h1>
      <p className="sub">{t('cuadra.sub')} <Link to="/inicio">{t('home.atajos_titulo')}</Link></p>

      <section className="tarjeta redactar">
        <div className="chips" role="group" aria-label={t('cuadra.tipo')}>
          {TIPOS_POST.map((x) => <button key={x} type="button" className={'chip' + (tipo === x ? ' on' : '')} aria-pressed={tipo === x} onClick={() => setTipo(x)}>{t('cuadra.tipo_' + x)}</button>)}
        </div>
        <label htmlFor="nuevo-post" className="sr">{t('cuadra.nueva')}</label>
        <textarea id="nuevo-post" rows={3} maxLength={MAX_POST} value={texto} onChange={(e) => setTexto(e.target.value)} placeholder={t('cuadra.ph_' + tipo)} />
        <div className="fila-pie"><small>{texto.length}/{MAX_POST}</small></div>
        {error && <p className="error" role="alert">{t('err.' + error)}</p>}
        <button type="button" className="boton" disabled={enviando} onClick={() => void publicar()}>{t('cuadra.publicar')}</button>
      </section>

      {posts == null && !error && <p className="fino">{t('common.cargando')}</p>}
      {posts != null && posts.length === 0 && (
        <div className="tarjeta vacia"><strong>{t('cuadra.vacio_titulo')}</strong><p className="sub">{t('cuadra.vacio_texto')}</p></div>
      )}
      <ul className="lista-svc">
        {(posts ?? []).map((p) => <li key={p.id}><Post p={p} miId={perfil?.id ?? ''} alCambiar={cargar} /></li>)}
      </ul>
      <p className="fino">{t('cuadra.reglas')}</p>
    </div>
  )
}
