import { useState } from 'react'
import { t } from '../../i18n'
import { backend } from '../../lib/backend'
import { MAX_POST, tiempoRelativo, validarTexto } from '../../lib/social'
import type { Comentario, Publicacion as P } from '../../lib/social'
import { Avatar } from '../../ui/Baldosa'
import { Icon } from '../../ui/Icon'

const cuando = (iso: string) => { const r = tiempoRelativo(iso); return t(r.k, { n: r.n ?? 0 }) }

/** Todo el texto de otras personas se pinta como texto (React lo escapa): nunca se ejecuta como HTML. */
export function Publicacion({ p, miId, alCambiar }: { p: P; miId: string; alCambiar: () => void }) {
  const [abierto, setAbierto] = useState(false)
  const [coms, setComs] = useState<Comentario[] | null>(null)
  const [nuevo, setNuevo] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [hecho, setHecho] = useState<string | null>(null)

  const cargarComs = () => backend.listComments(p.id).then(setComs).catch(() => setError('no_disponible'))
  async function abrir() {
    const a = !abierto; setAbierto(a)
    if (a) void cargarComs()
  }
  async function like() { try { await backend.toggleLike(p.id); alCambiar() } catch { setError('no_se_guardo') } }
  async function comentar() {
    const e = validarTexto(nuevo, MAX_POST)
    if (e) { setError(e); return }
    try { await backend.addComment(p.id, nuevo); setNuevo(''); setError(null); await cargarComs(); alCambiar() } catch { setError('no_se_guardo') }
  }
  async function reportar() { try { await backend.reportarPost(p.id); setError(null); setHecho('cuadra.reportado'); alCambiar() } catch { setError('no_se_guardo') } }
  async function bloquear() { try { await backend.bloquear(p.autor.id); alCambiar() } catch { setError('no_se_guardo') } }
  async function borrar() { try { await backend.deletePost(p.id); alCambiar() } catch { setError('no_se_guardo') } }

  return (
    <article className="tarjeta svc post">
      <header className="svc-cab">
        <Avatar apodo={p.autor.apodo} provincia={p.autor.provincia_cuba} color={p.autor.avatar_color} size={42} />
        <div className="svc-quien">
          <strong>{p.autor.apodo}</strong>
          <span className="fino">{p.autor.provincia_cuba ? `${p.autor.provincia_cuba} · ` : ''}{cuando(p.creado_en)}</span>
        </div>
        {p.autor.ejemplo && <span className="sello-ej">{t('svc.ejemplo')}</span>}
        <span className="et">{t('cuadra.tipo_' + p.tipo)}</span>
      </header>
      <p className="svc-desc">{p.texto}</p>
      <div className="acciones-post">
        <button type="button" className={'chip chico' + (p.yo_like ? ' on' : '')} aria-pressed={p.yo_like} onClick={() => void like()}>
          <Icon name="corazon" size={16} relleno={p.yo_like} />{p.likes}<span className="sr"> {t('cuadra.megusta')}</span>
        </button>
        <button type="button" className="chip chico" aria-expanded={abierto} onClick={() => void abrir()}>
          <Icon name="chat" size={16} />{p.comentarios}<span className="sr"> {t('cuadra.comentarios')}</span>
        </button>
        {p.autor.id !== miId && !p.autor.ejemplo && <button type="button" className="chip chico" onClick={() => void reportar()}><Icon name="alerta" size={16} />{t('cuadra.reportar')}</button>}
        {p.autor.id !== miId && !p.autor.ejemplo && <button type="button" className="chip chico" onClick={() => void bloquear()}><Icon name="candado" size={16} />{t('cuadra.bloquear')}</button>}
        {p.autor.id === miId && <button type="button" className="chip chico" onClick={() => void borrar()}><Icon name="basura" size={16} />{t('cuadra.borrar')}</button>}
      </div>
      {hecho && <p className="fino" role="status">{t(hecho)}</p>}
      {abierto && (
        <div className="comentarios">
          {coms == null && <p className="fino">{t('common.cargando')}</p>}
          {(coms ?? []).map((c) => (
            <p key={c.id} className="comentario"><strong>{c.autor.apodo}</strong> {c.texto} <span className="fino">{cuando(c.creado_en)}</span></p>
          ))}
          <div className="fila-com">
            <input type="text" value={nuevo} maxLength={MAX_POST} onChange={(e) => setNuevo(e.target.value)} placeholder={t('cuadra.comentar_ph')} aria-label={t('cuadra.comentar_ph')} onKeyDown={(e) => { if (e.key === 'Enter') void comentar() }} />
            <button type="button" className="boton chico" onClick={() => void comentar()}><Icon name="enviar" size={18} /><span className="sr">{t('cuadra.enviar')}</span></button>
          </div>
          {error && <p className="error" role="alert">{t('err.' + error)}</p>}
        </div>
      )}
    </article>
  )
}
