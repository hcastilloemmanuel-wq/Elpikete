import { useState } from 'react'
import { t } from '../../i18n'

const KEY = 'pk_reglas_ok'
const leido = () => { try { return localStorage.getItem(KEY) === '1' } catch { return false } }

/** Las 10 reglas de la comunidad, visibles la primera vez. */
export function Reglas() {
  const [ok, setOk] = useState(leido)
  if (ok) return null
  const aceptar = () => { try { localStorage.setItem(KEY, '1') } catch { /* sin almacenamiento */ } setOk(true) }
  return (
    <div className="hoja-fondo" role="presentation">
      <div className="hoja" role="dialog" aria-modal="true" aria-label={t('reglas.titulo')}>
        <h2>{t('reglas.titulo')}</h2>
        <ol className="reglas">{Array.from({ length: 10 }, (_, i) => <li key={i}>{t('reglas.r' + (i + 1))}</li>)}</ol>
        <button type="button" className="boton" onClick={aceptar}>{t('reglas.acepto')}</button>
      </div>
    </div>
  )
}
