import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { backend, BackendError } from '../../lib/backend'
import { nombreEstado } from '../../lib/data'
import { getRemember } from '../../lib/storage'
import { getLang, setLang, t, useLang } from '../../i18n'
import { useAuth } from '../auth/AuthProvider'
import { Icon } from '../../ui/Icon'
import { Avatar } from '../../ui/Baldosa'

export type Tema = 'claro' | 'oscuro' | 'auto'
export function temaGuardado(): Tema {
  try { const v = localStorage.getItem('pk_tema'); if (v === 'claro' || v === 'oscuro') return v } catch { /* sin almacenamiento */ }
  return 'auto'
}
export function aplicarTema(tema: Tema) {
  if (tema === 'auto') delete document.documentElement.dataset.tema
  else document.documentElement.dataset.tema = tema
  try { if (tema === 'auto') localStorage.removeItem('pk_tema'); else localStorage.setItem('pk_tema', tema) } catch { /* sin almacenamiento */ }
}

export default function Me() {
  useLang()
  const { perfil, setPerfil, salir } = useAuth()
  const nav = useNavigate()
  const [confirmar, setConfirmar] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [trabajando, setTrabajando] = useState(false)
  const [tema, setTema] = useState<Tema>(temaGuardado())
  if (!perfil) return null

  async function conmutarDiscreto(v: boolean) {
    try { setPerfil(await backend.savePerfil({ modo_discreto: v })) } catch (e) { setError(e instanceof BackendError ? e.code : 'no_se_guardo') }
  }
  async function descargar() {
    try {
      const datos = await backend.exportData()
      const url = URL.createObjectURL(new Blob([JSON.stringify(datos, null, 2)], { type: 'application/json' }))
      const a = document.createElement('a'); a.href = url; a.download = 'mis-datos-el-pikete.json'; a.click()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
    } catch (e) { setError(e instanceof BackendError ? e.code : 'no_disponible') }
  }
  async function borrar() {
    setTrabajando(true)
    try { await backend.deleteAccount(); await salir('local'); nav('/entrar', { replace: true }) }
    catch (e) { setError(e instanceof BackendError ? e.code : 'no_se_borro'); setTrabajando(false) }
  }
  const salirLocal = () => void salir('local').then(() => nav('/entrar', { replace: true }))
  const salirTodas = () => void salir('global').then(() => nav('/entrar', { replace: true }))

  return (
    <div className="stack">
      <section className="perfil bloque">
        <Avatar apodo={perfil.apodo} provincia={perfil.provincia_cuba} discreto={perfil.modo_discreto} color={perfil.avatar_color} size={84} />
        <h1>{perfil.apodo}</h1>
        {perfil.frase && <p className="sub">{perfil.frase}</p>}
        <dl>
          <dt>{t('me.origen')}</dt><dd>{perfil.provincia_cuba}</dd>
          <dt>{t('me.vives')}</dt><dd>{perfil.ciudad_nombre}, {nombreEstado(perfil.estado_br)}</dd>
        </dl>
      </section>

      <section className="bloque">
        <h2>{t('me.privacidad')}</h2>
        <label className="casilla"><input type="checkbox" checked={perfil.modo_discreto} onChange={(e) => void conmutarDiscreto(e.target.checked)} /> <span><strong>{t('me.discreto')}</strong><br /><small>{t('onb.cierre.discreto_ayuda')}</small></span></label>
        <p className="fino" style={{ marginTop: 'var(--s4)' }}>{getRemember() ? t('me.sesion_info') : t('me.compartido')}</p>
        <button className="boton sec" onClick={salirLocal}><Icon name="salir" size={20} />{t('me.cerrar')}</button>
        <button className="boton sec" onClick={salirTodas}><Icon name="candado" size={20} />{t('me.cerrar_todas')}</button>
        <small>{t('me.cerrar_todas_ayuda')}</small>
      </section>

      <section className="bloque">
        <h2>{t('me.idioma')}</h2>
        <div className="radios">
          {(['es', 'pt'] as const).map((l) => <label key={l} className={'radio' + (getLang() === l ? ' on' : '')}><input type="radio" name="lang" checked={getLang() === l} onChange={() => setLang(l)} /> {l === 'es' ? 'Español' : 'Português'}</label>)}
        </div>
        <h2 style={{ marginTop: 'var(--s5)' }}>{t('me.tema')}</h2>
        <div className="radios">
          {(['auto', 'claro', 'oscuro'] as const).map((x) => <label key={x} className={'radio' + (tema === x ? ' on' : '')}><input type="radio" name="tema" checked={tema === x} onChange={() => { aplicarTema(x); setTema(x); setError(null) }} /> {t('me.' + x)}</label>)}
        </div>
      </section>

      <section className="bloque">
        <h2>{t('me.tus_datos')}</h2>
        <button className="boton sec" onClick={() => void descargar()}><Icon name="descargar" size={20} />{t('me.descargar')}</button>
        {!confirmar ? <button className="boton peligro" onClick={() => setConfirmar(true)}><Icon name="basura" size={20} />{t('me.borrar')}</button> : (
          <div role="alertdialog" aria-label={t('me.borrar')} style={{ marginTop: 'var(--s4)' }}>
            <p>{t('me.borrar_confirma')}</p>
            <div className="acciones">
              <button className="boton sec" onClick={() => setConfirmar(false)}>{t('me.cancelar')}</button>
              <button className="boton peligro" disabled={trabajando} onClick={() => void borrar()}>{t('me.borrar_si')}</button>
            </div>
          </div>
        )}
        {error && <p className="error" role="alert"><Icon name="alerta" size={20} />{t('err.' + error)}</p>}
      </section>
      <p className="fino centro">{t('me.version')} · El Pikete</p>
    </div>
  )
}
