import { Baldosa, PALETAS } from '../../ui/Baldosa'

export function Logo({ grande = false, claro = false }: { grande?: boolean; claro?: boolean }) {
  return (
    <div className={'logo' + (grande ? ' grande' : '') + (claro ? ' claro' : '')} aria-label="El Pikete">
      <Baldosa diseno={0} paleta={claro ? { ...PALETAS[1], bg: '#F6F5F0' } : PALETAS[0]} size={grande ? 44 : 30} radio={0.28} />
      <span className="logo-texto">El Pikete</span>
    </div>
  )
}
