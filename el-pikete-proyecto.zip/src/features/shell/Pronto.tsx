import { t, useLang } from '../../i18n'
import { BaldosaCampo } from '../../ui/Baldosa'

export default function Pronto({ titulo, texto }: { titulo: string; texto: string }) {
  useLang()
  return (
    <div className="stack vacio">
      <div className="campo-v"><BaldosaCampo columnas={3} filas={1} celdas={[{ d: 4, p: 1 }, { d: 0, p: 2 }, { d: 5, p: 6 }]} /></div>
      <h1>{t(titulo)}</h1>
      <p className="sub">{t(texto)}</p>
      <p className="fino">{t('pronto.cuando')}</p>
    </div>
  )
}
