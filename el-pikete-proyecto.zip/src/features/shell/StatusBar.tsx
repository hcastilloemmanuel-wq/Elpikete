import { useEffect, useState } from 'react'
import { useRegisterSW } from 'virtual:pwa-register/react'
import { t, useLang } from '../../i18n'
import { Icon } from '../../ui/Icon'

/** Avisos globales: sin internet y versión nueva disponible. */
export function StatusBar() {
  useLang()
  const [online, setOnline] = useState(navigator.onLine)
  const { needRefresh: [hayNueva], updateServiceWorker } = useRegisterSW()
  useEffect(() => {
    const on = () => setOnline(true), off = () => setOnline(false)
    window.addEventListener('online', on); window.addEventListener('offline', off)
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off) }
  }, [])
  return (
    <>
      {!online && <div className="barra aviso" role="status"><Icon name="wifioff" size={18} />{t('offline.aviso')}</div>}
      {hayNueva && <div className="barra nueva" role="status">{t('update.nueva')} <button className="enlace" onClick={() => void updateServiceWorker(true)}>{t('update.actualizar')}</button></div>}
    </>
  )
}
