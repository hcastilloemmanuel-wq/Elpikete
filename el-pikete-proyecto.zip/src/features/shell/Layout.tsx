import { useState } from 'react'
import { NavLink, Navigate, Outlet, Link } from 'react-router-dom'
import { t, useLang } from '../../i18n'
import { useAuth } from '../auth/AuthProvider'
import { Logo } from './Logo'
import { StatusBar } from './StatusBar'
import { Icon } from '../../ui/Icon'
import type { IconName } from '../../ui/Icon'
import { Avatar } from '../../ui/Baldosa'
import { SocioHoja } from '../socio/SocioHoja'

const TABS: { to: string; k: string; i: IconName }[] = [
  { to: '/', k: 'nav.cuadra', i: 'cuadra' },
  { to: '/servicios', k: 'nav.servicios', i: 'servicios' },
  { to: '/mercado', k: 'nav.mercado', i: 'bolsa' },
  { to: '/noticias', k: 'nav.noticias', i: 'noticias' },
  { to: '/chat', k: 'nav.chat', i: 'chat' },
]

export default function Layout() {
  useLang()
  const { sesion, perfil, cargando } = useAuth()
  const [socio, setSocio] = useState(false)
  if (cargando) return <main className="pantalla centrada"><p>{t('common.cargando')}</p></main>
  if (!sesion) return <Navigate to="/entrar" replace />
  if (!perfil?.completado) return <Navigate to="/registro" replace />

  return (
    <div className="app">
      <StatusBar />
      <header className="cabecera">
        <Logo />
        <Link to="/yo" className="avatar-b" aria-label={t('me.titulo')}><Avatar apodo={perfil.apodo} provincia={perfil.provincia_cuba} discreto={perfil.modo_discreto} color={perfil.avatar_color} size={42} /></Link>
      </header>
      <main className="contenido"><Outlet /></main>
      <button className="fab" onClick={() => setSocio(true)} aria-label={t('socio.nombre')}><Icon name="socio" size={22} />{t('socio.nombre')}</button>
      {socio && <SocioHoja cerrar={() => setSocio(false)} />}
      <nav className="tabs" aria-label="principal">
        {TABS.map((x) => (
          <NavLink key={x.to} to={x.to} end={x.to === '/'} className={({ isActive }) => (isActive ? 'tab on' : 'tab')}>
            {({ isActive }) => (<>
              <span className="ico"><Icon name={x.i} size={24} relleno={isActive} /></span>
              <span>{t(x.k)}</span>
            </>)}
          </NavLink>
        ))}
      </nav>
    </div>
  )
}
