import { Link } from 'react-router-dom'
import { DEMO_MODE } from '../../lib/config'
import { nombreEstado } from '../../lib/data'
import { t, useLang } from '../../i18n'
import { useAuth } from '../auth/AuthProvider'
import { Icon } from '../../ui/Icon'
import type { IconName } from '../../ui/Icon'
import { BaldosaCampo, PALETAS } from '../../ui/Baldosa'

const ATAJOS: { to: string; k: string; i: IconName; c: string }[] = [
  { to: '/servicios', k: 'home.atajos_servicios', i: 'servicios', c: 'c-sol' },
  { to: '/mercado', k: 'home.atajos_mercado', i: 'bolsa', c: 'c-mar' },
  { to: '/noticias', k: 'home.atajos_noticias', i: 'noticias', c: 'c-rosa' },
  { to: '/chat', k: 'home.atajos_chat', i: 'chat', c: 'c-anil' },
]

export default function Home() {
  useLang()
  const { perfil } = useAuth()
  if (!perfil) return null
  const celdas = [{ d: 1, p: 0 }, { d: 0, p: 4 }, { d: 5, p: 3 }, { d: 2, p: 0 }]
  return (
    <div className="stack">
      <h1>{t('home.hola', { apodo: perfil.apodo })}</h1>
      <section className="banner" aria-label={t('home.tu_cuadra')}>
        <BaldosaCampo className="campo" columnas={2} filas={2} celdas={celdas.map((c) => ({ ...c, p: c.p % PALETAS.length }))} />
        <small>{t('home.tu_cuadra')}</small>
        <p className="grande-txt">{perfil.ciudad_nombre}</p>
        <p className="cap"><Icon name="pin" size={18} /><span>{nombreEstado(perfil.estado_br)}
          {perfil.provincia_cuba && !perfil.modo_discreto && <> · {t('home.eres_de', { provincia: perfil.provincia_cuba })}</>}</span></p>
      </section>

      {perfil.recien_llegado && (
        <div className="lista-ruta">
          <div className="ruta">
            <span className="chapa"><Icon name="ruta" size={24} /></span>
            <div><h2>{t('home.recien_titulo')}</h2><p>{t('home.recien_texto')}</p></div>
          </div>
        </div>
      )}

      <h2 style={{ marginTop: 'var(--s5)' }}>{t('home.atajos_titulo')}</h2>
      <nav className="atajos" aria-label={t('home.atajos_titulo')}>
        {ATAJOS.map((a) => (
          <Link key={a.to} to={a.to} className="atajo">
            <span className={'chapa ' + a.c}><Icon name={a.i} size={24} /></span>
            <Icon name="der" size={18} className="ir" />
            <b>{t(a.k)}</b>
          </Link>
        ))}
      </nav>
      {DEMO_MODE && <p className="aviso-demo"><Icon name="info" size={20} />{t('demo.aviso')}</p>}
      <p className="fino">{t('home.demo_nota')}</p>
    </div>
  )
}
