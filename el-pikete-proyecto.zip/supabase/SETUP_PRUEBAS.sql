-- El Pikete · pruebas de seguridad. Pégalo DESPUÉS del setup. Cada bloque termina con un aviso "OK"; si algo dice FALLO, no abras la app a gente.

-- ============================================================
-- mercado_test.sql
-- ============================================================
begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', 'a@prueba.co', '{"apodo":"Ana"}'),
  ('00000000-0000-0000-0000-0000000000b2', 'b@prueba.co', '{"apodo":"Beto"}');
update public.perfiles set provincia_cuba='Matanzas', estado_br='RR', ciudad_ibge=1400100, ciudad_nombre='Boa Vista', completado=true;
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);
do $$
declare a public.anuncios; n int;
begin
  a := public.publicar_anuncio('{"tipo":"vendo","titulo":"Bicicleta","descripcion":"Bicicleta en buen estado, aro 26."}');
  assert a.estado = 'activo', 'FALLO: un anuncio normal debería quedar activo';
  a := public.publicar_anuncio('{"tipo":"empleo","titulo":"Trabajo fácil","descripcion":"Gana dinero fácil, solo paga la tarifa por adelantado."}');
  assert a.estado = 'revision', 'FALLO: el anuncio con señales de estafa debería ir a revisión';
  begin
    insert into public.anuncios (user_id, ciudad_ibge, tipo, titulo, descripcion) values (auth.uid(), 1400100, 'vendo', 'Directo', 'Intento de saltarse la función.');
    assert false, 'FALLO: se pudo insertar sin pasar por la función';
  exception when insufficient_privilege then null; end;
end $$;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
do $$
declare n int;
begin
  select count(*) into n from public.anuncios_publicos;
  assert n = 1, 'FALLO: B debe ver solo el anuncio activo (no el de revisión)';
  update public.anuncios set estado = 'cerrado' where user_id = '00000000-0000-0000-0000-0000000000a1';
  get diagnostics n = row_count;
  assert n = 0, 'FALLO: B cerró un anuncio ajeno';
  raise notice 'OK: reglas de Mercado correctas';
end $$;
rollback;


-- ============================================================
-- moderacion_test.sql
-- ============================================================
-- Bloqueos, reportes y límite del Socio.
begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1','a@p.co','{"apodo":"Ana"}'),('00000000-0000-0000-0000-0000000000b2','b@p.co','{"apodo":"Beto"}'),
  ('00000000-0000-0000-0000-0000000000c3','c@p.co','{"apodo":"Cuca"}'),('00000000-0000-0000-0000-0000000000d4','d@p.co','{"apodo":"Dani"}');
update public.perfiles set provincia_cuba='Matanzas', estado_br='RR', ciudad_ibge=1400100, ciudad_nombre='Boa Vista', completado=true;
insert into public.publicaciones (id, user_id, ciudad_ibge, tipo, texto) values
  ('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-0000000000b2',1400100,'aviso','Post de Beto'),
  ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-0000000000d4',1400100,'aviso','Post de Dani');
insert into public.amistades (de, para, estado) values ('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b2','aceptada');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}',true);
do $$
declare n int; r text;
begin
  select count(*) into n from public.cuadra_muro; assert n = 2, 'FALLO: A debe ver 2 posts';
  perform public.bloquear_usuario('00000000-0000-0000-0000-0000000000b2');
  select count(*) into n from public.cuadra_muro; assert n = 1, 'FALLO: tras bloquear, A no debe ver el post de Beto';
  select count(*) into n from public.amistades; assert n = 0, 'FALLO: bloquear debe cortar la amistad';
  select count(*) into n from public.paisanos_cerca() where id = '00000000-0000-0000-0000-0000000000b2'; assert n = 0, 'FALLO: bloqueado sigue en paisanos';
  perform public.reportar_post('10000000-0000-0000-0000-000000000002');
  select public.socio_registrar_uso(2, 100) into r; assert r = 'ok', 'FALLO: primer uso del Socio';
  select public.socio_registrar_uso(2, 100) into r; assert r = 'ok', 'FALLO: segundo uso del Socio';
  select public.socio_registrar_uso(2, 100) into r; assert r = 'dia', 'FALLO: debe frenar al pasar el límite diario';
  begin perform * from public.roles; assert false, 'FALLO: leyó roles'; exception when insufficient_privilege then null; end;
  select count(*) into n from public.cola_moderacion(); assert n = 0, 'FALLO: quien no es moderador ve la cola';
end $$;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000c3","role":"authenticated"}',true);
do $$
declare n int;
begin
  perform public.reportar_post('10000000-0000-0000-0000-000000000002');
  select count(*) into n from public.cuadra_muro; assert n = 2, 'FALLO: con 1 reporte no debe ocultarse';
end $$;
reset role;
insert into public.reportes_post (post_id, user_id) values ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-0000000000b2');
insert into public.roles values ('00000000-0000-0000-0000-0000000000d4','moderador');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000c3","role":"authenticated"}',true);
do $$
declare n int;
begin
  select count(*) into n from public.cuadra_muro; assert n = 1, 'FALLO: con 3 reportes el post debe ocultarse';
end $$;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000d4","role":"authenticated"}',true);
do $$
declare n int;
begin
  select count(*) into n from public.cola_moderacion(); assert n = 1, 'FALLO: el moderador debe ver la cola';
  raise notice 'OK: moderación y límite del Socio correctos';
end $$;
rollback;


-- ============================================================
-- rls_test.sql
-- ============================================================
-- Prueba de reglas de acceso: se hace pasar por el usuario B e intenta leer datos del usuario A.
-- Si algo falla, el script se detiene con un mensaje. Se ejecuta dentro de una transacción y no deja datos.
begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', 'a@prueba.co', '{"apodo":"Ana"}'),
  ('00000000-0000-0000-0000-0000000000b2', 'b@prueba.co', '{"apodo":"Beto"}');
insert into public.contactos_privados (user_id, whatsapp, whatsapp_visibilidad)
  values ('00000000-0000-0000-0000-0000000000a1', '5595999999999', 'nadie');
update public.perfiles set provincia_cuba = 'Matanzas', estado_br = 'RR', ciudad_ibge = 1400100, completado = true,
  modo_discreto = true where id = '00000000-0000-0000-0000-0000000000a1';

set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
do $$
declare n int; prov text;
begin
  select count(*) into n from public.perfiles where id <> auth.uid();
  assert n = 0, 'FALLO: B puede leer perfiles ajenos en la tabla';
  select count(*) into n from public.contactos_privados;
  assert n = 0, 'FALLO: B puede leer contactos ajenos';
  assert public.ver_whatsapp('00000000-0000-0000-0000-0000000000a1') is null, 'FALLO: B ve el WhatsApp de A (visibilidad nadie)';
  select provincia_cuba into prov from public.perfiles_publicos where id = '00000000-0000-0000-0000-0000000000a1';
  assert prov is null, 'FALLO: la provincia se ve con modo discreto activo';
  update public.perfiles set apodo = 'Hack' where id = '00000000-0000-0000-0000-0000000000a1';
  get diagnostics n = row_count;
  assert n = 0, 'FALLO: B pudo editar el perfil de A';
  raise notice 'OK: todas las reglas de acceso se cumplen';
end $$;
rollback;


-- ============================================================
-- servicios_test.sql
-- ============================================================
-- Prueba de Servicios: B no puede escribir ni leer por tabla lo de A; la vista pública no filtra datos privados.
begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', 'a@prueba.co', '{"apodo":"Ana"}'),
  ('00000000-0000-0000-0000-0000000000b2', 'b@prueba.co', '{"apodo":"Beto"}');
update public.perfiles set provincia_cuba = 'Matanzas', estado_br = 'RR', ciudad_ibge = 1400100, ciudad_nombre = 'Boa Vista',
  completado = true, modo_discreto = true where id = '00000000-0000-0000-0000-0000000000a1';
insert into public.servicios (user_id, oficio, descripcion) values
  ('00000000-0000-0000-0000-0000000000a1', 'Electricista', 'Instalaciones y reparaciones en casa.');

set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
do $$
declare n int; prov text;
begin
  select count(*) into n from public.servicios;
  assert n = 0, 'FALLO: B lee por tabla el servicio de A';
  select count(*) into n from public.servicios_publicos where oficio = 'Electricista';
  assert n = 1, 'FALLO: B no ve el servicio de A en la vista pública';
  select provincia_cuba into prov from public.servicios_publicos where oficio = 'Electricista';
  assert prov is null, 'FALLO: la vista pública muestra la provincia con modo discreto';
  update public.servicios set oficio = 'Hack' where user_id = '00000000-0000-0000-0000-0000000000a1';
  get diagnostics n = row_count;
  assert n = 0, 'FALLO: B pudo editar el servicio de A';
  delete from public.servicios where user_id = '00000000-0000-0000-0000-0000000000a1';
  get diagnostics n = row_count;
  assert n = 0, 'FALLO: B pudo borrar el servicio de A';
  begin
    insert into public.servicios (user_id, oficio, descripcion) values
      ('00000000-0000-0000-0000-0000000000a1', 'Falso', 'Intento de crear a nombre de otro.');
    assert false, 'FALLO: B creó un servicio a nombre de A';
  exception when insufficient_privilege or check_violation then null; end;
  begin
    update public.servicios set trabajos = 999 where user_id = auth.uid();
    assert false, 'FALLO: se pudo escribir la reputación';
  exception when insufficient_privilege then null; end;
  raise notice 'OK: reglas de Servicios correctas';
end $$;
rollback;


-- ============================================================
-- social_test.sql
-- ============================================================
-- Prueba de la cuadra y los mensajes: otra ciudad y no-amigos no ven ni escriben.
begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', 'a@prueba.co', '{"apodo":"Ana"}'),
  ('00000000-0000-0000-0000-0000000000b2', 'b@prueba.co', '{"apodo":"Beto"}'),
  ('00000000-0000-0000-0000-0000000000c3', 'c@prueba.co', '{"apodo":"Cuca"}');
update public.perfiles set provincia_cuba='Matanzas', estado_br='RR', ciudad_ibge=1400100, ciudad_nombre='Boa Vista', completado=true
  where id in ('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b2');
update public.perfiles set provincia_cuba='La Habana', estado_br='AM', ciudad_ibge=1302603, ciudad_nombre='Manaus', completado=true
  where id = '00000000-0000-0000-0000-0000000000c3';
insert into public.publicaciones (user_id, ciudad_ibge, tipo, texto) values
  ('00000000-0000-0000-0000-0000000000a1', 1400100, 'aviso', 'Hola cuadra');
insert into public.mensajes (de, para, texto) values ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-0000000000b2', 'secreto A a B');

set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000c3","role":"authenticated"}', true);
do $$
declare n int;
begin
  select count(*) into n from public.cuadra_muro;
  assert n = 0, 'FALLO: C (otra ciudad) ve publicaciones de Boa Vista';
  select count(*) into n from public.mensajes;
  assert n = 0, 'FALLO: C lee mensajes ajenos';
  begin
    insert into public.publicaciones (user_id, ciudad_ibge, tipo, texto) values (auth.uid(), 1400100, 'aviso', 'cuela');
    assert false, 'FALLO: C publicó en otra ciudad';
  exception when insufficient_privilege or check_violation then null; end;
  begin
    insert into public.mensajes (de, para, texto) values (auth.uid(), '00000000-0000-0000-0000-0000000000a1', 'sin ser amigos');
    assert false, 'FALLO: C escribió sin ser amigo';
  exception when insufficient_privilege or check_violation then null; end;
end $$;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
do $$
declare n int;
begin
  select count(*) into n from public.cuadra_muro;
  assert n = 1, 'FALLO: B no ve el muro de su ciudad';
  select count(*) into n from public.mensajes;
  assert n = 1, 'FALLO: B no ve el mensaje que le escribieron';
  raise notice 'OK: reglas de la cuadra y mensajes correctas';
end $$;
rollback;
