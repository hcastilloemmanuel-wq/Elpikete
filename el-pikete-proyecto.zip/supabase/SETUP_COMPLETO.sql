-- El Pikete · TODA la base de datos en un solo archivo. Pégalo completo en Supabase > SQL Editor > Run (una sola vez).

-- ============================================================
-- 0001_perfiles.sql
-- ============================================================
-- El Pikete · Migración 0001 · Perfiles, contactos privados, amistades y reglas de acceso
-- Pégalo completo en Supabase > SQL Editor > New query > Run.

create table public.perfiles (
  id uuid primary key references auth.users on delete cascade,
  apodo text not null check (char_length(apodo) between 2 and 30),
  provincia_cuba text check (provincia_cuba in (
    'Pinar del Río','Artemisa','La Habana','Mayabeque','Matanzas','Cienfuegos','Villa Clara','Sancti Spíritus',
    'Ciego de Ávila','Camagüey','Las Tunas','Holguín','Granma','Santiago de Cuba','Guantánamo','Isla de la Juventud')),
  estado_br char(2),
  ciudad_ibge integer,
  ciudad_nombre text,
  barrio text check (char_length(barrio) <= 60),
  oficios text[] not null default '{}' check (cardinality(oficios) <= 6),
  oficio_visibilidad text not null default 'todos' check (oficio_visibilidad in ('todos','amigos','servicios')),
  modo_discreto boolean not null default false,
  recien_llegado boolean not null default false,
  propositos text[] not null default '{}',
  frase text check (char_length(frase) <= 120),
  avatar_color text not null default '#C9A24B' check (avatar_color ~ '^#[0-9A-Fa-f]{6}$'),
  paso smallint not null default 2 check (paso between 1 and 7),
  completado boolean not null default false,
  creado_en timestamptz not null default now(),
  constraint completo_si_terminado check (
    not completado or (provincia_cuba is not null and estado_br is not null and ciudad_ibge is not null))
);
alter table public.perfiles enable row level security;
revoke all on public.perfiles from anon;

create policy "ver mi perfil" on public.perfiles for select to authenticated using (id = auth.uid());
create policy "editar mi perfil" on public.perfiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- Vista que ven los demás: sin correo, sin WhatsApp, y sin provincia si el usuario está en modo discreto.
create view public.perfiles_publicos as
  select id, apodo,
         case when modo_discreto then null else provincia_cuba end as provincia_cuba,
         estado_br, ciudad_ibge, ciudad_nombre, frase, avatar_color,
         case when oficio_visibilidad = 'todos' then oficios else '{}'::text[] end as oficios
  from public.perfiles
  where completado;
revoke all on public.perfiles_publicos from anon;
grant select on public.perfiles_publicos to authenticated;

create table public.contactos_privados (
  user_id uuid primary key references public.perfiles(id) on delete cascade,
  whatsapp text check (whatsapp ~ '^[1-9][0-9]{7,14}$'),
  whatsapp_visibilidad text not null default 'nadie' check (whatsapp_visibilidad in ('nadie','amigos','todos'))
);
alter table public.contactos_privados enable row level security;
revoke all on public.contactos_privados from anon;
create policy "solo el dueño" on public.contactos_privados for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create table public.amistades (
  id uuid primary key default gen_random_uuid(),
  de uuid not null references public.perfiles(id) on delete cascade,
  para uuid not null references public.perfiles(id) on delete cascade,
  estado text not null default 'pendiente' check (estado in ('pendiente','aceptada')),
  creado_en timestamptz not null default now(),
  check (de <> para),
  unique (de, para)
);
alter table public.amistades enable row level security;
revoke all on public.amistades from anon;
create policy "ver mis amistades" on public.amistades for select to authenticated using (de = auth.uid() or para = auth.uid());
create policy "pedir amistad" on public.amistades for insert to authenticated with check (de = auth.uid() and estado = 'pendiente');
create policy "aceptar amistad" on public.amistades for update to authenticated using (para = auth.uid()) with check (para = auth.uid());
create policy "borrar amistad" on public.amistades for delete to authenticated using (de = auth.uid() or para = auth.uid());

-- Al crearse una cuenta en Supabase Auth se crea su perfil vacío.
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare a text;
begin
  a := left(coalesce(nullif(trim(new.raw_user_meta_data->>'apodo'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'Paisano'), 30);
  if char_length(a) < 2 then a := 'Paisano'; end if;
  insert into public.perfiles (id, apodo) values (new.id, a);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- El WhatsApp de otra persona solo se obtiene por aquí, que revisa su visibilidad y la amistad.
create function public.ver_whatsapp(objetivo uuid) returns text language sql stable security definer set search_path = public as $$
  select c.whatsapp from public.contactos_privados c
  where c.user_id = objetivo and (
    c.user_id = auth.uid()
    or c.whatsapp_visibilidad = 'todos'
    or (c.whatsapp_visibilidad = 'amigos' and exists (
      select 1 from public.amistades a
      where a.estado = 'aceptada'
        and ((a.de = auth.uid() and a.para = objetivo) or (a.para = auth.uid() and a.de = objetivo)))));
$$;
revoke all on function public.ver_whatsapp(uuid) from public, anon;
grant execute on function public.ver_whatsapp(uuid) to authenticated;

-- Borrar mi cuenta: borra el usuario y, en cascada, todo lo suyo.
create function public.borrar_mi_cuenta() returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'sin sesión'; end if;
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.borrar_mi_cuenta() from public, anon;
grant execute on function public.borrar_mi_cuenta() to authenticated;


-- ============================================================
-- 0004_servicios.sql
-- ============================================================
-- El Pikete · Migración 0004 · Servicios (directorio de oficios)
-- Pégalo completo en Supabase > SQL Editor > New query > Run. Va después de la 0001.

create table public.servicios (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.perfiles(id) on delete cascade,
  oficio text not null check (char_length(oficio) between 2 and 60),
  descripcion text not null check (char_length(descripcion) between 10 and 400),
  zonas text check (char_length(zonas) <= 120),
  precio text check (char_length(precio) <= 60),
  horario text check (char_length(horario) <= 60),
  habla_pt boolean not null default false,
  domicilio boolean not null default false,
  urgencias boolean not null default false,
  disponible_hoy boolean not null default false,
  mostrar_whatsapp boolean not null default false,
  activo boolean not null default true,
  trabajos integer not null default 0 check (trabajos >= 0),
  rapidez_min integer check (rapidez_min >= 0),
  resenas integer not null default 0 check (resenas >= 0),
  promedio numeric(2,1) check (promedio between 1 and 5),
  creado_en timestamptz not null default now()
);
create index servicios_oficio_idx on public.servicios (lower(oficio));
alter table public.servicios enable row level security;
revoke all on public.servicios from anon;

-- Los números de reputación los calcula el servidor (fases siguientes): el dueño no puede escribirlos.
revoke insert, update on public.servicios from authenticated;
grant insert (user_id, oficio, descripcion, zonas, precio, horario, habla_pt, domicilio, urgencias, disponible_hoy, mostrar_whatsapp, activo)
  on public.servicios to authenticated;
grant update (oficio, descripcion, zonas, precio, horario, habla_pt, domicilio, urgencias, disponible_hoy, mostrar_whatsapp, activo)
  on public.servicios to authenticated;
grant select, delete on public.servicios to authenticated;

-- La tabla solo la lee su dueño. Los demás consultan la vista servicios_publicos (que filtra perfiles completados).
create policy "ver mi servicio" on public.servicios for select to authenticated using (user_id = auth.uid());
create policy "crear mi servicio" on public.servicios for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.perfiles p where p.id = auth.uid() and p.completado));
create policy "editar mi servicio" on public.servicios for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "borrar mi servicio" on public.servicios for delete to authenticated using (user_id = auth.uid());

-- Lo que ve la gente: servicio + datos públicos del perfil (nunca correo ni WhatsApp; sin provincia si es discreto).
create view public.servicios_publicos as
  select s.id, s.user_id, p.apodo,
         case when p.modo_discreto then null else p.provincia_cuba end as provincia_cuba,
         p.avatar_color, s.oficio, s.descripcion, p.ciudad_ibge, p.ciudad_nombre, p.barrio,
         s.zonas, s.precio, s.horario, s.habla_pt, s.domicilio, s.urgencias, s.disponible_hoy,
         s.mostrar_whatsapp, s.trabajos, s.rapidez_min, s.resenas, s.promedio
  from public.servicios s join public.perfiles p on p.id = s.user_id
  where s.activo and p.completado;
revoke all on public.servicios_publicos from anon;
grant select on public.servicios_publicos to authenticated;

-- Fotos del trabajo: carpeta privada por usuario en el almacenamiento (se usará con src/lib/imagen.ts).
insert into storage.buckets (id, name, public) values ('servicios', 'servicios', false) on conflict do nothing;
create policy "fotos: leer autenticados" on storage.objects for select to authenticated using (bucket_id = 'servicios');
create policy "fotos: subir a mi carpeta" on storage.objects for insert to authenticated
  with check (bucket_id = 'servicios' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "fotos: borrar las mías" on storage.objects for delete to authenticated
  using (bucket_id = 'servicios' and (storage.foldername(name))[1] = auth.uid()::text);


-- ============================================================
-- 0005_social.sql
-- ============================================================
-- El Pikete · Migración 0005 · Cuadra (publicaciones por ciudad), comentarios, "me gusta" y mensajes
-- Pégalo completo en Supabase > SQL Editor > New query > Run. Va después de la 0001 y la 0004.

create function public.mi_ciudad() returns integer language sql stable security definer set search_path = public as $$
  select ciudad_ibge from public.perfiles where id = auth.uid() and completado;
$$;
revoke all on function public.mi_ciudad() from public, anon;
grant execute on function public.mi_ciudad() to authenticated;

create table public.publicaciones (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.perfiles(id) on delete cascade,
  ciudad_ibge integer not null,
  tipo text not null check (tipo in ('pregunta','aviso','evento','recomendacion','llegue')),
  texto text not null check (char_length(btrim(texto)) between 1 and 500),
  creado_en timestamptz not null default now()
);
create index publicaciones_ciudad_idx on public.publicaciones (ciudad_ibge, creado_en desc);
alter table public.publicaciones enable row level security;
revoke all on public.publicaciones from anon;
create policy "ver las de mi ciudad" on public.publicaciones for select to authenticated using (ciudad_ibge = public.mi_ciudad());
create policy "publicar en mi ciudad" on public.publicaciones for insert to authenticated
  with check (user_id = auth.uid() and ciudad_ibge = public.mi_ciudad());
create policy "borrar las mías" on public.publicaciones for delete to authenticated using (user_id = auth.uid());

create table public.comentarios (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.publicaciones(id) on delete cascade,
  user_id uuid not null references public.perfiles(id) on delete cascade,
  texto text not null check (char_length(btrim(texto)) between 1 and 500),
  creado_en timestamptz not null default now()
);
create index comentarios_post_idx on public.comentarios (post_id, creado_en);
alter table public.comentarios enable row level security;
revoke all on public.comentarios from anon;
create policy "ver comentarios de mi ciudad" on public.comentarios for select to authenticated
  using (exists (select 1 from public.publicaciones p where p.id = post_id and p.ciudad_ibge = public.mi_ciudad()));
create policy "comentar en mi ciudad" on public.comentarios for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.publicaciones p where p.id = post_id and p.ciudad_ibge = public.mi_ciudad()));
create policy "borrar mis comentarios" on public.comentarios for delete to authenticated using (user_id = auth.uid());

create table public.me_gusta (
  post_id uuid not null references public.publicaciones(id) on delete cascade,
  user_id uuid not null references public.perfiles(id) on delete cascade,
  primary key (post_id, user_id)
);
alter table public.me_gusta enable row level security;
revoke all on public.me_gusta from anon;
create policy "ver mis me gusta" on public.me_gusta for select to authenticated using (user_id = auth.uid());
create policy "dar me gusta" on public.me_gusta for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.publicaciones p where p.id = post_id and p.ciudad_ibge = public.mi_ciudad()));
create policy "quitar mi me gusta" on public.me_gusta for delete to authenticated using (user_id = auth.uid());

-- Muro de mi ciudad: publicación + autor (sin provincia si es discreto) + conteos + si yo di me gusta.
create view public.cuadra_muro as
  select p.id, p.user_id, pe.apodo,
         case when pe.modo_discreto then null else pe.provincia_cuba end as provincia_cuba,
         pe.avatar_color, pe.ciudad_nombre, p.tipo, p.texto, p.creado_en,
         (select count(*) from public.comentarios c where c.post_id = p.id) as comentarios,
         (select count(*) from public.me_gusta g where g.post_id = p.id) as likes,
         exists (select 1 from public.me_gusta g where g.post_id = p.id and g.user_id = auth.uid()) as yo_like
  from public.publicaciones p join public.perfiles pe on pe.id = p.user_id
  where p.ciudad_ibge = public.mi_ciudad();
revoke all on public.cuadra_muro from anon;
grant select on public.cuadra_muro to authenticated;

create view public.cuadra_comentarios as
  select c.id, c.post_id, c.user_id, pe.apodo,
         case when pe.modo_discreto then null else pe.provincia_cuba end as provincia_cuba,
         pe.avatar_color, c.texto, c.creado_en
  from public.comentarios c
  join public.publicaciones p on p.id = c.post_id and p.ciudad_ibge = public.mi_ciudad()
  join public.perfiles pe on pe.id = c.user_id;
revoke all on public.cuadra_comentarios from anon;
grant select on public.cuadra_comentarios to authenticated;

-- Paisanos de mi ciudad que se pueden descubrir: nunca el modo discreto, nunca yo.
create function public.paisanos_cerca() returns table (id uuid, apodo text, provincia_cuba text, avatar_color text, ciudad_nombre text)
language sql stable security definer set search_path = public as $$
  select p.id, p.apodo, p.provincia_cuba, p.avatar_color, p.ciudad_nombre from public.perfiles p
  where p.completado and not p.modo_discreto and p.ciudad_ibge = public.mi_ciudad() and p.id <> auth.uid()
  order by p.creado_en desc limit 100;
$$;
revoke all on function public.paisanos_cerca() from public, anon;
grant execute on function public.paisanos_cerca() to authenticated;

-- Mis amigos y solicitudes con los datos públicos de la otra persona.
create function public.mis_amistades() returns table (id uuid, apodo text, provincia_cuba text, avatar_color text, ciudad_nombre text, estado text)
language sql stable security definer set search_path = public as $$
  select p.id, p.apodo,
         case when p.modo_discreto and a.estado <> 'aceptada' then null else p.provincia_cuba end,
         p.avatar_color, p.ciudad_nombre,
         case when a.estado = 'aceptada' then 'amigo' when a.de = auth.uid() then 'enviada' else 'recibida' end
  from public.amistades a
  join public.perfiles p on p.id = case when a.de = auth.uid() then a.para else a.de end
  where a.de = auth.uid() or a.para = auth.uid();
$$;
revoke all on function public.mis_amistades() from public, anon;
grant execute on function public.mis_amistades() to authenticated;

create function public.son_amigos(a uuid, b uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.amistades x where x.estado = 'aceptada' and ((x.de = a and x.para = b) or (x.de = b and x.para = a)));
$$;
revoke all on function public.son_amigos(uuid, uuid) from public, anon;
grant execute on function public.son_amigos(uuid, uuid) to authenticated;

-- Mensajes: solo entre amigos, solo los ven los dos.
create table public.mensajes (
  id uuid primary key default gen_random_uuid(),
  de uuid not null references public.perfiles(id) on delete cascade,
  para uuid not null references public.perfiles(id) on delete cascade,
  texto text not null check (char_length(btrim(texto)) between 1 and 1000),
  creado_en timestamptz not null default now(),
  check (de <> para)
);
create index mensajes_par_idx on public.mensajes (de, para, creado_en);
alter table public.mensajes enable row level security;
revoke all on public.mensajes from anon;
create policy "ver mis mensajes" on public.mensajes for select to authenticated using (de = auth.uid() or para = auth.uid());
create policy "escribir a un amigo" on public.mensajes for insert to authenticated
  with check (de = auth.uid() and public.son_amigos(de, para));


-- ============================================================
-- 0006_mercado.sql
-- ============================================================
-- El Pikete · Migración 0006 · La Bolsa y Pincha (anuncios por ciudad, vencen a los 30 días)
-- Va después de la 0005 (usa mi_ciudad()).

create table public.anuncios (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.perfiles(id) on delete cascade,
  ciudad_ibge integer not null,
  tipo text not null check (tipo in ('vendo','compro','alquilo','servicio','empleo','busco_empleo')),
  titulo text not null check (char_length(btrim(titulo)) between 4 and 80),
  descripcion text not null check (char_length(btrim(descripcion)) between 10 and 600),
  precio numeric(10,2) check (precio >= 0 and precio <= 10000000),
  barrio text check (char_length(barrio) <= 60),
  jornada text check (char_length(jornada) <= 40),
  idioma text check (char_length(idioma) <= 40),
  mostrar_whatsapp boolean not null default false,
  estado text not null default 'activo' check (estado in ('activo','cerrado','revision')),
  creado_en timestamptz not null default now(),
  vence_en timestamptz not null default now() + interval '30 days'
);
create index anuncios_ciudad_idx on public.anuncios (ciudad_ibge, creado_en desc);
alter table public.anuncios enable row level security;
revoke all on public.anuncios from anon;
revoke insert, update, delete on public.anuncios from authenticated;
grant select on public.anuncios to authenticated;
grant update (estado) on public.anuncios to authenticated;
create policy "ver los míos" on public.anuncios for select to authenticated using (user_id = auth.uid());
-- Cerrar el mío: solo puede pasar a 'cerrado' (renovar y revisión van por funciones del servidor).
create policy "cerrar el mío" on public.anuncios for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and estado = 'cerrado');

create table public.reportes_anuncio (
  anuncio_id uuid not null references public.anuncios(id) on delete cascade,
  user_id uuid not null references public.perfiles(id) on delete cascade,
  creado_en timestamptz not null default now(),
  primary key (anuncio_id, user_id)
);
alter table public.reportes_anuncio enable row level security;
revoke all on public.reportes_anuncio from anon, authenticated;

-- Señales de estafa (las mismas que en la app, pero aquí no se pueden saltar).
create function public.anuncio_riesgoso(txt text) returns boolean language sql immutable as $$
  select txt ~* '(adelantad[oa]|adiantad[oa]|taxa de (inscri|cadastro|admiss)|western union|moneygram|transfer[eê]ncia para (um )?terceiro|transferencia a (un )?tercero|gan(a|e|ar) (dinero )?f[aá]cil|ganancias? garantizad|ganhos garantidos|multiplica tu dinero|(env[ií]a|manda|envie)\s+(tu|seu|su)?\s*(pasaporte|passaporte|cpf|documentos?))';
$$;

create function public.publicar_anuncio(p jsonb) returns public.anuncios language plpgsql security definer set search_path = public as $$
declare ciudad integer; fila public.anuncios;
begin
  ciudad := public.mi_ciudad();
  if auth.uid() is null or ciudad is null then raise exception 'perfil incompleto'; end if;
  -- Límite suave: 10 anuncios por día.
  if (select count(*) from public.anuncios where user_id = auth.uid() and creado_en > now() - interval '1 day') >= 10 then
    raise exception 'demasiados anuncios hoy';
  end if;
  insert into public.anuncios (user_id, ciudad_ibge, tipo, titulo, descripcion, precio, barrio, jornada, idioma, mostrar_whatsapp, estado)
  values (auth.uid(), ciudad, p->>'tipo', p->>'titulo', p->>'descripcion', nullif(p->>'precio','')::numeric, nullif(p->>'barrio',''),
          nullif(p->>'jornada',''), nullif(p->>'idioma',''), coalesce((p->>'mostrar_whatsapp')::boolean, false),
          case when public.anuncio_riesgoso(coalesce(p->>'titulo','') || ' ' || coalesce(p->>'descripcion','')) then 'revision' else 'activo' end)
  returning * into fila;
  return fila;
end $$;
revoke all on function public.publicar_anuncio(jsonb) from public, anon;
grant execute on function public.publicar_anuncio(jsonb) to authenticated;

create function public.renovar_anuncio(anuncio uuid) returns void language sql security definer set search_path = public as $$
  update public.anuncios set vence_en = now() + interval '30 days', estado = 'activo'
  where id = anuncio and user_id = auth.uid() and estado in ('activo','cerrado');
$$;
revoke all on function public.renovar_anuncio(uuid) from public, anon;
grant execute on function public.renovar_anuncio(uuid) to authenticated;

-- Tres reportes de personas distintas lo mandan a revisión.
create function public.reportar_anuncio(anuncio uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.anuncios where id = anuncio and ciudad_ibge = public.mi_ciudad()) then raise exception 'no disponible'; end if;
  insert into public.reportes_anuncio (anuncio_id, user_id) values (anuncio, auth.uid()) on conflict do nothing;
  if (select count(*) from public.reportes_anuncio where anuncio_id = anuncio) >= 3 then
    update public.anuncios set estado = 'revision' where id = anuncio;
  end if;
end $$;
revoke all on function public.reportar_anuncio(uuid) from public, anon;
grant execute on function public.reportar_anuncio(uuid) to authenticated;

-- Lo que ve la gente: solo activos y vigentes de mi ciudad (más los míos, en cualquier estado).
create view public.anuncios_publicos as
  select a.id, a.user_id, pe.apodo, pe.avatar_color, a.ciudad_ibge, pe.ciudad_nombre, a.tipo, a.titulo, a.descripcion, a.precio,
         a.barrio, a.jornada, a.idioma, a.mostrar_whatsapp, a.creado_en, a.vence_en, a.estado
  from public.anuncios a join public.perfiles pe on pe.id = a.user_id
  where (a.ciudad_ibge = public.mi_ciudad() and a.estado = 'activo' and a.vence_en > now()) or a.user_id = auth.uid();
revoke all on public.anuncios_publicos from anon;
grant select on public.anuncios_publicos to authenticated;


-- ============================================================
-- 0007_moderacion.sql
-- ============================================================
-- El Pikete · Migración 0007 · Reportes, bloqueos y cola de moderación
-- Va después de la 0006.

create table public.bloqueos (
  de uuid not null references public.perfiles(id) on delete cascade,
  a uuid not null references public.perfiles(id) on delete cascade,
  creado_en timestamptz not null default now(),
  primary key (de, a), check (de <> a)
);
alter table public.bloqueos enable row level security;
revoke all on public.bloqueos from anon;
create policy "ver mis bloqueos" on public.bloqueos for select to authenticated using (de = auth.uid());
create policy "desbloquear" on public.bloqueos for delete to authenticated using (de = auth.uid());

create function public.hay_bloqueo(persona1 uuid, persona2 uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.bloqueos x where (x.de = persona1 and x.a = persona2) or (x.de = persona2 and x.a = persona1));
$$;
revoke all on function public.hay_bloqueo(uuid, uuid) from public, anon;
grant execute on function public.hay_bloqueo(uuid, uuid) to authenticated;

create function public.bloquear_usuario(objetivo uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if objetivo = auth.uid() then return; end if;
  insert into public.bloqueos (de, a) values (auth.uid(), objetivo) on conflict do nothing;
  delete from public.amistades where (de = auth.uid() and para = objetivo) or (para = auth.uid() and de = objetivo);
end $$;
revoke all on function public.bloquear_usuario(uuid) from public, anon;
grant execute on function public.bloquear_usuario(uuid) to authenticated;

create table public.reportes_post (
  post_id uuid not null references public.publicaciones(id) on delete cascade,
  user_id uuid not null references public.perfiles(id) on delete cascade,
  creado_en timestamptz not null default now(),
  primary key (post_id, user_id)
);
alter table public.reportes_post enable row level security;
revoke all on public.reportes_post from anon, authenticated;

create function public.reportar_post(post uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.publicaciones where id = post and ciudad_ibge = public.mi_ciudad()) then raise exception 'no disponible'; end if;
  insert into public.reportes_post (post_id, user_id) values (post, auth.uid()) on conflict do nothing;
end $$;
revoke all on function public.reportar_post(uuid) from public, anon;
grant execute on function public.reportar_post(uuid) to authenticated;

-- El muro ya no muestra: lo de personas bloqueadas ni lo que tiene 3 o más reportes.
create or replace view public.cuadra_muro as
  select p.id, p.user_id, pe.apodo,
         case when pe.modo_discreto then null else pe.provincia_cuba end as provincia_cuba,
         pe.avatar_color, pe.ciudad_nombre, p.tipo, p.texto, p.creado_en,
         (select count(*) from public.comentarios c where c.post_id = p.id) as comentarios,
         (select count(*) from public.me_gusta g where g.post_id = p.id) as likes,
         exists (select 1 from public.me_gusta g where g.post_id = p.id and g.user_id = auth.uid()) as yo_like
  from public.publicaciones p join public.perfiles pe on pe.id = p.user_id
  where p.ciudad_ibge = public.mi_ciudad()
    and not public.hay_bloqueo(auth.uid(), p.user_id)
    and (select count(*) from public.reportes_post r where r.post_id = p.id) < 3;

create or replace view public.cuadra_comentarios as
  select c.id, c.post_id, c.user_id, pe.apodo,
         case when pe.modo_discreto then null else pe.provincia_cuba end as provincia_cuba,
         pe.avatar_color, c.texto, c.creado_en
  from public.comentarios c
  join public.publicaciones p on p.id = c.post_id and p.ciudad_ibge = public.mi_ciudad()
  join public.perfiles pe on pe.id = c.user_id
  where not public.hay_bloqueo(auth.uid(), c.user_id);

create or replace function public.paisanos_cerca() returns table (id uuid, apodo text, provincia_cuba text, avatar_color text, ciudad_nombre text)
language sql stable security definer set search_path = public as $$
  select p.id, p.apodo, p.provincia_cuba, p.avatar_color, p.ciudad_nombre from public.perfiles p
  where p.completado and not p.modo_discreto and p.ciudad_ibge = public.mi_ciudad() and p.id <> auth.uid()
    and not public.hay_bloqueo(auth.uid(), p.id)
  order by p.creado_en desc limit 100;
$$;

-- Nadie puede escribirle a quien lo bloqueó (ni a quien él bloqueó).
drop policy "escribir a un amigo" on public.mensajes;
create policy "escribir a un amigo" on public.mensajes for insert to authenticated
  with check (de = auth.uid() and public.son_amigos(de, para) and not public.hay_bloqueo(de, para));

-- Moderación: quien tenga una fila en roles ve la cola. Se asigna desde el panel de Supabase (ver la guía).
create table public.roles (user_id uuid primary key references public.perfiles(id) on delete cascade, rol text not null check (rol in ('moderador')));
alter table public.roles enable row level security;
revoke all on public.roles from anon, authenticated;

create function public.cola_moderacion() returns table (tipo text, id uuid, texto text, reportes bigint, creado_en timestamptz)
language sql stable security definer set search_path = public as $$
  select 'publicacion', p.id, p.texto, count(r.*), p.creado_en from public.publicaciones p
    join public.reportes_post r on r.post_id = p.id
    where exists (select 1 from public.roles x where x.user_id = auth.uid() and x.rol = 'moderador') group by p.id
  union all
  select 'anuncio', a.id, a.titulo || ' — ' || a.descripcion, 0, a.creado_en from public.anuncios a
    where a.estado = 'revision' and exists (select 1 from public.roles x where x.user_id = auth.uid() and x.rol = 'moderador')
  order by 5 desc;
$$;
revoke all on function public.cola_moderacion() from public, anon;
grant execute on function public.cola_moderacion() to authenticated;


-- ============================================================
-- 0008_socio.sql
-- ============================================================
-- El Pikete · Migración 0008 · Límite de uso de El Socio (IA)
create table public.socio_uso (
  user_id uuid not null references public.perfiles(id) on delete cascade,
  dia date not null default current_date,
  n integer not null default 0,
  primary key (user_id, dia)
);
alter table public.socio_uso enable row level security;
revoke all on public.socio_uso from anon, authenticated;

-- Cuenta un mensaje. Devuelve 'ok', 'dia' (pasó el límite diario) o 'mes' (pasó el tope mensual de toda la app).
create function public.socio_registrar_uso(limite_dia integer default 30, tope_mes integer default 5000) returns text
language plpgsql security definer set search_path = public as $$
declare hoy integer; mes integer;
begin
  if auth.uid() is null then return 'dia'; end if;
  select coalesce(sum(n), 0) into mes from public.socio_uso where dia >= date_trunc('month', current_date);
  if mes >= tope_mes then return 'mes'; end if;
  select coalesce(n, 0) into hoy from public.socio_uso where user_id = auth.uid() and dia = current_date;
  if coalesce(hoy, 0) >= limite_dia then return 'dia'; end if;
  insert into public.socio_uso (user_id, dia, n) values (auth.uid(), current_date, 1)
    on conflict (user_id, dia) do update set n = public.socio_uso.n + 1;
  return 'ok';
end $$;
revoke all on function public.socio_registrar_uso(integer, integer) from public, anon;
grant execute on function public.socio_registrar_uso(integer, integer) to authenticated;
