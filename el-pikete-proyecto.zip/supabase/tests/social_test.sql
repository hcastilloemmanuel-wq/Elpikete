-- Prueba de la cuadra y los mensajes: otra ciudad y no-amigos no ven ni escriben.
begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', 'a@prueba.co', '{"apodo":"Ana"}'),
  ('00000000-0000-0000-0000-0000000000b2', 'b@prueba.co', '{"apodo":"Beto"}'),
  ('00000000-0000-0000-0000-0000000000c3', 'c@prueba.co', '{"apodo":"Cuca"}');
update public.perfiles set provincia_cuba='Matanzas', estado_br='RR', ciudad_ibge=1400100, ciudad_nombre='Boa Vista', completado=true
  where id in ('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b2');
update public.perfiles set provincia_cuba='La Habana', estado_br='AM', ciudad_ibge=1302603, ciudad_nombre='Manaus', completado=true
  where id = '00000000-0000-0000-0000-0000000000c3';
insert into public.publicaciones (user_id, ciudad_ibge, tipo, texto) values
  ('00000000-0000-0000-0000-0000000000a1', 1400100, 'aviso', 'Hola cuadra');
insert into public.mensajes (de, para, texto) values ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-0000000000b2', 'secreto A a B');

set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000c3","role":"authenticated"}', true);
do $$
declare n int;
begin
  select count(*) into n from public.cuadra_muro;
  assert n = 0, 'FALLO: C (otra ciudad) ve publicaciones de Boa Vista';
  select count(*) into n from public.mensajes;
  assert n = 0, 'FALLO: C lee mensajes ajenos';
  begin
    insert into public.publicaciones (user_id, ciudad_ibge, tipo, texto) values (auth.uid(), 1400100, 'aviso', 'cuela');
    assert false, 'FALLO: C publicó en otra ciudad';
  exception when insufficient_privilege or check_violation then null; end;
  begin
    insert into public.mensajes (de, para, texto) values (auth.uid(), '00000000-0000-0000-0000-0000000000a1', 'sin ser amigos');
    assert false, 'FALLO: C escribió sin ser amigo';
  exception when insufficient_privilege or check_violation then null; end;
end $$;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
do $$
declare n int;
begin
  select count(*) into n from public.cuadra_muro;
  assert n = 1, 'FALLO: B no ve el muro de su ciudad';
  select count(*) into n from public.mensajes;
  assert n = 1, 'FALLO: B no ve el mensaje que le escribieron';
  raise notice 'OK: reglas de la cuadra y mensajes correctas';
end $$;
rollback;
