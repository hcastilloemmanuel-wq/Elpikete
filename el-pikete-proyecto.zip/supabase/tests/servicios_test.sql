-- Prueba de Servicios: B no puede escribir ni leer por tabla lo de A; la vista pública no filtra datos privados.
begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', 'a@prueba.co', '{"apodo":"Ana"}'),
  ('00000000-0000-0000-0000-0000000000b2', 'b@prueba.co', '{"apodo":"Beto"}');
update public.perfiles set provincia_cuba = 'Matanzas', estado_br = 'RR', ciudad_ibge = 1400100, ciudad_nombre = 'Boa Vista',
  completado = true, modo_discreto = true where id = '00000000-0000-0000-0000-0000000000a1';
insert into public.servicios (user_id, oficio, descripcion) values
  ('00000000-0000-0000-0000-0000000000a1', 'Electricista', 'Instalaciones y reparaciones en casa.');

set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
do $$
declare n int; prov text;
begin
  select count(*) into n from public.servicios;
  assert n = 0, 'FALLO: B lee por tabla el servicio de A';
  select count(*) into n from public.servicios_publicos where oficio = 'Electricista';
  assert n = 1, 'FALLO: B no ve el servicio de A en la vista pública';
  select provincia_cuba into prov from public.servicios_publicos where oficio = 'Electricista';
  assert prov is null, 'FALLO: la vista pública muestra la provincia con modo discreto';
  update public.servicios set oficio = 'Hack' where user_id = '00000000-0000-0000-0000-0000000000a1';
  get diagnostics n = row_count;
  assert n = 0, 'FALLO: B pudo editar el servicio de A';
  delete from public.servicios where user_id = '00000000-0000-0000-0000-0000000000a1';
  get diagnostics n = row_count;
  assert n = 0, 'FALLO: B pudo borrar el servicio de A';
  begin
    insert into public.servicios (user_id, oficio, descripcion) values
      ('00000000-0000-0000-0000-0000000000a1', 'Falso', 'Intento de crear a nombre de otro.');
    assert false, 'FALLO: B creó un servicio a nombre de A';
  exception when insufficient_privilege or check_violation then null; end;
  begin
    update public.servicios set trabajos = 999 where user_id = auth.uid();
    assert false, 'FALLO: se pudo escribir la reputación';
  exception when insufficient_privilege then null; end;
  raise notice 'OK: reglas de Servicios correctas';
end $$;
rollback;
