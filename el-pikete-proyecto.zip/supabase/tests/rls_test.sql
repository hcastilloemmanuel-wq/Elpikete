-- Prueba de reglas de acceso: se hace pasar por el usuario B e intenta leer datos del usuario A.
-- Si algo falla, el script se detiene con un mensaje. Se ejecuta dentro de una transacción y no deja datos.
begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', 'a@prueba.co', '{"apodo":"Ana"}'),
  ('00000000-0000-0000-0000-0000000000b2', 'b@prueba.co', '{"apodo":"Beto"}');
insert into public.contactos_privados (user_id, whatsapp, whatsapp_visibilidad)
  values ('00000000-0000-0000-0000-0000000000a1', '5595999999999', 'nadie');
update public.perfiles set provincia_cuba = 'Matanzas', estado_br = 'RR', ciudad_ibge = 1400100, completado = true,
  modo_discreto = true where id = '00000000-0000-0000-0000-0000000000a1';

set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
do $$
declare n int; prov text;
begin
  select count(*) into n from public.perfiles where id <> auth.uid();
  assert n = 0, 'FALLO: B puede leer perfiles ajenos en la tabla';
  select count(*) into n from public.contactos_privados;
  assert n = 0, 'FALLO: B puede leer contactos ajenos';
  assert public.ver_whatsapp('00000000-0000-0000-0000-0000000000a1') is null, 'FALLO: B ve el WhatsApp de A (visibilidad nadie)';
  select provincia_cuba into prov from public.perfiles_publicos where id = '00000000-0000-0000-0000-0000000000a1';
  assert prov is null, 'FALLO: la provincia se ve con modo discreto activo';
  update public.perfiles set apodo = 'Hack' where id = '00000000-0000-0000-0000-0000000000a1';
  get diagnostics n = row_count;
  assert n = 0, 'FALLO: B pudo editar el perfil de A';
  raise notice 'OK: todas las reglas de acceso se cumplen';
end $$;
rollback;
