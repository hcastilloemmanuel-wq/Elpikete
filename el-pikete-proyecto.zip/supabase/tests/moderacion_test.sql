-- Bloqueos, reportes y límite del Socio.
begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1','a@p.co','{"apodo":"Ana"}'),('00000000-0000-0000-0000-0000000000b2','b@p.co','{"apodo":"Beto"}'),
  ('00000000-0000-0000-0000-0000000000c3','c@p.co','{"apodo":"Cuca"}'),('00000000-0000-0000-0000-0000000000d4','d@p.co','{"apodo":"Dani"}');
update public.perfiles set provincia_cuba='Matanzas', estado_br='RR', ciudad_ibge=1400100, ciudad_nombre='Boa Vista', completado=true;
insert into public.publicaciones (id, user_id, ciudad_ibge, tipo, texto) values
  ('10000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-0000000000b2',1400100,'aviso','Post de Beto'),
  ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-0000000000d4',1400100,'aviso','Post de Dani');
insert into public.amistades (de, para, estado) values ('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b2','aceptada');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}',true);
do $$
declare n int; r text;
begin
  select count(*) into n from public.cuadra_muro; assert n = 2, 'FALLO: A debe ver 2 posts';
  perform public.bloquear_usuario('00000000-0000-0000-0000-0000000000b2');
  select count(*) into n from public.cuadra_muro; assert n = 1, 'FALLO: tras bloquear, A no debe ver el post de Beto';
  select count(*) into n from public.amistades; assert n = 0, 'FALLO: bloquear debe cortar la amistad';
  select count(*) into n from public.paisanos_cerca() where id = '00000000-0000-0000-0000-0000000000b2'; assert n = 0, 'FALLO: bloqueado sigue en paisanos';
  perform public.reportar_post('10000000-0000-0000-0000-000000000002');
  select public.socio_registrar_uso(2, 100) into r; assert r = 'ok', 'FALLO: primer uso del Socio';
  select public.socio_registrar_uso(2, 100) into r; assert r = 'ok', 'FALLO: segundo uso del Socio';
  select public.socio_registrar_uso(2, 100) into r; assert r = 'dia', 'FALLO: debe frenar al pasar el límite diario';
  begin perform * from public.roles; assert false, 'FALLO: leyó roles'; exception when insufficient_privilege then null; end;
  select count(*) into n from public.cola_moderacion(); assert n = 0, 'FALLO: quien no es moderador ve la cola';
end $$;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000c3","role":"authenticated"}',true);
do $$
declare n int;
begin
  perform public.reportar_post('10000000-0000-0000-0000-000000000002');
  select count(*) into n from public.cuadra_muro; assert n = 2, 'FALLO: con 1 reporte no debe ocultarse';
end $$;
reset role;
insert into public.reportes_post (post_id, user_id) values ('10000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-0000000000b2');
insert into public.roles values ('00000000-0000-0000-0000-0000000000d4','moderador');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000c3","role":"authenticated"}',true);
do $$
declare n int;
begin
  select count(*) into n from public.cuadra_muro; assert n = 1, 'FALLO: con 3 reportes el post debe ocultarse';
end $$;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000d4","role":"authenticated"}',true);
do $$
declare n int;
begin
  select count(*) into n from public.cola_moderacion(); assert n = 1, 'FALLO: el moderador debe ver la cola';
  raise notice 'OK: moderación y límite del Socio correctos';
end $$;
rollback;
