begin;
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', 'a@prueba.co', '{"apodo":"Ana"}'),
  ('00000000-0000-0000-0000-0000000000b2', 'b@prueba.co', '{"apodo":"Beto"}');
update public.perfiles set provincia_cuba='Matanzas', estado_br='RR', ciudad_ibge=1400100, ciudad_nombre='Boa Vista', completado=true;
set local role authenticated;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);
do $$
declare a public.anuncios; n int;
begin
  a := public.publicar_anuncio('{"tipo":"vendo","titulo":"Bicicleta","descripcion":"Bicicleta en buen estado, aro 26."}');
  assert a.estado = 'activo', 'FALLO: un anuncio normal debería quedar activo';
  a := public.publicar_anuncio('{"tipo":"empleo","titulo":"Trabajo fácil","descripcion":"Gana dinero fácil, solo paga la tarifa por adelantado."}');
  assert a.estado = 'revision', 'FALLO: el anuncio con señales de estafa debería ir a revisión';
  begin
    insert into public.anuncios (user_id, ciudad_ibge, tipo, titulo, descripcion) values (auth.uid(), 1400100, 'vendo', 'Directo', 'Intento de saltarse la función.');
    assert false, 'FALLO: se pudo insertar sin pasar por la función';
  exception when insufficient_privilege then null; end;
end $$;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
do $$
declare n int;
begin
  select count(*) into n from public.anuncios_publicos;
  assert n = 1, 'FALLO: B debe ver solo el anuncio activo (no el de revisión)';
  update public.anuncios set estado = 'cerrado' where user_id = '00000000-0000-0000-0000-0000000000a1';
  get diagnostics n = row_count;
  assert n = 0, 'FALLO: B cerró un anuncio ajeno';
  raise notice 'OK: reglas de Mercado correctas';
end $$;
rollback;
