-- El Pikete · Migración 0004 · Servicios (directorio de oficios)
-- Pégalo completo en Supabase > SQL Editor > New query > Run. Va después de la 0001.

create table public.servicios (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.perfiles(id) on delete cascade,
  oficio text not null check (char_length(oficio) between 2 and 60),
  descripcion text not null check (char_length(descripcion) between 10 and 400),
  zonas text check (char_length(zonas) <= 120),
  precio text check (char_length(precio) <= 60),
  horario text check (char_length(horario) <= 60),
  habla_pt boolean not null default false,
  domicilio boolean not null default false,
  urgencias boolean not null default false,
  disponible_hoy boolean not null default false,
  mostrar_whatsapp boolean not null default false,
  activo boolean not null default true,
  trabajos integer not null default 0 check (trabajos >= 0),
  rapidez_min integer check (rapidez_min >= 0),
  resenas integer not null default 0 check (resenas >= 0),
  promedio numeric(2,1) check (promedio between 1 and 5),
  creado_en timestamptz not null default now()
);
create index servicios_oficio_idx on public.servicios (lower(oficio));
alter table public.servicios enable row level security;
revoke all on public.servicios from anon;

-- Los números de reputación los calcula el servidor (fases siguientes): el dueño no puede escribirlos.
revoke insert, update on public.servicios from authenticated;
grant insert (user_id, oficio, descripcion, zonas, precio, horario, habla_pt, domicilio, urgencias, disponible_hoy, mostrar_whatsapp, activo)
  on public.servicios to authenticated;
grant update (oficio, descripcion, zonas, precio, horario, habla_pt, domicilio, urgencias, disponible_hoy, mostrar_whatsapp, activo)
  on public.servicios to authenticated;
grant select, delete on public.servicios to authenticated;

-- La tabla solo la lee su dueño. Los demás consultan la vista servicios_publicos (que filtra perfiles completados).
create policy "ver mi servicio" on public.servicios for select to authenticated using (user_id = auth.uid());
create policy "crear mi servicio" on public.servicios for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.perfiles p where p.id = auth.uid() and p.completado));
create policy "editar mi servicio" on public.servicios for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "borrar mi servicio" on public.servicios for delete to authenticated using (user_id = auth.uid());

-- Lo que ve la gente: servicio + datos públicos del perfil (nunca correo ni WhatsApp; sin provincia si es discreto).
create view public.servicios_publicos as
  select s.id, s.user_id, p.apodo,
         case when p.modo_discreto then null else p.provincia_cuba end as provincia_cuba,
         p.avatar_color, s.oficio, s.descripcion, p.ciudad_ibge, p.ciudad_nombre, p.barrio,
         s.zonas, s.precio, s.horario, s.habla_pt, s.domicilio, s.urgencias, s.disponible_hoy,
         s.mostrar_whatsapp, s.trabajos, s.rapidez_min, s.resenas, s.promedio
  from public.servicios s join public.perfiles p on p.id = s.user_id
  where s.activo and p.completado;
revoke all on public.servicios_publicos from anon;
grant select on public.servicios_publicos to authenticated;

-- Fotos del trabajo: carpeta privada por usuario en el almacenamiento (se usará con src/lib/imagen.ts).
insert into storage.buckets (id, name, public) values ('servicios', 'servicios', false) on conflict do nothing;
create policy "fotos: leer autenticados" on storage.objects for select to authenticated using (bucket_id = 'servicios');
create policy "fotos: subir a mi carpeta" on storage.objects for insert to authenticated
  with check (bucket_id = 'servicios' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "fotos: borrar las mías" on storage.objects for delete to authenticated
  using (bucket_id = 'servicios' and (storage.foldername(name))[1] = auth.uid()::text);
