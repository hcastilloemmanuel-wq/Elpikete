-- El Pikete · Migración 0001 · Perfiles, contactos privados, amistades y reglas de acceso
-- Pégalo completo en Supabase > SQL Editor > New query > Run.

create table public.perfiles (
  id uuid primary key references auth.users on delete cascade,
  apodo text not null check (char_length(apodo) between 2 and 30),
  provincia_cuba text check (provincia_cuba in (
    'Pinar del Río','Artemisa','La Habana','Mayabeque','Matanzas','Cienfuegos','Villa Clara','Sancti Spíritus',
    'Ciego de Ávila','Camagüey','Las Tunas','Holguín','Granma','Santiago de Cuba','Guantánamo','Isla de la Juventud')),
  estado_br char(2),
  ciudad_ibge integer,
  ciudad_nombre text,
  barrio text check (char_length(barrio) <= 60),
  oficios text[] not null default '{}' check (cardinality(oficios) <= 6),
  oficio_visibilidad text not null default 'todos' check (oficio_visibilidad in ('todos','amigos','servicios')),
  modo_discreto boolean not null default false,
  recien_llegado boolean not null default false,
  propositos text[] not null default '{}',
  frase text check (char_length(frase) <= 120),
  avatar_color text not null default '#C9A24B' check (avatar_color ~ '^#[0-9A-Fa-f]{6}$'),
  paso smallint not null default 2 check (paso between 1 and 7),
  completado boolean not null default false,
  creado_en timestamptz not null default now(),
  constraint completo_si_terminado check (
    not completado or (provincia_cuba is not null and estado_br is not null and ciudad_ibge is not null))
);
alter table public.perfiles enable row level security;
revoke all on public.perfiles from anon;

create policy "ver mi perfil" on public.perfiles for select to authenticated using (id = auth.uid());
create policy "editar mi perfil" on public.perfiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- Vista que ven los demás: sin correo, sin WhatsApp, y sin provincia si el usuario está en modo discreto.
create view public.perfiles_publicos as
  select id, apodo,
         case when modo_discreto then null else provincia_cuba end as provincia_cuba,
         estado_br, ciudad_ibge, ciudad_nombre, frase, avatar_color,
         case when oficio_visibilidad = 'todos' then oficios else '{}'::text[] end as oficios
  from public.perfiles
  where completado;
revoke all on public.perfiles_publicos from anon;
grant select on public.perfiles_publicos to authenticated;

create table public.contactos_privados (
  user_id uuid primary key references public.perfiles(id) on delete cascade,
  whatsapp text check (whatsapp ~ '^[1-9][0-9]{7,14}$'),
  whatsapp_visibilidad text not null default 'nadie' check (whatsapp_visibilidad in ('nadie','amigos','todos'))
);
alter table public.contactos_privados enable row level security;
revoke all on public.contactos_privados from anon;
create policy "solo el dueño" on public.contactos_privados for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create table public.amistades (
  id uuid primary key default gen_random_uuid(),
  de uuid not null references public.perfiles(id) on delete cascade,
  para uuid not null references public.perfiles(id) on delete cascade,
  estado text not null default 'pendiente' check (estado in ('pendiente','aceptada')),
  creado_en timestamptz not null default now(),
  check (de <> para),
  unique (de, para)
);
alter table public.amistades enable row level security;
revoke all on public.amistades from anon;
create policy "ver mis amistades" on public.amistades for select to authenticated using (de = auth.uid() or para = auth.uid());
create policy "pedir amistad" on public.amistades for insert to authenticated with check (de = auth.uid() and estado = 'pendiente');
create policy "aceptar amistad" on public.amistades for update to authenticated using (para = auth.uid()) with check (para = auth.uid());
create policy "borrar amistad" on public.amistades for delete to authenticated using (de = auth.uid() or para = auth.uid());

-- Al crearse una cuenta en Supabase Auth se crea su perfil vacío.
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare a text;
begin
  a := left(coalesce(nullif(trim(new.raw_user_meta_data->>'apodo'), ''), nullif(split_part(coalesce(new.email, ''), '@', 1), ''), 'Paisano'), 30);
  if char_length(a) < 2 then a := 'Paisano'; end if;
  insert into public.perfiles (id, apodo) values (new.id, a);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- El WhatsApp de otra persona solo se obtiene por aquí, que revisa su visibilidad y la amistad.
create function public.ver_whatsapp(objetivo uuid) returns text language sql stable security definer set search_path = public as $$
  select c.whatsapp from public.contactos_privados c
  where c.user_id = objetivo and (
    c.user_id = auth.uid()
    or c.whatsapp_visibilidad = 'todos'
    or (c.whatsapp_visibilidad = 'amigos' and exists (
      select 1 from public.amistades a
      where a.estado = 'aceptada'
        and ((a.de = auth.uid() and a.para = objetivo) or (a.para = auth.uid() and a.de = objetivo)))));
$$;
revoke all on function public.ver_whatsapp(uuid) from public, anon;
grant execute on function public.ver_whatsapp(uuid) to authenticated;

-- Borrar mi cuenta: borra el usuario y, en cascada, todo lo suyo.
create function public.borrar_mi_cuenta() returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'sin sesión'; end if;
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.borrar_mi_cuenta() from public, anon;
grant execute on function public.borrar_mi_cuenta() to authenticated;
