-- El Pikete · Migración 0007 · Reportes, bloqueos y cola de moderación
-- Va después de la 0006.

create table public.bloqueos (
  de uuid not null references public.perfiles(id) on delete cascade,
  a uuid not null references public.perfiles(id) on delete cascade,
  creado_en timestamptz not null default now(),
  primary key (de, a), check (de <> a)
);
alter table public.bloqueos enable row level security;
revoke all on public.bloqueos from anon;
create policy "ver mis bloqueos" on public.bloqueos for select to authenticated using (de = auth.uid());
create policy "desbloquear" on public.bloqueos for delete to authenticated using (de = auth.uid());

create function public.hay_bloqueo(persona1 uuid, persona2 uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.bloqueos x where (x.de = persona1 and x.a = persona2) or (x.de = persona2 and x.a = persona1));
$$;
revoke all on function public.hay_bloqueo(uuid, uuid) from public, anon;
grant execute on function public.hay_bloqueo(uuid, uuid) to authenticated;

create function public.bloquear_usuario(objetivo uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if objetivo = auth.uid() then return; end if;
  insert into public.bloqueos (de, a) values (auth.uid(), objetivo) on conflict do nothing;
  delete from public.amistades where (de = auth.uid() and para = objetivo) or (para = auth.uid() and de = objetivo);
end $$;
revoke all on function public.bloquear_usuario(uuid) from public, anon;
grant execute on function public.bloquear_usuario(uuid) to authenticated;

create table public.reportes_post (
  post_id uuid not null references public.publicaciones(id) on delete cascade,
  user_id uuid not null references public.perfiles(id) on delete cascade,
  creado_en timestamptz not null default now(),
  primary key (post_id, user_id)
);
alter table public.reportes_post enable row level security;
revoke all on public.reportes_post from anon, authenticated;

create function public.reportar_post(post uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.publicaciones where id = post and ciudad_ibge = public.mi_ciudad()) then raise exception 'no disponible'; end if;
  insert into public.reportes_post (post_id, user_id) values (post, auth.uid()) on conflict do nothing;
end $$;
revoke all on function public.reportar_post(uuid) from public, anon;
grant execute on function public.reportar_post(uuid) to authenticated;

-- El muro ya no muestra: lo de personas bloqueadas ni lo que tiene 3 o más reportes.
create or replace view public.cuadra_muro as
  select p.id, p.user_id, pe.apodo,
         case when pe.modo_discreto then null else pe.provincia_cuba end as provincia_cuba,
         pe.avatar_color, pe.ciudad_nombre, p.tipo, p.texto, p.creado_en,
         (select count(*) from public.comentarios c where c.post_id = p.id) as comentarios,
         (select count(*) from public.me_gusta g where g.post_id = p.id) as likes,
         exists (select 1 from public.me_gusta g where g.post_id = p.id and g.user_id = auth.uid()) as yo_like
  from public.publicaciones p join public.perfiles pe on pe.id = p.user_id
  where p.ciudad_ibge = public.mi_ciudad()
    and not public.hay_bloqueo(auth.uid(), p.user_id)
    and (select count(*) from public.reportes_post r where r.post_id = p.id) < 3;

create or replace view public.cuadra_comentarios as
  select c.id, c.post_id, c.user_id, pe.apodo,
         case when pe.modo_discreto then null else pe.provincia_cuba end as provincia_cuba,
         pe.avatar_color, c.texto, c.creado_en
  from public.comentarios c
  join public.publicaciones p on p.id = c.post_id and p.ciudad_ibge = public.mi_ciudad()
  join public.perfiles pe on pe.id = c.user_id
  where not public.hay_bloqueo(auth.uid(), c.user_id);

create or replace function public.paisanos_cerca() returns table (id uuid, apodo text, provincia_cuba text, avatar_color text, ciudad_nombre text)
language sql stable security definer set search_path = public as $$
  select p.id, p.apodo, p.provincia_cuba, p.avatar_color, p.ciudad_nombre from public.perfiles p
  where p.completado and not p.modo_discreto and p.ciudad_ibge = public.mi_ciudad() and p.id <> auth.uid()
    and not public.hay_bloqueo(auth.uid(), p.id)
  order by p.creado_en desc limit 100;
$$;

-- Nadie puede escribirle a quien lo bloqueó (ni a quien él bloqueó).
drop policy "escribir a un amigo" on public.mensajes;
create policy "escribir a un amigo" on public.mensajes for insert to authenticated
  with check (de = auth.uid() and public.son_amigos(de, para) and not public.hay_bloqueo(de, para));

-- Moderación: quien tenga una fila en roles ve la cola. Se asigna desde el panel de Supabase (ver la guía).
create table public.roles (user_id uuid primary key references public.perfiles(id) on delete cascade, rol text not null check (rol in ('moderador')));
alter table public.roles enable row level security;
revoke all on public.roles from anon, authenticated;

create function public.cola_moderacion() returns table (tipo text, id uuid, texto text, reportes bigint, creado_en timestamptz)
language sql stable security definer set search_path = public as $$
  select 'publicacion', p.id, p.texto, count(r.*), p.creado_en from public.publicaciones p
    join public.reportes_post r on r.post_id = p.id
    where exists (select 1 from public.roles x where x.user_id = auth.uid() and x.rol = 'moderador') group by p.id
  union all
  select 'anuncio', a.id, a.titulo || ' — ' || a.descripcion, 0, a.creado_en from public.anuncios a
    where a.estado = 'revision' and exists (select 1 from public.roles x where x.user_id = auth.uid() and x.rol = 'moderador')
  order by 5 desc;
$$;
revoke all on function public.cola_moderacion() from public, anon;
grant execute on function public.cola_moderacion() to authenticated;
