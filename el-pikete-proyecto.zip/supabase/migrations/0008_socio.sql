-- El Pikete · Migración 0008 · Límite de uso de El Socio (IA)
create table public.socio_uso (
  user_id uuid not null references public.perfiles(id) on delete cascade,
  dia date not null default current_date,
  n integer not null default 0,
  primary key (user_id, dia)
);
alter table public.socio_uso enable row level security;
revoke all on public.socio_uso from anon, authenticated;

-- Cuenta un mensaje. Devuelve 'ok', 'dia' (pasó el límite diario) o 'mes' (pasó el tope mensual de toda la app).
create function public.socio_registrar_uso(limite_dia integer default 30, tope_mes integer default 5000) returns text
language plpgsql security definer set search_path = public as $$
declare hoy integer; mes integer;
begin
  if auth.uid() is null then return 'dia'; end if;
  select coalesce(sum(n), 0) into mes from public.socio_uso where dia >= date_trunc('month', current_date);
  if mes >= tope_mes then return 'mes'; end if;
  select coalesce(n, 0) into hoy from public.socio_uso where user_id = auth.uid() and dia = current_date;
  if coalesce(hoy, 0) >= limite_dia then return 'dia'; end if;
  insert into public.socio_uso (user_id, dia, n) values (auth.uid(), current_date, 1)
    on conflict (user_id, dia) do update set n = public.socio_uso.n + 1;
  return 'ok';
end $$;
revoke all on function public.socio_registrar_uso(integer, integer) from public, anon;
grant execute on function public.socio_registrar_uso(integer, integer) to authenticated;
