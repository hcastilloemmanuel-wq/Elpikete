-- El Pikete · Migración 0006 · La Bolsa y Pincha (anuncios por ciudad, vencen a los 30 días)
-- Va después de la 0005 (usa mi_ciudad()).

create table public.anuncios (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.perfiles(id) on delete cascade,
  ciudad_ibge integer not null,
  tipo text not null check (tipo in ('vendo','compro','alquilo','servicio','empleo','busco_empleo')),
  titulo text not null check (char_length(btrim(titulo)) between 4 and 80),
  descripcion text not null check (char_length(btrim(descripcion)) between 10 and 600),
  precio numeric(10,2) check (precio >= 0 and precio <= 10000000),
  barrio text check (char_length(barrio) <= 60),
  jornada text check (char_length(jornada) <= 40),
  idioma text check (char_length(idioma) <= 40),
  mostrar_whatsapp boolean not null default false,
  estado text not null default 'activo' check (estado in ('activo','cerrado','revision')),
  creado_en timestamptz not null default now(),
  vence_en timestamptz not null default now() + interval '30 days'
);
create index anuncios_ciudad_idx on public.anuncios (ciudad_ibge, creado_en desc);
alter table public.anuncios enable row level security;
revoke all on public.anuncios from anon;
revoke insert, update, delete on public.anuncios from authenticated;
grant select on public.anuncios to authenticated;
grant update (estado) on public.anuncios to authenticated;
create policy "ver los míos" on public.anuncios for select to authenticated using (user_id = auth.uid());
-- Cerrar el mío: solo puede pasar a 'cerrado' (renovar y revisión van por funciones del servidor).
create policy "cerrar el mío" on public.anuncios for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and estado = 'cerrado');

create table public.reportes_anuncio (
  anuncio_id uuid not null references public.anuncios(id) on delete cascade,
  user_id uuid not null references public.perfiles(id) on delete cascade,
  creado_en timestamptz not null default now(),
  primary key (anuncio_id, user_id)
);
alter table public.reportes_anuncio enable row level security;
revoke all on public.reportes_anuncio from anon, authenticated;

-- Señales de estafa (las mismas que en la app, pero aquí no se pueden saltar).
create function public.anuncio_riesgoso(txt text) returns boolean language sql immutable as $$
  select txt ~* '(adelantad[oa]|adiantad[oa]|taxa de (inscri|cadastro|admiss)|western union|moneygram|transfer[eê]ncia para (um )?terceiro|transferencia a (un )?tercero|gan(a|e|ar) (dinero )?f[aá]cil|ganancias? garantizad|ganhos garantidos|multiplica tu dinero|(env[ií]a|manda|envie)\s+(tu|seu|su)?\s*(pasaporte|passaporte|cpf|documentos?))';
$$;

create function public.publicar_anuncio(p jsonb) returns public.anuncios language plpgsql security definer set search_path = public as $$
declare ciudad integer; fila public.anuncios;
begin
  ciudad := public.mi_ciudad();
  if auth.uid() is null or ciudad is null then raise exception 'perfil incompleto'; end if;
  -- Límite suave: 10 anuncios por día.
  if (select count(*) from public.anuncios where user_id = auth.uid() and creado_en > now() - interval '1 day') >= 10 then
    raise exception 'demasiados anuncios hoy';
  end if;
  insert into public.anuncios (user_id, ciudad_ibge, tipo, titulo, descripcion, precio, barrio, jornada, idioma, mostrar_whatsapp, estado)
  values (auth.uid(), ciudad, p->>'tipo', p->>'titulo', p->>'descripcion', nullif(p->>'precio','')::numeric, nullif(p->>'barrio',''),
          nullif(p->>'jornada',''), nullif(p->>'idioma',''), coalesce((p->>'mostrar_whatsapp')::boolean, false),
          case when public.anuncio_riesgoso(coalesce(p->>'titulo','') || ' ' || coalesce(p->>'descripcion','')) then 'revision' else 'activo' end)
  returning * into fila;
  return fila;
end $$;
revoke all on function public.publicar_anuncio(jsonb) from public, anon;
grant execute on function public.publicar_anuncio(jsonb) to authenticated;

create function public.renovar_anuncio(anuncio uuid) returns void language sql security definer set search_path = public as $$
  update public.anuncios set vence_en = now() + interval '30 days', estado = 'activo'
  where id = anuncio and user_id = auth.uid() and estado in ('activo','cerrado');
$$;
revoke all on function public.renovar_anuncio(uuid) from public, anon;
grant execute on function public.renovar_anuncio(uuid) to authenticated;

-- Tres reportes de personas distintas lo mandan a revisión.
create function public.reportar_anuncio(anuncio uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.anuncios where id = anuncio and ciudad_ibge = public.mi_ciudad()) then raise exception 'no disponible'; end if;
  insert into public.reportes_anuncio (anuncio_id, user_id) values (anuncio, auth.uid()) on conflict do nothing;
  if (select count(*) from public.reportes_anuncio where anuncio_id = anuncio) >= 3 then
    update public.anuncios set estado = 'revision' where id = anuncio;
  end if;
end $$;
revoke all on function public.reportar_anuncio(uuid) from public, anon;
grant execute on function public.reportar_anuncio(uuid) to authenticated;

-- Lo que ve la gente: solo activos y vigentes de mi ciudad (más los míos, en cualquier estado).
create view public.anuncios_publicos as
  select a.id, a.user_id, pe.apodo, pe.avatar_color, a.ciudad_ibge, pe.ciudad_nombre, a.tipo, a.titulo, a.descripcion, a.precio,
         a.barrio, a.jornada, a.idioma, a.mostrar_whatsapp, a.creado_en, a.vence_en, a.estado
  from public.anuncios a join public.perfiles pe on pe.id = a.user_id
  where (a.ciudad_ibge = public.mi_ciudad() and a.estado = 'activo' and a.vence_en > now()) or a.user_id = auth.uid();
revoke all on public.anuncios_publicos from anon;
grant select on public.anuncios_publicos to authenticated;
