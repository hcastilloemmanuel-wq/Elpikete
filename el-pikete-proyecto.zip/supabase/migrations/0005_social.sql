-- El Pikete · Migración 0005 · Cuadra (publicaciones por ciudad), comentarios, "me gusta" y mensajes
-- Pégalo completo en Supabase > SQL Editor > New query > Run. Va después de la 0001 y la 0004.

create function public.mi_ciudad() returns integer language sql stable security definer set search_path = public as $$
  select ciudad_ibge from public.perfiles where id = auth.uid() and completado;
$$;
revoke all on function public.mi_ciudad() from public, anon;
grant execute on function public.mi_ciudad() to authenticated;

create table public.publicaciones (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.perfiles(id) on delete cascade,
  ciudad_ibge integer not null,
  tipo text not null check (tipo in ('pregunta','aviso','evento','recomendacion','llegue')),
  texto text not null check (char_length(btrim(texto)) between 1 and 500),
  creado_en timestamptz not null default now()
);
create index publicaciones_ciudad_idx on public.publicaciones (ciudad_ibge, creado_en desc);
alter table public.publicaciones enable row level security;
revoke all on public.publicaciones from anon;
create policy "ver las de mi ciudad" on public.publicaciones for select to authenticated using (ciudad_ibge = public.mi_ciudad());
create policy "publicar en mi ciudad" on public.publicaciones for insert to authenticated
  with check (user_id = auth.uid() and ciudad_ibge = public.mi_ciudad());
create policy "borrar las mías" on public.publicaciones for delete to authenticated using (user_id = auth.uid());

create table public.comentarios (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.publicaciones(id) on delete cascade,
  user_id uuid not null references public.perfiles(id) on delete cascade,
  texto text not null check (char_length(btrim(texto)) between 1 and 500),
  creado_en timestamptz not null default now()
);
create index comentarios_post_idx on public.comentarios (post_id, creado_en);
alter table public.comentarios enable row level security;
revoke all on public.comentarios from anon;
create policy "ver comentarios de mi ciudad" on public.comentarios for select to authenticated
  using (exists (select 1 from public.publicaciones p where p.id = post_id and p.ciudad_ibge = public.mi_ciudad()));
create policy "comentar en mi ciudad" on public.comentarios for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.publicaciones p where p.id = post_id and p.ciudad_ibge = public.mi_ciudad()));
create policy "borrar mis comentarios" on public.comentarios for delete to authenticated using (user_id = auth.uid());

create table public.me_gusta (
  post_id uuid not null references public.publicaciones(id) on delete cascade,
  user_id uuid not null references public.perfiles(id) on delete cascade,
  primary key (post_id, user_id)
);
alter table public.me_gusta enable row level security;
revoke all on public.me_gusta from anon;
create policy "ver mis me gusta" on public.me_gusta for select to authenticated using (user_id = auth.uid());
create policy "dar me gusta" on public.me_gusta for insert to authenticated
  with check (user_id = auth.uid() and exists (select 1 from public.publicaciones p where p.id = post_id and p.ciudad_ibge = public.mi_ciudad()));
create policy "quitar mi me gusta" on public.me_gusta for delete to authenticated using (user_id = auth.uid());

-- Muro de mi ciudad: publicación + autor (sin provincia si es discreto) + conteos + si yo di me gusta.
create view public.cuadra_muro as
  select p.id, p.user_id, pe.apodo,
         case when pe.modo_discreto then null else pe.provincia_cuba end as provincia_cuba,
         pe.avatar_color, pe.ciudad_nombre, p.tipo, p.texto, p.creado_en,
         (select count(*) from public.comentarios c where c.post_id = p.id) as comentarios,
         (select count(*) from public.me_gusta g where g.post_id = p.id) as likes,
         exists (select 1 from public.me_gusta g where g.post_id = p.id and g.user_id = auth.uid()) as yo_like
  from public.publicaciones p join public.perfiles pe on pe.id = p.user_id
  where p.ciudad_ibge = public.mi_ciudad();
revoke all on public.cuadra_muro from anon;
grant select on public.cuadra_muro to authenticated;

create view public.cuadra_comentarios as
  select c.id, c.post_id, c.user_id, pe.apodo,
         case when pe.modo_discreto then null else pe.provincia_cuba end as provincia_cuba,
         pe.avatar_color, c.texto, c.creado_en
  from public.comentarios c
  join public.publicaciones p on p.id = c.post_id and p.ciudad_ibge = public.mi_ciudad()
  join public.perfiles pe on pe.id = c.user_id;
revoke all on public.cuadra_comentarios from anon;
grant select on public.cuadra_comentarios to authenticated;

-- Paisanos de mi ciudad que se pueden descubrir: nunca el modo discreto, nunca yo.
create function public.paisanos_cerca() returns table (id uuid, apodo text, provincia_cuba text, avatar_color text, ciudad_nombre text)
language sql stable security definer set search_path = public as $$
  select p.id, p.apodo, p.provincia_cuba, p.avatar_color, p.ciudad_nombre from public.perfiles p
  where p.completado and not p.modo_discreto and p.ciudad_ibge = public.mi_ciudad() and p.id <> auth.uid()
  order by p.creado_en desc limit 100;
$$;
revoke all on function public.paisanos_cerca() from public, anon;
grant execute on function public.paisanos_cerca() to authenticated;

-- Mis amigos y solicitudes con los datos públicos de la otra persona.
create function public.mis_amistades() returns table (id uuid, apodo text, provincia_cuba text, avatar_color text, ciudad_nombre text, estado text)
language sql stable security definer set search_path = public as $$
  select p.id, p.apodo,
         case when p.modo_discreto and a.estado <> 'aceptada' then null else p.provincia_cuba end,
         p.avatar_color, p.ciudad_nombre,
         case when a.estado = 'aceptada' then 'amigo' when a.de = auth.uid() then 'enviada' else 'recibida' end
  from public.amistades a
  join public.perfiles p on p.id = case when a.de = auth.uid() then a.para else a.de end
  where a.de = auth.uid() or a.para = auth.uid();
$$;
revoke all on function public.mis_amistades() from public, anon;
grant execute on function public.mis_amistades() to authenticated;

create function public.son_amigos(a uuid, b uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.amistades x where x.estado = 'aceptada' and ((x.de = a and x.para = b) or (x.de = b and x.para = a)));
$$;
revoke all on function public.son_amigos(uuid, uuid) from public, anon;
grant execute on function public.son_amigos(uuid, uuid) to authenticated;

-- Mensajes: solo entre amigos, solo los ven los dos.
create table public.mensajes (
  id uuid primary key default gen_random_uuid(),
  de uuid not null references public.perfiles(id) on delete cascade,
  para uuid not null references public.perfiles(id) on delete cascade,
  texto text not null check (char_length(btrim(texto)) between 1 and 1000),
  creado_en timestamptz not null default now(),
  check (de <> para)
);
create index mensajes_par_idx on public.mensajes (de, para, creado_en);
alter table public.mensajes enable row level security;
revoke all on public.mensajes from anon;
create policy "ver mis mensajes" on public.mensajes for select to authenticated using (de = auth.uid() or para = auth.uid());
create policy "escribir a un amigo" on public.mensajes for insert to authenticated
  with check (de = auth.uid() and public.son_amigos(de, para));
